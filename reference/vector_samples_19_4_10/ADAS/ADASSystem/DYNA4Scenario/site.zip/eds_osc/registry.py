#
# Copyright (c) Vector Informatik GmbH. All rights reserved.
#
import copy
import logging
from collections import defaultdict
from dataclasses import dataclass
from typing import Callable, DefaultDict, Dict, List, Optional, Type
from xml.etree.ElementTree import Element

from eds_osc.handler import EmptyHandler

from .utils import underscore

logger = logging.getLogger(__name__)


@dataclass
class Handler:
    func: Callable
    casts: Dict[str, Callable]
    children: Dict[str, str]
    pass_context: bool
    pass_element: bool
    validator: Optional[Callable]


class NoHandlerException(Exception):
    """Exception that is thrown when no handler was found for a given XML tag"""
    def __init__(self, element: Element, msg=None):
        super().__init__(msg or f"No handler for tag {element.tag}")
        self.element = element


class XMLRegistry:
    """XML Registry class"""
    def __init__(self):
        """
        Create a new XMLRegistry instance.
        """
        self.handlers: DefaultDict[str, List[Handler]] = defaultdict(list)
        self.trivial_tags = set()

    def deepcopy(self) -> "XMLRegistry":
        """
        Make a deep copy of this object.
        """
        return copy.deepcopy(self)

    def register_trivial(self, trivial_tags: List[str]):
        """
        Add tags that are considered trivial,
        meaning that they always contain exactly one child element.
        When a trivial element is processed, all operations are delegated to its child element.
        """
        self.trivial_tags.update(trivial_tags)

    def register_func(self,
                      func: Callable,
                      *names: str,
                      casts: Dict[str, Callable] = None,
                      children: Dict[str, str] = None,
                      pass_context=True,
                      pass_element=True,
                      replace=False,
                      validator: Optional[Callable] = None):
        for name in names:
            if len(self.handlers[name]) > 0 and not replace:
                raise KeyError(f"Handler for tag {name} is already registered")
            if name in self.trivial_tags:
                raise KeyError(f"Tag {name} is already registered as a trivial tag")
            self.handlers[name].append(
                Handler(func, casts or {}, children or {}, pass_context, pass_element, validator))

    def register_class(self,
                       klass: Type,
                       *names: str,
                       casts: Dict[str, Callable] = None,
                       children: Dict[str, str] = None):
        """
        Register a dataclass for handling xml elements.

        :param klass: Dataclass
        :param names: tag name or list of tag names of the elements to handle
        :param casts: optional dictionary to type-cast injected attributes. Key: parameter name, Value: callable
        :param children: optional dictionary to convert child XML elements.
            Result will be passed to class as additional parameter.
            Key: parameter name, Value: Child Class Tag

        Example usage::

            @dataclass
            class Pet:
                age: int
                name: str

            @dataclass
            class Human:
                pet_attr: Pet
                name: str,

            reg.register_class(Pet, "PetTag", casts={"age": int})
            reg.register_class(Human, "HumanTag", children={"pet_attr": "PetTag"})

        Sample Input XML:

        .. code-block:: XML

            <HumanTag name="Bob">
                <PetTag age="2" name="Lassie"/>
            </HumanTag>
        """
        self.register_func(klass,
                           *names,
                           casts=casts,
                           children=children,
                           pass_context=False,
                           pass_element=False)

    def register(self,
                 *names: str,
                 casts: Dict[str, Callable] = None,
                 children: Dict[str, str] = None,
                 validator: Optional[Callable] = None):
        """
        Decorator for registering a new method for handling xml elements.
        The decoration target must be a method.
        Its first positional argument will be the xml element.
        The following keyword arguments will be the element's attributes,
        converted to snake_case.


        Example usage::

            class MyParser:
                @reg.register("SomeElement")
                def handle_some_element(self, element, attrib1, attrib2):
                    ...

        :param names: tag name or list of tag names of the elements to handle
        :param casts: optional dictionary to type-cast injected attributes. Key: parameter name, Value: callable
        :param children: optional dictionary to convert child XML elements.
            Result will be passed to decorated function as additional parameter.
            Key: parameter name, Value: Child Class Tag
        :param validator: Optional function to perform optional validation to generate error and warning markers
        :return: a decorator
        """
        def decorator(func):
            self.register_func(func,
                               *names,
                               casts=casts,
                               children=children,
                               pass_context=True,
                               pass_element=True,
                               validator=validator)
            return func

        return decorator

    def build_args(self, context, element: Element, handler: Handler, kwargs: Dict = None):
        attrib = dict(kwargs or {})
        # load raw attribute values from XML, skip DYNA4-internal variables starting with __
        attrib.update(
            {underscore(k): v
             for k, v in element.attrib.items() if not k.startswith("__")})

        # cast attributes to correct datatype, according to registered conversion functions
        for attr_name, cast_fn in handler.casts.items():
            if attr_name not in attrib:
                continue

            old_value = attrib[attr_name]
            try:
                attrib[attr_name] = cast_fn(old_value)
            except Exception as e:
                msg = f"Unexpected datatype of attribute '{attr_name}' "\
                      f"in XML tag '{element.tag}' (value: '{old_value}')"
                # Rethrow exception with a more user-friendly error message
                raise ValueError(msg) from e

        # recursively handle children if the handler was defined to do that
        attrib.update(
            {k: self.handle(context, element.find(v))
             for k, v in handler.children.items()})

        args = []
        if handler.pass_context:
            args.append(context)
        if handler.pass_element:
            args.append(element)

        return args, attrib

    def handle(self, context, element: Element, skip_if_none=True, **kwargs):
        """
        Handle a given XML Element.

        Looks up previously registered handlers and calls a matching one if found.
        :param context: Parser instance
        :param element: XML Element
        :param skip_if_none: Do not throw an exception if `None` is passed
        :param kwargs: arbitrary keyword arguments that get passed on to the handler function
        :return forwards the return value of the handler function
        :raise NoHandlerException: if no handler was found for a given tag
        """
        if element is None:
            if skip_if_none:
                return
            raise ValueError("Tried to handle `None` element, but `skip_if_none` is false")

        while element.tag in self.trivial_tags:
            logger.debug("'%s' is trivial. Using first child...", element.tag)
            if len(element) == 0:
                raise AttributeError(f'"{element.tag}" is an empty element.')

            element = element[0]

        logger.debug("Handling %s", element.tag)
        handlers = self.handlers[element.tag]

        if len(handlers) == 0:
            raise NoHandlerException(element)
        if len(handlers) > 1:
            raise KeyError(
                f"Too many ({len(handlers)}) handlers registered for tag '{element.tag}'")

        # exactly one valid handler. let's use it
        handler = handlers[0]
        args, attrib = self.build_args(context, element, handler, kwargs)
        return handler.func(*args, **attrib)

    def validate_recursive(self, context, element: Element):
        """
        Walk through the whole XML tree and invoke validator callbacks if defined
        """
        handlers = self.handlers[element.tag]
        if handlers:
            handler: Handler = handlers[0]

            try:
                # always build args, even without validator
                # so that we catch casting problems
                args, attrib = self.build_args(context, element, handler)

                if validator := handler.validator:
                    validator(*args, **attrib)
            except Exception as e:
                context.add_error(str(e))

        for e in element:
            self.validate_recursive(context, e)
