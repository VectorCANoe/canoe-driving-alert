#
# Copyright (c) Vector Informatik GmbH. All rights reserved.
#
import logging
import re
from collections import defaultdict
from typing import Any, Iterable, List, Optional, SupportsFloat, Type, TypeVar

from dyna4.scenario import LoggingBridge, get_signal

from .typealiases import FloatSupplier

logger = logging.getLogger(__name__)


class Dyna4LogHandler(logging.Handler):
    def __init__(self):
        super().__init__()
        self.bridge = LoggingBridge()
        self.setFormatter(logging.Formatter("[%(name)s] %(message)s"))

    def emit(self, record: logging.LogRecord):
        msg: str = self.format(record)
        self.bridge.log(record.levelname.lower(), msg)


def join_format(separator: str, format_: str, items: Iterable[Any]):
    """
    Join a list of objects into a string
    by applying a format string to each of the items
    """
    return separator.join(format_.format(x) for x in items)


def underscore(word: str) -> str:
    """
    Make an underscored, lowercase form from the expression in the string.

    Example::

        >>> underscore("DeviceType")
        'device_type'
    """
    word = re.sub(r"([A-Z]+)([A-Z][a-z])", r'\1_\2', word)
    word = re.sub(r"([a-z\d])([A-Z])", r'\1_\2', word)
    word = word.replace("-", "_")
    return word.lower()


def float_or_none(val: Optional[SupportsFloat]) -> Optional[float]:
    return float(val) if val is not None else None


def int_or_one(val: str) -> int:
    try:
        return int(val)
    except ValueError:
        return 1


def to_bool(inp: Any) -> bool:
    """
    Converts string "True" / "False" to boolean. Cannot use `bool(...)`!
    In case the input is no string we use the bool constructor
    """
    if isinstance(inp, str):
        return inp.lower() == "true"
    else:
        return bool(inp)


T = TypeVar("T")


def assert_is_list_of(obj: List[T], klass: Type[T], allow_empty: bool = True):
    assert isinstance(obj, list)
    if not allow_empty:
        assert len(obj) > 0
    if len(obj) > 0:
        assert isinstance(obj[0],
                          klass), f"Expected a list of {klass} but got a list of {type(obj[0])}"



class ElementNameManager:
    """
    OpenSCENARIO allows referencing StoryboardElements by an abbreviated name, as long as it is unique.
    This class manages all names so that they can be resolved at the end of the parsing process.
    """
    def __init__(self):
        self.names = defaultdict(set)
        self.refs = {}

    def add(self, typ: str, full_name: str) -> str:
        """
        Finds a unique element name according to OSC standard and adds it to the list of known element names.
        If the name ends with "[]", special treatment is done to find a unique suffix.

        :param typ: Type of the Element ("action", "act", "story", ...)
        :param full_name: Absolute name of the element, including all parents using :: delimiter
        :return: Guaranteed unique name for the element
        :raises KeyError: If the name is a duplicate and special treatment is not enabled
        """
        if not full_name.endswith("[]"):
            if full_name in self.names[typ]:
                raise KeyError(f"Duplicate element {full_name}")
            self.names[typ].add(full_name)
            return full_name

        # special reference
        full_name = full_name[:-2]

        # count up until we found an unused name
        index = 0
        while True:
            name = f"{full_name}{index}"
            if name not in self.names[typ]:
                self.names[typ].add(name)
                return name
            index += 1

    def resolve(self, typ: str, short_name: str) -> str:
        """
        Get a fully qualified name for a StoryboardElement
        :param typ: Type of the Element ("action", "act", "story", ...)
        :param short_name: Unique suffix of an element name
        :return: Fully qualified name
        """
        typ_members = self.names[typ]
        if short_name in typ_members:
            # exact match
            return short_name

        matches = [n for n in typ_members if n.endswith(short_name)]
        if len(matches) == 1:
            return matches[0]
        elif len(matches) > 1:
            raise KeyError(f"{typ} named {short_name} is ambiguous. Possible matches: {matches}")
        else:
            raise KeyError(f"Could not resolve {typ} named {short_name}")


def get_signal_float_supplier(value: str) -> FloatSupplier:
    if ":" in value:
        prefix, body = value.split(":", maxsplit=1)
        if prefix == "signal":
            signal = get_signal(body)
            return signal.read
        else:
            raise AttributeError(f"Unknown prefix {prefix}")
    else:
        v = float(value)
        return lambda: v


def unsupported_validator(parser, element, **kwargs):
    """Utility validator to be used when a tag is not implemented yet"""
    parser.add_info(f"'{element.tag}' is not supported yet")


def position_validator(parser, element):
    if element is None or len(element) == 0:
        parser.add_error(
            "'Position' is empty. It does not contain any of ('WorldPosition', 'RelativeWorldPosition', "
            "'RelativeObjectPosition', 'RoadPosition', 'RelativeRoadPosition', 'LanePosition', "
            "'RelativeLanePosition', 'RoutePosition', 'GeoPosition', 'TrajectoryPosition')")
