#
# Copyright (c) Vector Informatik GmbH. All rights reserved.
#

from enum import Enum

#: Absolute tolerance speed in m/s when a vehicle is considered standing still
TOLERANCE_STAND_STILL = 0.01

#: Namespace for custom DYNA4 XML tags
DYNA4_XML_NAMESPACE = "http://vector.com/dyna4/openscenario/v1.0"
