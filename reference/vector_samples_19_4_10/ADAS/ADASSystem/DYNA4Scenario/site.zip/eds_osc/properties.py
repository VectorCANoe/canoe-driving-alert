#
# Copyright (c) Vector Informatik GmbH. All rights reserved.
#
import inspect
from abc import ABC
from collections import defaultdict
from typing import Any, Callable, Dict, List, Optional
from xml.etree.ElementTree import Element

from dyna4.scenario import MotionModel, SpeedLimitAdherence, StaticCodeMarkerList

from eds_osc.model import CarFollowingModel, SpeedControl
from eds_osc.utils import to_bool

_UNDEFINED = object()
"""Sentinel object for internal use"""


class PropertyField:
    """
    Base class for a OpenSCENARIO `Property` type.
    To be used as class attributes inside `eds_osc.Properties`.
    """
    def __init__(self,
                 name: str,
                 default: Any = _UNDEFINED,
                 typ: Optional[Callable[[str], Any]] = None):
        """
        Define a new property.

        :param name: The corresponding OSC property name that is used for parsing.
        :param default: Fallback value when the property is not defined in the parsed XML.
            If undefined, the field is considered mandatory.
        :param typ: Callable that converts the string value to a desired type.
            If undefined, the raw string is used.
        """
        self.default = default
        self.name = name
        self.typ = typ

    def has_default(self):
        return self.default is not _UNDEFINED

    def cast(self, raw_value: str) -> Any:
        if self.typ:
            return self.typ(raw_value)
        return raw_value

    def __str__(self):
        return self.name

    def __repr__(self):
        return f"{type(self).__name__}({self.name!r})"


class ChoiceField(PropertyField):
    def __init__(self, name: str, options: Dict[str, Any], default: Any = _UNDEFINED):
        """
        Construct a new ChoiceField.

        :param name: Property name that must equal the XML `name` attribute of the Property tag
        :param options: Dictionary of possible values for this field.
                        Key is the string that will be used in the XML `value` attribute of the Property tag
        """
        super().__init__(name, default=default)
        self.options = options

    def cast(self, raw_value: str) -> Any:
        try:
            return self.options[raw_value]
        except KeyError:
            raise KeyError(
                f"Invalid value '{raw_value}' for choice field property {self!r}. Allowed values: {list(self.options.keys())}"
            )


class FloatField(PropertyField):
    """
    Floating-point property
    """
    def __init__(self, name: str, default: Any = _UNDEFINED):
        super().__init__(name, default=default, typ=float)


class BooleanField(PropertyField):
    """
    Boolean property
    """
    def __init__(self, name: str, default: Any = _UNDEFINED):
        super().__init__(name, default=default, typ=bool)

    def cast(self, raw_value: str) -> bool:
        if self.typ:
            return to_bool(raw_value)
        return raw_value


class MixedField(PropertyField):
    def __init__(self, name: str, type_or_dict: List[Any], default: Any = _UNDEFINED):
        """
        Construct a new MixedField.

        :param name: Property name that must equal the XML `name` attribute of the Property tag :param type_or_dict:
            List of mixed types and dictionaries of possible values for this field. If entry is a dictionary, the key is
            the string that will be used in the XML `value` attribute of the Property tag
        """
        super().__init__(name, default=default)
        self.type_or_dict = type_or_dict

    def cast(self, raw_value: str) -> Any:
        for t in self.type_or_dict:
            if isinstance(t, dict):
                try:
                    return t[raw_value]
                except KeyError:
                    continue
            else:
                if t:
                    try:
                        return t(raw_value)
                    except ValueError:
                        continue

        raise KeyError(
            f"Invalid value '{raw_value}' for choice field property {self!r}. Allowed values: {self.type_or_dict}"
        )


class Properties(ABC):
    """
    Abstract base class for OpenSCENARIO `Properties`.
    Subclasses should define the desired property elements as class attributes.
    Each class attribute should be a `PropertyField` (or a subclass).
    Type annotations should indicate the resulting type after parsing, not `PropertyField`.

    During construction, the new instance's member attributes are
    populated with the corresponding values from the XML element.
    """
    def __init__(self,
                 marker_list: StaticCodeMarkerList,
                 element: Optional[Element] = None,
                 filename: str = "Unknown",
                 context_info: str = ""):
        """
        Parse an XML element to obtain a new Properties instance.

        :param element: Optional XML element. If None, a default instance is constructed.
        """
        self.marker_list = marker_list
        self.filename = filename
        self.context_info = context_info

        if element is not None and len(element) > 0:
            props = {
                prop.attrib['name']: prop.attrib['value']
                for prop in element.findall("Property")
            }

            for _ in element.findall("File"):
                raise NotImplementedError("Properties.File not implemented")
        else:
            props = {}
        self.parse(props)

    def parse(self, props: Dict[str, str]):
        valid_xml_names = set()
        for attr_name, field in inspect.getmembers(self.__class__,
                                                   lambda x: isinstance(x, PropertyField)):
            xml_name = field.name
            valid_xml_names.add(xml_name)
            if xml_name in props:
                value = field.cast(props[xml_name])
            elif field.has_default():
                value = field.default
            else:
                raise AttributeError(f"Mandatory property '{xml_name}' not found")
            setattr(self, attr_name, value)

        # combine all properties with same context
        props_with_same_context = defaultdict(list)

        for key in props.keys():
            if key not in valid_xml_names:
                if self.context_info == "":
                    self.marker_list.add_info_marker(str(self.filename),
                                                     f"Unknown property '{key}'")
                else:
                    props_with_same_context[self.context_info].append(key)

        for context_info, properties in props_with_same_context.items():
            join_string = "', '"
            self.marker_list.add_info_marker(
                str(self.filename),
                f"{context_info} uses unknown properties ('{join_string.join(properties)}')")


class ControllerProperties(Properties):
    """
    Properties for the OSC `Controller` class. Example usage in OSC 1.x:

    .. code-block:: XML

        <Properties>
            <Property name="MotionModel" value="Smooth"/>
            <Property name="Driver.SpeedLimitAdherence" value="1.1"/>
            <Property name="Driver.CanUseNonDrivableLanes" value="False"/>
            <Property name="Driver.CarFollowing.Model" value="Default"/>
            <Property name="Driver.CarFollowing.MinimumFrontDistance" value="10.0"/>
            <Property name="Driver.CarFollowing.TimeHeadway" value="1.8"/>
            <Property name="Driver.CarFollowing.DistanceTolerance" value="3.0"/>
            <Property name="Driver.CarFollowing.DistanceControlGain" value="1.0"/>
            <Property name="Driver.CarFollowing.MaximumLateralOffsetToLeader" value="2.0"/>
            <Property name="Driver.Constraints.LongitudinalSpeed" value="25.0"/>
            <Property name="Driver.Constraints.LongitudinalAcceleration" value="2.0"/>
            <Property name="Driver.Constraints.LongitudinalDeceleration" value="2.5"/>
            <Property name="Driver.Constraints.LongitudinalAccelerationRate" value="0.3"/>
            <Property name="Driver.Constraints.LongitudinalDecelerationRate" value="0.4"/>
            <Property name="Driver.Constraints.LateralSpeed" value="1.2"/>
            <Property name="Driver.Constraints.LateralAcceleration" value="2.1"/>
            <Property name="Driver.Constraints.LateralDeceleration" value="2.9"/>
            <Property name="Driver.Constraints.LateralAccelerationRate" value="0.2"/>
            <Property name="Driver.Constraints.LateralDecelerationRate" value="0.8"/>
        </Properties>
    """

    speed_limit_adherence: Any = MixedField("Driver.SpeedLimitAdherence", [
        float, {
            "Exact": SpeedLimitAdherence.Mode.EXACT,
            "Ignore": SpeedLimitAdherence.Mode.IGNORE
        }
    ],
                                            default=SpeedLimitAdherence.Mode.IGNORE)
    """Driver's speed limit adherence. Value is a factor by which the current speed limit is multiplied.
    Alternatively, the mode is either `Exact` or `Ignore`"""

    motion_model: MotionModel = ChoiceField("MotionModel", {
        "Exact": MotionModel.EXACT,
        "Smooth": MotionModel.SMOOTH
    },
                                            default=MotionModel.EXACT)
    """Type of motion model to use.
    Exact: exactly match the specified transition dynamics
    Smooth: use a more realistic model for smooth transitions
    """

    preview_time: float = FloatField("Driver.PreviewTime", default=1.8)
    """Driver's characteristic preview time
    """

    can_use_non_drivable_lanes: bool = BooleanField("Driver.CanUseNonDrivableLanes", default=False)
    """Can the driver use non-drivable lanes
    """

    car_following_model: CarFollowingModel = ChoiceField("Driver.CarFollowing.Model", {
        "None": CarFollowingModel.NONE,
        "Default": CarFollowingModel.DEFAULT
    },
                                                         default=CarFollowingModel.NONE)
    """Type of car following model use.
    None: no car following model is used
    Default: default DYNA4 car following model
    """

    car_following_minimum_front_distance: float = FloatField(
        "Driver.CarFollowing.MinimumFrontDistance", default=10.0)
    """Minimum allowed distance to front neighbor (measured from reference point to reference point) [m]
    """

    car_following_time_headway: float = FloatField("Driver.CarFollowing.TimeHeadway", default=1.8)
    """Time in [s] used for speed dependent distance control
    """

    car_following_distance_tolerance: float = FloatField("Driver.CarFollowing.DistanceTolerance",
                                                         default=3.0)
    """Tolerance for distance control in [m]
    """

    car_following_distance_control_gain: float = FloatField(
        "Driver.CarFollowing.DistanceControlGain", default=1.0)
    """Gain parameter for distance control based on relative speed
    """

    car_following_maximum_lateral_offset_to_leader: float = FloatField(
        "Driver.CarFollowing.MaximumLateralOffsetToLeader", default=2.0)
    """Maximum lateral offset between entity's and leader's reference points within that a potential collision is 
    detected [m] """

    # Required driver characteristics

    driver_constraints_longitudinal_speed: Any = MixedField("Driver.Constraints.LongitudinalSpeed",
                                                            [float, {
                                                                'None': None
                                                            }],
                                                            default=70.0)
    """Speed the driver is willing to drive in longitudinal direction"""

    driver_constraints_longitudinal_acceleration: Any = MixedField(
        "Driver.Constraints.LongitudinalAcceleration", [float, {
            'None': None
        }], default=3.0)
    """Longitudinal acceleration how the driver is willing to accelerate"""

    driver_constraints_longitudinal_deceleration: Any = MixedField(
        "Driver.Constraints.LongitudinalDeceleration", [float, {
            'None': None
        }], default=3.0)
    """Longitudinal deceleration how the driver is willing to decelerate"""

    driver_constraints_longitudinal_acceleration_rate: Any = MixedField(
        "Driver.Constraints.LongitudinalAccelerationRate", [float, {
            'None': None
        }], default=500.0)
    """Longitudinal acceleration rate how the driver is willing to adapt the acceleration"""

    driver_constraints_lateral_acceleration: Any = MixedField(
        "Driver.Constraints.LateralAcceleration", [float, {
            'None': None
        }], default=2.5)
    """Lateral acceleration how the driver is willing to accelerate"""

    # optional driver characteristics

    driver_constraints_longitudinal_deceleration_rate: Any = MixedField(
        "Driver.Constraints.LongitudinalDecelerationRate", [float, {
            'None': None
        }], default=-1)
    """Longitudinal deceleration rate how the driver is willing to adapt the deceleration"""

    driver_constraints_lateral_speed: Any = MixedField("Driver.Constraints.LateralSpeed",
                                                       [float, {
                                                           'None': None
                                                       }],
                                                       default=-1)
    """Speed the driver is willing to drive in lateral direction"""

    driver_constraints_lateral_deceleration: Any = MixedField(
        "Driver.Constraints.LateralDeceleration", [float, {
            'None': None
        }], default=-1)
    """Lateral deceleration how the driver is willing to decelerate"""

    driver_constraints_lateral_acceleration_rate: Any = MixedField(
        "Driver.Constraints.LateralAccelerationRate", [float, {
            'None': None
        }], default=-1)
    """Lateral acceleration rate how the driver is willing to adapt the lateral acceleration"""

    driver_constraints_lateral_deceleration_rate: Any = MixedField(
        "Driver.Constraints.LateralDecelerationRate", [float, {
            'None': None
        }], default=-1)
    """Lateral deceleration rate how the driver is willing to adapt the lateral deceleration"""

    pedestrian_speed: float = FloatField("Pedestrian.Speed", default=1.25)
    """average walking speed of a pedestrian"""
    """
    Properties for ego vehicle. Example usage in OSC 1.x:

    .. code-block:: XML

        <Properties>
            <Property name="Driver.SpeedControl" value="Automatic"/>
        </Properties>
    """

    ego_speed_control: SpeedControl = ChoiceField("Driver.SpeedControl", {
        "Exact": SpeedControl.EXACT,
        "Automatic": SpeedControl.AUTOMATIC
    },
                                                  default=SpeedControl.EXACT)
    """SpeedControl mode for Ego vehicle.
    Exact: The driver aims at reaching target speeds as exact as possible using the parameters of the ``Speed Control`` Module
    Automatic: Acceleration constraints, speed limits or leading vehicles are considered additionally as parameterized in the ``Reference Speed Computation`` Module
    """


class EntityProperties(Properties):
    """Properties for all OSC Entity classes"""

    animation_file: Optional[str] = PropertyField("AnimationFile", default=None)
    """Deprecated. DYNAanimation data file path.
    Only used for OpenSCENARIO 1.0. Replaced by `Vehicle.model3d` in OpenSCENARIO 1.1"""


class VehicleProperties(EntityProperties):
    """Properties for the OSC `Vehicle` class"""
    pass


class PedestrianProperties(EntityProperties):
    """Properties for the OSC `Pedestrian` class"""
    pass


class MiscObjectProperties(EntityProperties):
    """Properties for the OSC `MiscObject` class"""
    pass
