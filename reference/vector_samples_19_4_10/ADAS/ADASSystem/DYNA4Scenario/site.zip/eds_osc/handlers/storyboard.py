import logging
from typing import List
from xml.etree.ElementTree import Element

from dyna4.scenario import (Action, Condition, EmptyNode, Entity, Event, ExhaustiveOrCondition,
                            MetaData, Node, NodeGroup, NodeState, StatefulNodeGroup)
from eds_osc.instructions import IfInstruction
from eds_osc.model import Priority
from eds_osc.nodes import TRANSITION_SKIP_STANDBY, parallel, sequence, storyboard_element
from eds_osc.registry import XMLRegistry
from eds_osc.utils import int_or_one, to_bool

logger = logging.getLogger(__name__)


def register_storyboard_handlers(reg: XMLRegistry):
    """
    Handler functions for OpenSCENARIO storyboard elements (except actions and conditions)
    """
    from eds_osc.parser import OSCParser, ParsingStage

    @reg.register("Story")
    def handle_story(self: OSCParser, element: Element, name: str = None) -> Node:
        if name is None:
            raise AttributeError("'Story' requires a name")

        assert self.parsing_stage == ParsingStage.STORY
        logger.debug("Story: %s", name)
        self.name_mgr.add("story", name)

        act_nodes = self.handle_list(element.findall("Act"), namespace=name)

        if len(act_nodes) == 0:
            raise AttributeError("Expect at least 1 Act in a 'Story'")

        body = parallel(act_nodes, name=f"{name}.body")

        sb_element = storyboard_element(name, body)
        self.element_mgr[name] = sb_element
        return sb_element

    @reg.register("Act")
    def handle_act(self: OSCParser, element, name, namespace: str) -> Node:
        full_name = self.name_mgr.add("act", f"{namespace}::{name}")

        # start trigger
        start_trigger_node = self.handle(element.find("StartTrigger"),
                                         name=full_name + ".start_trigger")

        # maneuver groups (optional)
        group_nodes = self.handle_list(element.findall("ManeuverGroup"), namespace=full_name)
        body = parallel(group_nodes, name=f"{full_name}.body")

        sb_element = storyboard_element(full_name, body, in_node=start_trigger_node)
        self.element_mgr[full_name] = sb_element

        # stop trigger (optional)
        stop_trigger_elem = element.find("StopTrigger")
        if stop_trigger_elem is not None and len(stop_trigger_elem) > 0:
            stop_trigger_node = self.handle(element.find("StopTrigger"),
                                            name=full_name + ".stop_trigger")
            start_trigger_node.connect(stop_trigger_node)
            stop_action = Action(MetaData(full_name + ".Stop"), 0,
                                 lambda: sb_element.stop_and_continue(None, 0))
            stop_trigger_node.connect(stop_action)

        return sb_element

    @reg.register("ManeuverGroup", casts={"maximum_execution_count": int_or_one})
    def handle_maneuver_group(self: OSCParser,
                              element,
                              name,
                              namespace: str,
                              maximum_execution_count: int = 1) -> Node:
        full_name = self.name_mgr.add("maneuverGroup", f"{namespace}::{name}")

        actors = self.handle(element.find("Actors"))

        # load maneuvers from catalog (optional)
        maneuvers = self.handle_list(element.findall("CatalogReference"), types=["Maneuver"])
        # inline maneuvers (optional)
        maneuvers.extend(element.findall("Maneuver"))

        maneuver_nodes = self.handle_list(maneuvers, namespace=full_name, actors=actors)
        loop_body = parallel(maneuver_nodes, name=f"{full_name}.body")

        sb_element = storyboard_element(full_name, loop_body, iterations=maximum_execution_count)
        self.element_mgr[full_name] = sb_element
        return sb_element

    @reg.register("Actors", casts={"select_triggering_entities": to_bool})
    def handle_actors(self: OSCParser, element, select_triggering_entities: bool) -> List[Entity]:
        """
        Contains a list of EntityRef objects.
        """
        if select_triggering_entities:
            # TODO implement
            # this is probably hard to implement. See User guide v1.0 3.3.1 and v1.1 4.3.1
            logger.warning("Actors.select_triggering_entities is not implemented")
        return self.handle_list(element)

    @reg.register("EntityRef")
    def handle_entity_ref(self: OSCParser, element, entity_ref) -> Entity:
        """
        Actors -> EntityRef
        """
        return self.get_entity(entity_ref)

    @reg.register("Maneuver")
    def handle_maneuver(self: OSCParser, element, name, namespace: str,
                        actors: List[Entity]) -> Node:
        full_name = self.name_mgr.add("maneuver", f"{namespace}::{name}")

        # we need to tell each event about its sibling events
        # to do this, we pass this list to them that is populated afterwards
        sibling_events = []

        event_nodes = self.handle_list(element.findall("Event"),
                                       namespace=full_name,
                                       actors=actors,
                                       sibling_events=sibling_events)
        body = parallel(event_nodes, name=f"{full_name}.body")

        # use extend to keep the list instance!
        sibling_events.extend(event_nodes)

        sb_element = storyboard_element(full_name, body)
        self.element_mgr[full_name] = sb_element
        return sb_element

    @reg.register("Event", casts={"maximum_execution_count": int_or_one, "priority": Priority})
    def handle_event(self: OSCParser,
                     element: Element,
                     name,
                     priority: Priority,
                     namespace: str,
                     actors: List[Entity],
                     sibling_events: List[StatefulNodeGroup],
                     maximum_execution_count: int = 1) -> StatefulNodeGroup:
        full_name = self.name_mgr.add("event", f"{namespace}::{name}")

        sb_element = None

        start_trigger_element = element.find("StartTrigger")
        if start_trigger_element is not None and len(start_trigger_element) > 0:
            start_trigger_node: Node = self.handle(start_trigger_element,
                                                   name=full_name + ".start_trigger")
        else:
            # If no Event.StartTrigger or a StartTrigger with no ComponentGroup is specified, the Event should start
            # as soon as the surrounding Act's StartTrigger has triggered
            start_trigger_node = EmptyNode(MetaData(full_name + ".start_trigger"), 0)
        if priority == Priority.SKIP:
            cond_sibling_running = Condition(
                lambda: any(s.state == NodeState.RUNNING for s in sibling_events))
            if_sibling_running = IfInstruction.create_node(cond_sibling_running,
                                                           full_name + ".if_sibling_running")
            # use ~ to invert, as it calls the overloaded __invert__ operator of Condition
            if_not_sibling_running = IfInstruction.create_node(
                ~cond_sibling_running, full_name + ".if_not_sibling_running")

            start_trigger_node.connect(if_sibling_running)
            start_trigger_node.connect(if_not_sibling_running)
            if_sibling_running.connect(start_trigger_node)

            in_node = NodeGroup([start_trigger_node, if_sibling_running, if_not_sibling_running],
                                start_trigger_node, if_not_sibling_running,
                                MetaData(full_name + ".skip_handler"))
        else:
            in_node = start_trigger_node

        actions = self.handle_list(element.findall("Action"), namespace=full_name, actors=actors)
        body = parallel(actions, name=f"{full_name}.actions")

        if priority == Priority.OVERWRITE or priority == Priority.OVERRIDE:

            def stop_running_siblings():
                for e in sibling_events:
                    # only kill events that are actually running.
                    # standby events are still waiting for their trigger condition
                    if e != sb_element and e.state == NodeState.RUNNING:
                        e.stop_and_continue(None, 0)

            stopper = Action(MetaData(full_name + ".SiblingStopper"), 0, stop_running_siblings)
            body = sequence([stopper, body])

        sb_element = storyboard_element(full_name,
                                        body,
                                        in_node=in_node,
                                        iterations=maximum_execution_count)
        if priority == Priority.SKIP:
            # noinspection PyUnboundLocalVariable
            sb_element.add_transition(TRANSITION_SKIP_STANDBY, if_sibling_running)
        self.element_mgr[full_name] = sb_element
        return sb_element

    @reg.register("StartTrigger", "StopTrigger")
    def handle_trigger(self: OSCParser, element, name) -> Node:
        cond_groups = self.handle_list(element.findall("ConditionGroup"), namespace=name)
        if len(cond_groups) == 0 and element.tag == "StartTrigger":
            self.add_warning(f"StartTrigger {name} has no conditions and will never trigger")
        # a single condition must be fulfilled (OR)
        condition = ExhaustiveOrCondition.optimized(cond_groups)
        return Event(MetaData(name), 0, condition)
