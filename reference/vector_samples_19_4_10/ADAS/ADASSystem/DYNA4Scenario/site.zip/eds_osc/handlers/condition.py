import logging
from typing import List, Optional, Tuple
from xml.etree.ElementTree import Element

from dyna4.scenario import (AccelerationCondition, CollisionCondition, CompareCondition, Condition,
                            ConditionEdge, ConditionRule, DirectionalDimension, DistanceCondition,
                            DistanceReference, Entity, ExhaustiveAndCondition,
                            ExhaustiveOrCondition, NodeState, ObjectType, OSCCondition,
                            ParameterCondition, RelativeClearanceCondition, RelativeDistanceCondition, RelativeDistanceType,
                            RelativeLaneRange, RelativeSpeedCondition, RoutingAlgorithm, SignalValueCondition, SimulationTimeCondition,
                            SpeedCondition, StandStillCondition, StatefulNodeGroupCondition,
                            TimeHeadwayCondition, TimeToCollisionCondition,
                            TraveledDistanceCondition, VariableCondition, get_condition_edge,
                            get_condition_rule)
from eds_osc import constants
from eds_osc.nodes import (TRANSITION_END_COMPLETE, TRANSITION_SKIP_STANDBY,
                           TRANSITION_START_RUNNING, TRANSITION_STOP_COMPLETE)
from eds_osc.registry import XMLRegistry
from eds_osc.utils import to_bool

logger = logging.getLogger(__name__)


def register_condition_handlers(reg: XMLRegistry):
    """
    Handler functions for all conditions
    """
    from eds_osc.parser import OSCParser

    @reg.register("ConditionGroup")
    def handle_condition_group(self: OSCParser, element: Element, namespace: str) -> Condition:
        conditions = self.handle_list(element.findall("Condition"), namespace=namespace)
        # all conditions must be fulfilled (AND)
        return ExhaustiveAndCondition.optimized(conditions)

    #
    # Condition Implementations
    #
    @reg.register("Condition", casts={"delay": float, "condition_edge": get_condition_edge})
    def handle_condition(self: OSCParser, element: Element, name: str, delay: float,
                         condition_edge: ConditionEdge, namespace: str) -> Condition:
        # contains always one element
        full_name = self.name_mgr.add("condition", f"{namespace}::{name}")

        if element is None or len(element) == 0:
            raise AttributeError('Element "Condition" contains neither a "ByEntityCondition" nor a '
                                 '"ByValueCondition"')
        sub_condition: Element = element[0]

        self.current_condition_name = full_name
        condition = self.handle(sub_condition)
        self.current_condition_name = "<unknown>"
        osc_cond = OSCCondition(condition, delay, condition_edge, name)

        # A common OSC snippet uses conditionEdge="rising" in combination with simulation time greater than 0.000.
        # We need this workaround for that as long as we cannot fully access entities at t=0.000.
        # See also DYNA-16532
        if sub_condition.tag == "ByValueCondition" and len(sub_condition) > 0:
            sub_sub_condition = sub_condition[0]
            if sub_sub_condition.tag == "SimulationTimeCondition":
                value = float(sub_condition[0].attrib["value"])
                rule = get_condition_rule(sub_condition[0].attrib["rule"])

                if value == 0.0:
                    if rule in (ConditionRule.LESS_OR_EQUAL, ConditionRule.EQUAL_TO):
                        # trigger independent of edge
                        return Condition(lambda: True)
                    if rule == ConditionRule.GREATER_OR_EQUAL:
                        if condition_edge in (ConditionEdge.RISING,
                                              ConditionEdge.RISING_OR_FALLING):
                            return Condition(lambda: True)
                        if condition_edge is ConditionEdge.FALLING:
                            # never trigger
                            return Condition(lambda: False)

                if condition_edge != ConditionEdge.NONE:
                    # simulate the first two time steps
                    at_zero = CompareCondition(rule, lambda: 0.0, value).update()
                    at_one = CompareCondition(rule, lambda: 0.001, value).update()
                    trigger_falling = at_zero and (not at_one) and condition_edge in (
                        ConditionEdge.FALLING, ConditionEdge.RISING_OR_FALLING)
                    trigger_rising = (not at_zero) and at_one and condition_edge in (
                        ConditionEdge.RISING, ConditionEdge.RISING_OR_FALLING)

                    # if this condition would trigger, we set the flag to override default behavior
                    if trigger_falling or trigger_rising:
                        osc_cond.set_can_trigger_first_check(True)
            elif sub_sub_condition.tag == "StoryboardElementStateCondition":
                state = sub_sub_condition.attrib.get("state", "")
                sbe_type = sub_sub_condition.attrib.get("storyboardElementType", "")

                if sbe_type == "story" and state in ("runningState", "startTransition", "standbyState") \
                        and condition_edge == ConditionEdge.RISING:
                    self.add_warning(
                        f'StoryboardElementStateCondition "{full_name}" with type="story" and state="{state}" '
                        'will never trigger a rising edge. Consider changing the conditionEdge to "none" instead.'
                    )

        return Condition(osc_cond)

    #
    # ByEntityConditions
    #
    @reg.register("ByEntityCondition")
    def handle_by_entity_condition(self: OSCParser, element: Element) -> Condition:
        entities, rule = self.handle(element.find("TriggeringEntities"))
        condition_element = element.find("EntityCondition")
        # handle condition_element multiple times; for each entity once
        conditions = [self.handle(condition_element, entity=e) for e in entities]

        if rule == "any":
            return ExhaustiveOrCondition.optimized(conditions)
        else:  # all
            return ExhaustiveAndCondition.optimized(conditions)

    @reg.register("TriggeringEntities")
    def handle_triggering_entities(self: OSCParser, element: Element,
                                   triggering_entities_rule: str) -> Tuple[List[Entity], str]:
        """
        Returns a tuple:
        [0]: list of entities
        [1]: triggering rule (either "any" or "all")
        """
        entities = self.handle_list(element)
        return entities, triggering_entities_rule

    @reg.register("SpeedCondition",
                  casts={
                      "value": float,
                      "rule": get_condition_rule,
                      "direction": DirectionalDimension.parse
                  })
    def handle_speed_condition(
            self: OSCParser,
            element: Element,
            rule: ConditionRule,
            value: float,
            entity: Entity,
            direction: DirectionalDimension = DirectionalDimension.TOTAL) -> Condition:
        return SpeedCondition(rule, value, entity, direction)

    @reg.register("RelativeSpeedCondition", casts={"value": float, "rule": get_condition_rule})
    def handle_relative_speed_condition(self: OSCParser, element: Element, rule: ConditionRule,
                                        value: float, entity: Entity, entity_ref: str):
        return RelativeSpeedCondition(rule, value, entity, self.get_entity(entity_ref))

    @reg.register("AccelerationCondition",
                  casts={
                      "value": float,
                      "rule": get_condition_rule,
                      "direction": DirectionalDimension.parse
                  })
    def handle_acceleration_condition(
            self: OSCParser,
            element: Element,
            rule: ConditionRule,
            value: float,
            entity: Entity,
            direction: DirectionalDimension = DirectionalDimension.TOTAL) -> Condition:
        return AccelerationCondition(rule, value, entity, direction)

    @reg.register("StandStillCondition", casts={"duration": float})
    def handle_stand_still_condition(self: OSCParser, element: Element, duration: float,
                                     entity: Entity) -> Condition:
        return StandStillCondition(constants.TOLERANCE_STAND_STILL, entity, duration)

    @reg.register("TraveledDistanceCondition", casts={"value": float})
    def handle_traveled_distance_condition(self: OSCParser, element: Element, value: float,
                                           entity: Entity) -> Condition:
        return TraveledDistanceCondition(value, entity)

    def handle_preprocessing(relative_distance_type: Optional[RelativeDistanceType] = None,
                             coordinate_system: Optional[DistanceReference] = None,
                             along_route: Optional[bool] = None):
        if along_route:
            logger.warning("DistanceCondition.alongRoute is deprecated")

        if relative_distance_type == RelativeDistanceType.CARTESIAN_DISTANCE:
            logger.warning("RelativeDistanceType 'CartesianDistance' is deprecated")

        if coordinate_system is not None:
            coords = coordinate_system
        elif along_route:
            # fallback for OSC 1.0
            coords = DistanceReference.ROAD
        else:
            coords = DistanceReference.ENTITY

        if relative_distance_type is not None:
            dist_type = relative_distance_type
        elif along_route:
            # fallback for OSC 1.0
            dist_type = RelativeDistanceType.LONGITUDINAL
        else:
            dist_type = RelativeDistanceType.EUCLIDEAN_DISTANCE

        return coords, dist_type

    @reg.register("DistanceCondition",
                  casts={
                      "value": float,
                      "freespace": to_bool,
                      "along_route": to_bool,
                      "rule": get_condition_rule,
                      "routing_algorithm": RoutingAlgorithm.parse,
                      "relative_distance_type": RelativeDistanceType.parse,
                      "coordinate_system": DistanceReference.parse
                  })
    def handle_distance_condition(self: OSCParser,
                                  element: Element,
                                  value: float,
                                  freespace: bool,
                                  rule: ConditionRule,
                                  entity: Entity,
                                  routing_algorithm: Optional[
                                      RoutingAlgorithm] = RoutingAlgorithm.ASSIGNED_ROUTE_WITH_FALLBACK,
                                  relative_distance_type: Optional[RelativeDistanceType] = None,
                                  coordinate_system: Optional[DistanceReference] = None,
                                  along_route: Optional[bool] = None) -> Condition:
        coords, dist_type = handle_preprocessing(relative_distance_type, coordinate_system,
                                                 along_route)

        if routing_algorithm not in (RoutingAlgorithm.ASSIGNED_ROUTE, RoutingAlgorithm.ASSIGNED_ROUTE_WITH_FALLBACK):
            self.add_info(
                f"Routing with mode {routing_algorithm} might significantly decrease simulation performance.")

        return DistanceCondition(rule, value, entity, self.handle(element.find("Position")),
                                 freespace, dist_type, coords, routing_algorithm)

    @reg.register("RelativeDistanceCondition",
                  casts={
                      "value": float,
                      "freespace": to_bool,
                      "rule": get_condition_rule,
                      "routing_algorithm": RoutingAlgorithm.parse,
                      "relative_distance_type": RelativeDistanceType.parse,
                      "coordinate_system": DistanceReference.parse
                  })
    def handle_relative_distance_condition(
            self,
            element: Element,
            value: float,
            freespace: bool,
            rule: ConditionRule,
            entity: Entity,
            entity_ref: str,
            relative_distance_type: RelativeDistanceType,
            routing_algorithm: Optional[RoutingAlgorithm] = RoutingAlgorithm.ASSIGNED_ROUTE_WITH_FALLBACK,
            coordinate_system: DistanceReference = DistanceReference.ENTITY):
        if relative_distance_type == RelativeDistanceType.CARTESIAN_DISTANCE:
            logger.warning("RelativeDistanceType 'CartesianDistance' is deprecated")

        if routing_algorithm not in (RoutingAlgorithm.ASSIGNED_ROUTE, RoutingAlgorithm.ASSIGNED_ROUTE_WITH_FALLBACK):
            self.add_info(
                f"Routing with mode {routing_algorithm} might significantly decrease simulation performance.")

        return RelativeDistanceCondition(rule, value, entity, self.get_entity(entity_ref),
                                         freespace, relative_distance_type, coordinate_system, routing_algorithm)

    @reg.register("ReachPositionCondition", casts={"tolerance": float})
    def handle_reach_position_condition(self: OSCParser, element: Element, tolerance: float,
                                        entity: Entity) -> Condition:
        return handle_distance_condition(self, element, tolerance, False, ConditionRule.LESS_THAN,
                                         entity)

    @reg.register("CollisionCondition")
    def handle_collision_condition(self: OSCParser, element: Element, entity: Entity):
        entity_ref = self.handle(element.find("EntityRef"))
        if entity_ref is not None:
            return CollisionCondition(entity, entity_ref)
        object_type = self.handle(element.find("ByType"))
        if object_type is not None:
            return CollisionCondition(entity, object_type)
        raise ValueError("Either entity_ref or object_type must be provided")

    @reg.register("ByType", casts={"type": ObjectType.parse})
    def handle_type(self: OSCParser, element, type: ObjectType) -> ObjectType:
        return type

    @reg.register("TimeToCollisionConditionTarget")
    def handle_type(self: OSCParser, element):
        entity_ref = self.handle(element.find("EntityRef"))
        if entity_ref is not None:
            return entity_ref
        position = self.handle(element.find("Position"))
        if position is not None:
            return position
        else:
            raise ValueError("Either entity_ref or position must be provided")

    @reg.register("TimeToCollisionCondition",
                  casts={
                      "value": float,
                      "freespace": to_bool,
                      "along_route": to_bool,
                      "rule": get_condition_rule,
                      "routing_algorithm": RoutingAlgorithm.parse,
                      "relative_distance_type": RelativeDistanceType.parse,
                      "coordinate_system": DistanceReference.parse
                  })
    def handle_time_to_collision_condition(self: OSCParser,
                                           element: Element,
                                           value: float,
                                           freespace: bool,
                                           rule: ConditionRule,
                                           entity: Entity,
                                           routing_algorithm: Optional[
                                               RoutingAlgorithm] = RoutingAlgorithm.ASSIGNED_ROUTE_WITH_FALLBACK,
                                           relative_distance_type: RelativeDistanceType = None,
                                           coordinate_system: DistanceReference = None,
                                           along_route: Optional[bool] = None):
        coords, dist_type = handle_preprocessing(relative_distance_type, coordinate_system,
                                                 along_route)
        if dist_type == RelativeDistanceType.LATERAL:
            dist_type = RelativeDistanceType.EUCLIDEAN_DISTANCE
            logger.warning(
                "RelativeDistanceType 'Lateral' will be handled using the euclidean distance")

        if routing_algorithm not in (RoutingAlgorithm.ASSIGNED_ROUTE, RoutingAlgorithm.ASSIGNED_ROUTE_WITH_FALLBACK):
            self.add_info(
                f"Routing with mode {routing_algorithm} might significantly decrease simulation performance.")

        return TimeToCollisionCondition(rule, value, entity,
                                        self.handle(element.find("TimeToCollisionConditionTarget")),
                                        freespace, dist_type, coords, routing_algorithm)

    @reg.register("TimeHeadwayCondition",
                  casts={
                      "value": float,
                      "freespace": to_bool,
                      "along_route": to_bool,
                      "rule": get_condition_rule,
                      "routing_algorithm": RoutingAlgorithm.parse,
                      "relative_distance_type": RelativeDistanceType.parse,
                      "coordinate_system": DistanceReference.parse
                  })
    def handle_time_headway_condition(self: OSCParser,
                                      element: Element,
                                      value: float,
                                      freespace: bool,
                                      rule: ConditionRule,
                                      entity: Entity,
                                      entity_ref: str,
                                      routing_algorithm: Optional[
                                          RoutingAlgorithm] = RoutingAlgorithm.ASSIGNED_ROUTE_WITH_FALLBACK,
                                      relative_distance_type: RelativeDistanceType = None,
                                      coordinate_system: DistanceReference = None,
                                      along_route: Optional[bool] = None):
        coords, dist_type = handle_preprocessing(relative_distance_type, coordinate_system,
                                                 along_route)
        if dist_type == RelativeDistanceType.LATERAL:
            dist_type = RelativeDistanceType.EUCLIDEAN_DISTANCE
            logger.warning(
                "RelativeDistanceType 'Lateral' will be handled using the euclidean distance")

        if routing_algorithm not in (RoutingAlgorithm.ASSIGNED_ROUTE, RoutingAlgorithm.ASSIGNED_ROUTE_WITH_FALLBACK):
            self.add_info(
                f"Routing with mode {routing_algorithm} might significantly decrease simulation performance.")

        return TimeHeadwayCondition(rule, value, entity, self.get_entity(entity_ref), freespace,
                                    dist_type, coords, routing_algorithm)

    @reg.register("RelativeLaneRange", casts={"from_": int, "to": int})
    def handle_relative_lane_range(parser: OSCParser, element: Element, from_: int,
                                   to: int) -> RelativeLaneRange:
        """
        Relative lane range.
        """
        return RelativeLaneRange(from_, to)

    def relative_clearance_validator(parser: OSCParser, element: Element, free_space: bool, opposite_lanes: bool, distance_backward: float = 0.0, distance_forward: float = 0.0):
        if distance_backward < 0.0:
            parser.add_warning("The property 'distanceBackward' must be non-negative; therefore, the distance is set to 0.0.")
        if distance_forward < 0.0:
            parser.add_warning("The property 'distanceForward' must be non-negative; therefore, the distance is set to 0.0.")

    @reg.register("RelativeClearanceCondition",
                  casts={
                      "free_space": to_bool,
                      "opposite_lanes": to_bool,
                      "distance_backward": float,
                      "distance_forward": float
                  },
                  validator=relative_clearance_validator)
    def handle_relative_clearance_condition(parser: OSCParser, element: Element, entity: Entity,
                                            free_space: bool, opposite_lanes: bool,
                                            distance_backward: float = 0.0, distance_forward: float = 0.0):
        if distance_backward < 0.0:
            distance_backward = 0.0
        if distance_forward < 0.0:
            distance_forward = 0.0

        entity_names = [e.attrib['entityRef'] for e in element.findall("EntityRef")]
        # Todo DYNA-1803: Convert to error marker
        if not all([parser.has_entity(entity_name) for entity_name in entity_names]):
            error_msg = "The RelativeClearanceCondition refers to entities that are not declared in the scenario."
            logger.error(error_msg)
            raise ValueError(error_msg)
        entity_refs = [parser.get_entity(e) for e in entity_names]

        relative_lane_ranges_e = element.findall("RelativeLaneRange")
        for relative_lane_range_e in relative_lane_ranges_e:
            relative_lane_range_e.attrib['from_'] = relative_lane_range_e.attrib.pop('from')
        relative_lane_ranges = parser.handle_list(relative_lane_ranges_e)

        return RelativeClearanceCondition(entity, free_space, opposite_lanes, distance_backward,
                                          distance_forward, entity_refs, relative_lane_ranges)

    #
    # ByValue Conditions
    #
    @reg.register("SimulationTimeCondition", casts={"value": float, "rule": get_condition_rule})
    def handle_simulation_time_condition(self: OSCParser, element: Element, value: float,
                                         rule: ConditionRule) -> Condition:
        """
        Condition -> ByValueCondition -> SimulationTimeCondition
        """
        return SimulationTimeCondition(rule, value)

    @reg.register("StoryboardElementStateCondition")
    def handle_element_state_condition(self: OSCParser, element: Element,
                                       storyboard_element_type: str, storyboard_element_ref: str,
                                       state: str) -> Condition:
        """
        Condition -> ByValueCondition -> StoryboardElementStateCondition
        """
        if state == "completeState":
            arg = NodeState.COMPLETE
        elif state == "runningState":
            arg = NodeState.RUNNING
        elif state == "standbyState":
            arg = NodeState.STANDBY
        elif state == "startTransition":
            arg = TRANSITION_START_RUNNING
        elif state == "stopTransition":
            arg = TRANSITION_STOP_COMPLETE
        elif state == "skipTransition":
            arg = TRANSITION_SKIP_STANDBY
        elif state == "endTransition":
            # endTransition also matches TRANSITION_END_STANDBY
            # this is handled by StatefulNodeGroupCondition
            # so we can pass either of them as arg
            arg = TRANSITION_END_COMPLETE
        else:
            raise NotImplementedError(f"StateCondition for {state} not supported")

        sngc = StatefulNodeGroupCondition(arg)
        # calling set_group must be delayed until parsing is complete
        # to ensure that the target storyboard element has been parsed
        self.post_parsing_callbacks.append(lambda: sngc.set_group(
            self.get_storyboard_element(storyboard_element_type, storyboard_element_ref)))
        return Condition(sngc)

    @reg.register("ParameterCondition", casts={"rule": get_condition_rule})
    def handle_parameter_condition(parser: OSCParser, element: Element, parameter_ref: str,
                                   value: str, rule: ConditionRule) -> Condition:
        var = parser.parameters[parameter_ref]

        return ParameterCondition(var, rule, value)

    @reg.register("VariableCondition", casts={"rule": get_condition_rule})
    def handle_variable_condition(parser: OSCParser, element: Element, variable_ref: str,
                                  value: str, rule: ConditionRule) -> Condition:
        var = parser.variables[variable_ref]

        return VariableCondition(var, rule, value)

    @reg.register("UserDefinedValueCondition", casts={"rule": get_condition_rule})
    def handle_user_defined_value_condition(self: OSCParser, element: Element, name: str,
                                            value: str, rule: ConditionRule) -> Condition:
        """
        DYNA4-specific conditions.
        Format of attribute `name`: "prefix:body".
        The prefix determines the interpretation of the body.

        * Matlab Signal Block
            * Prefix "signal:"
            * Body: accessId
            * Example:

            .. code-block:: XML

                <UserDefinedValueCondition name="signal:Some.AccessId[m]" rule="greaterThan" value="4.5"/>
        """
        if ":" not in name:
            raise AttributeError("Missing prefix in UserDefinedValueCondition.name")

        prefix, body = name.split(":", 1)

        if prefix == "signal":
            return SignalValueCondition(rule, body, float(value))
        else:
            raise AttributeError(f"Unknown prefix '{prefix}' for UserDefinedValueCondition")

    # endregion conditions
