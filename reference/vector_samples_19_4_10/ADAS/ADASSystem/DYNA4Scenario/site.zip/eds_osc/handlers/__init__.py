from .action import register_action_handlers
from .condition import register_condition_handlers
from .entity import register_entity_handlers
from .osc import register_osc_handlers
from .position import register_position_handlers
from .private_action import register_private_action_handlers
from .storyboard import register_storyboard_handlers
from .trajectory import register_trajectory_handlers
from ..registry import XMLRegistry


def register_all_handlers(reg: XMLRegistry):
    register_action_handlers(reg)
    register_condition_handlers(reg)
    register_entity_handlers(reg)
    register_osc_handlers(reg)
    register_position_handlers(reg)
    register_private_action_handlers(reg)
    register_storyboard_handlers(reg)
    register_trajectory_handlers(reg)
