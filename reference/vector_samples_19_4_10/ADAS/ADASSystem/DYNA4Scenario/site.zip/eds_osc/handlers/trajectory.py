from typing import List, Optional, Tuple
from xml.etree.ElementTree import Element

from dyna4.scenario import (ClothoidTrajectory, ICoordinates, InterpolatedClothoidTrajectory,
                          InterpolatedNurbsTrajectory, InterpolatedPolylineTrajectory, ITrajectory,
                          MotionModel, NurbsTrajectory, PolylineTrajectory, TrajectoryTiming)
from eds_osc.registry import XMLRegistry
from eds_osc.utils import to_bool


def register_trajectory_handlers(reg: XMLRegistry):
    """
    Handler functions for trajectory classes
    """
    @reg.register("TrajectoryFollowingMode")
    def handle_trajectory_following_mode(self, element: Element,
                                         following_mode: str) -> MotionModel:
        return MotionModel.parse(following_mode)

    @reg.register("Timing", casts={"offset": float, "scale": float})
    def handle_timing(self, element: Element, domain_absolute_relative: str, offset: float,
                      scale: float) -> TrajectoryTiming:
        if scale <= 0:
            raise ValueError("Timing.scale must be larger than zero")
        return TrajectoryTiming(domain_absolute_relative.lower() == "absolute", offset, scale)

    @reg.register("TimeReference")
    def handle_time_reference(self, element: Element) -> Optional[TrajectoryTiming]:
        timing = element.find("Timing")
        if timing is not None:
            return self.handle(timing)
        return None

    @reg.register("Trajectory", casts={"closed": to_bool})
    def handle_trajectory(self, element: Element, closed: bool, name: str) -> ITrajectory:

        el = element.find("Shape")[0]
        if el.tag in ("Clothoid", "Nurbs", "Polyline"):
            return self.handle(el, name=name)
        else:
            raise NotImplementedError(
                f'Shape in Trajectory must be "Polyline", "Clothoid" or "Nurbs" but was "{el.tag}".'
            )

    @reg.register("Vertex", casts={"time": float})
    def handle_vertex(
            self,
            element: Element,
            time: Optional[float] = None) -> Tuple[ICoordinates, Optional[float]]:  # position, time

        position: Optional[ICoordinates] = self.handle(element.find("Position"))
        if not position:
            raise AttributeError('Tag "Position" in "Vertex" does not exist but is required.')

        return position, time

    @reg.register("Polyline")
    def handle_polyline(self, element: Element, name: str) -> ITrajectory:
        vertices_handler: List[Tuple] = self.handle_list(element.findall("Vertex"))

        if len(vertices_handler) < 2:
            raise AttributeError(
                'Expected to have at least 2 child tags from type "Vertex" in Polyline.')

        # convert list of tuples into multiple lists: [(0,1,2), (3,4,5)] -> [[0,3], [1,4], [2,5]]
        unzipped = list(map(list, zip(*vertices_handler)))

        vertex_positions: List[ICoordinates] = unzipped[0]
        times: List[Optional[float]] = unzipped[1]

        if None in times and any(isinstance(x, float) for x in times):
            raise AttributeError(
                'Either all or none of the Vertices in Polyline require the optional attribute "time".'
            )

        if None in times:  # time should be ignored
            return PolylineTrajectory(name, vertex_positions)
        else:
            timed_vertex_positions = list(zip(times, vertex_positions))
            return InterpolatedPolylineTrajectory(name, timed_vertex_positions)

    @reg.register("Nurbs", casts={"order": int})
    def handle_nurbs(self, element: Element, name: str, order: int) -> ITrajectory:
        knot_vector: List[float] = self.handle_list(element.findall("Knot"))
        control_point_handler: List[Tuple] = self.handle_list(element.findall("ControlPoint"))

        if order < 2:
            raise AttributeError('Attribute "order<" in Nurbs must be greater or equal to 2.')

        if len(control_point_handler) == 0 or len(knot_vector) == 0:
            raise AttributeError(
                'Expected to have at least 2 child tags from type "controlPoint" and "Knot" in Nurbs.'
            )

        # convert list of tuples into multiple lists: [(0,1,2), (3,4,5)] -> [[0,3], [1,4], [2,5]]
        unzipped = list(map(list, zip(*control_point_handler)))

        control_point_positions: List[ICoordinates] = unzipped[0]
        times: List[Optional[float]] = unzipped[1]
        weights: List[Optional[float]] = unzipped[2]

        if len(control_point_positions) < order:
            raise ValueError(f'Number of "ControlPoints"(={len(control_point_positions)}) must be'
                             f' greater or equal to "order"(={order}).')

        if len(knot_vector) != order + len(control_point_positions):
            raise ValueError(
                f'Number of "Knots"(={len(knot_vector)}) must be equal to the number of control points'
                f' (={len(control_point_positions)}) plus the order (={order}) of the curve.')

        if None in weights and any(isinstance(x, float) for x in weights):
            raise AttributeError(
                'Either all or none of the ControlPoints in Nurbs require the optional attribute "weight".'
            )

        if None in times and any(isinstance(x, float) for x in times):
            raise AttributeError(
                'Either all or none of the ControlPoints in Nurbs require the optional attribute "time".'
            )

        if knot_vector != sorted(knot_vector):
            raise AttributeError('Components of attribute knots in Nurbs must be ascending.')

        # compare first and last element in sublist is enough because list is sorted
        if knot_vector[order - 1] != knot_vector[0]:
            raise AttributeError(
                f'The first {order}(=order) knots in Nurbs must have the same value.')

        if knot_vector[-order] != knot_vector[-1]:
            raise AttributeError(
                f'The last {order}(=order) knots in Nurbs must have the same value.')

        if None in weights:  # set all weights to 1 if
            weights = [1 for i in range(len(weights))]

        if None in times:  # time should be ignored
            return NurbsTrajectory(name=name,
                                   order=order,
                                   control_points=control_point_positions,
                                   knot_vector=knot_vector,
                                   weights=weights)

        else:
            timed_control_points = list(zip(times, control_point_positions))
            return InterpolatedNurbsTrajectory(name=name,
                                               order=order,
                                               supporting_control_points=timed_control_points,
                                               knot_vector=knot_vector,
                                               weights=weights)

    @reg.register("Knot", casts={"value": float})
    def handle_knot(self, element: Element, value: float) -> float:
        return value

    @reg.register("ControlPoint", casts={"time": float, "weight": float})
    def handle_control_point(
        self,
        element: Element,
        time: Optional[float] = None,
        weight: Optional[float] = None
    ) -> Tuple[ICoordinates, Optional[float], Optional[float]]:  # position, time, weight

        position: Optional[ICoordinates] = self.handle(element.find("Position"))
        if not position:
            raise AttributeError('Tag "Position" in "ControlPoint" does not exist but is required.')

        return position, time, weight

    @reg.register("Clothoid",
                  casts={
                      "curvature": float,
                      "curvatureDot": float,
                      "curvaturePrime": float,
                      "length": float,
                      "startTime": float,
                      "stopTime": float
                  })
    def handle_clothoid(self,
                        element: Element,
                        name: str,
                        curvature: float,
                        length: float,
                        curvature_prime: float = 0,
                        curvature_dot: Optional[float] = None,
                        start_time: Optional[float] = None,
                        stop_time: Optional[float] = None):

        position: ICoordinates = self.handle(element.find("Position"))
        curvature_prime = float(curvature_prime)

        if length <= 0:
            raise AttributeError(
                f'Attribute length in Clothoid must be greater than 0 but was {length}.')

        if curvature_dot:
            raise NotImplementedError(
                'Attribute "curvatureDot" in Clothoid is deprecated and not supported anymore.'
                'Use attribute "curvaturePrime" instead.')

        if start_time is None and stop_time:
            raise AttributeError(
                'Optional attribute "stopTime" in Clothoid can\'t be declared without a declaration of '
                'attribute "startTime"')
        elif start_time and stop_time is None:
            raise AttributeError(
                'Optional attribute "startTime" in Clothoid can\'t be declared without a declaration of '
                'attribute "stopTime"')
        elif stop_time is None and start_time is None:
            return ClothoidTrajectory(name=name,
                                      start_curvature=curvature,
                                      start_curvature_prime=curvature_prime,
                                      length=length,
                                      start_position=position)
        else:  # both start and stop time are given
            start_time = float(start_time)
            stop_time = float(stop_time)

            if stop_time <= start_time:
                raise AttributeError(
                    f'Attribute "stopTime"={stop_time} in Clothoid can\'t be less or'
                    f' equal to attribute "startTime"={start_time}.')

            if start_time < 0:
                raise AttributeError(
                    f'Attribute "startTime" in Clothoid can\'t be less than 0, but was {start_time}'
                )

            return InterpolatedClothoidTrajectory(name=name,
                                                  start_curvature=curvature,
                                                  start_curvature_prime=curvature_prime,
                                                  length=length,
                                                  start_position=position,
                                                  start_time=start_time,
                                                  stop_time=stop_time)
