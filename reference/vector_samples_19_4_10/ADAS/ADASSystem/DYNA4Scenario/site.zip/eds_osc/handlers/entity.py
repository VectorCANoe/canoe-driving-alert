import logging
from pathlib import Path
from typing import List, Optional
from xml.etree.ElementTree import Element

from dyna4.scenario import (Axle, AxleSystem, CarFollowing, Driver, DriverConstraints,
                            EntityConfiguration, IAxle, IAxleSystem, MotionModel, ObjectDimensions,
                            PedestrianDimensions, PedestrianModel, PerformanceLimits,
                            SpeedLimitAdherence, VehicleDimensions)
from eds_osc.model import BoundingBox, CarFollowingModel, SpeedControl
from eds_osc.properties import (ControllerProperties, EntityProperties, MiscObjectProperties,
                                PedestrianProperties, VehicleProperties)
from eds_osc.registry import XMLRegistry

logger = logging.getLogger(__name__)


def register_entity_handlers(reg: XMLRegistry):
    """
    Handler functions for all tags that are related to entity-definition and -creation
    """
    from eds_osc.parser import OSCParser

    @reg.register("Entities")
    def handle_entities(self: OSCParser, element: Element):
        self.handle_list(element)

        if self.ego_entity_ref == "":
            # do not throw an exception if the ego entity string is empty
            # the eds apply function will check later whether an entity is required
            return

        if self.ego_entity_ref not in self.entity_configs:
            names = [e[0] for e in self.entity_configs]
            self.marker_list.add_error_marker(
                str(self.filename),
                f"Specified ego entity '{self.ego_entity_ref}' was not found in the OpenSCENARIO file. Available "
                f"entities: {names}.\n "
                "Possible fixes:\n"
                "1. Specify a valid OpenSCENARIO entity name.\n"
                "2. If you want to run without ego entity, leave the ego entity name in DYNA4 empty (requires a model "
                "that supports to simulate without ego entity).\n"
                "3. Define an ego entity in an additional python scenario file.")

    @reg.register("ScenarioObject")
    def handle_scenario_object(self: OSCParser, element, name):
        # always contains 1 "EntityObject" subclass (or a reference to it)
        # can contain 1 "ObjectController"

        controller_props = None
        entity_object = None

        for child in element:
            if child.tag == "CatalogReference":
                # resolve catalog reference
                child = self.handle(child, types=["Vehicle", "Pedestrian", "MiscObject"])

            if child.tag in "ObjectController":
                controller_props = self.handle(child)
            else:
                entity_object = child

        if controller_props is None:
            controller_props = ControllerProperties(self.marker_list)

        if entity_object is None:
            self.marker_list.add_error_marker(
                str(self.filename),
                "'ScenarioObject' does not contain any entity object of ('Vehicle', 'Pedestrian', 'MiscObject', "
                "'CatalogReference', 'ExternalObjectReference') ")
            return

        config: EntityConfiguration = self.handle(entity_object,
                                                  object_name=name,
                                                  controller_props=controller_props)

        if config is None:
            return  # skip invalid configurations (e.g. deprecated categories)

        self.entity_configs.add(name, config)

    def is_database_relative_path(path_value):
        return str(path_value).startswith('cms:\\$(database)\\')

    def check_for_dapx_file(self: OSCParser,
                            prop_name: str,
                            path_value: Path,
                            marker_prefix="",
                            add_warning=True):
        """
        @return True if the path_value contains a file with .dapx suffix
        """

        if path_value.suffix == '.dapx':
            return True

        if add_warning:
            self.marker_list.add_warning_marker(
                str(self.filename),
                f"{marker_prefix}: Specified {prop_name} '{path_value.name}' is not supported and ignored. For "
                f"proper visualization, please specify a valid '.dapx' file. ")

        return False

    def get_animation_file(self: OSCParser, element: Element, name: str, object_name: str,
                           props: EntityProperties, model3d: Optional[str]) -> str:
        """
        Handling of OSC 'model3d' and DYNA4-specific 'AnimationFile' property:
        It is possible to specify a dapx-file either via the 'model3d' property (suggested attribute by OSC standard) or
        via a DYNA4-specific property 'AnimationFile'.
        Both variants to specify a dapx-file are supported in DYNA4.
        Since other tools will provide xosc files with already filled 'model3d' entries (which are tool-specific),
        we allow to overrule such entries in DYNA4 by specifying an additional 'AnimationFile' entry.
        This ensures that original parts of the xosc file can remain unchanged. Just in case that dapx files are
        specified in 'model3d' and 'AnimationFile' for the same scenario object, a warning will be logged and the
        overruling 'AnimationFile' property takes precedence
        """

        marker_prefix = f"ScenarioObject '{object_name}' ('{name}')"

        # check if a property with name 'AnimationFile' is specified. If this is the case, it takes precedence over
        # 'model3d'
        if props is not None and props.animation_file is not None:
            dapx_path = Path(props.animation_file)
            if not check_for_dapx_file(self, f"property '{EntityProperties.animation_file}'",
                                       dapx_path, marker_prefix):
                dapx_path = None
        else:
            dapx_path = None

        # if 'AnimationFile' property was not specified, but a 'model3d' attribute, check if the latter is a valid
        # '.dapx' file
        if model3d is not None:
            if dapx_path is None:
                dapx_path = Path(model3d)
                if not check_for_dapx_file(self, "attribute 'model3d'", dapx_path, marker_prefix):
                    dapx_path = None
            elif dapx_path is not None:
                # both valid model3d dapx and property dapx specified
                if check_for_dapx_file(self, "attribute 'model3d'", Path(model3d), "", False):
                    self.marker_list.add_warning_marker(
                        str(self.filename),
                        f"{marker_prefix}: Both entity attribute 'model3d' and property '{EntityProperties.animation_file}' are defined. "
                        f"Ignoring 'model3d'.")

        if dapx_path is None:
            return ""  # ensures that bounding objects are visualized instead

        if is_database_relative_path(dapx_path):
            return str(dapx_path)
        elif not dapx_path.is_absolute():
            # interpret as relative path
            dapx_path = self.relative_path_for_element(element, dapx_path)

        return str(dapx_path)

    @reg.register("Pedestrian",
                  casts={
                      "mass": float,
                      "pedestrian_category": EntityConfiguration.CategoryType.parse
                  })
    def handle_pedestrian(self: OSCParser,
                          element: Element,
                          name: str,
                          pedestrian_category: str,
                          mass: float,
                          object_name: str,
                          controller_props: ControllerProperties,
                          model3d: Optional[str] = None,
                          model: Optional[str] = None) -> EntityConfiguration:
        props: PedestrianProperties = self.handle(element.find("Properties"),
                                                  klass=PedestrianProperties,
                                                  context_info=f"Pedestrian '{name}'")
        if model is not None:
            self.add_warning(
                "Attribute 'model' in 'Pedestrian' is deprecated and will be ignored. Use 'model3d' instead."
            )

        bbox: BoundingBox = self.handle(element.find("BoundingBox"))

        config = EntityConfiguration()
        config.category_type = pedestrian_category
        config.object_dimensions = PedestrianDimensions(bbox.dimensions, bbox.center)
        config.pedestrian_model = PedestrianModel(speed=controller_props.pedestrian_speed)
        config.controller_type = EntityConfiguration.ControllerType.DYNA4_TRAFFIC
        config.motion_model = MotionModel.EXACT
        config.animation_file = get_animation_file(self, element, name, object_name, props, model3d)

        return config

    @reg.register("MiscObject",
                  casts={
                      "mass": float,
                      "misc_object_category": EntityConfiguration.CategoryType.parse
                  })
    def handle_misc_object(self: OSCParser,
                           element: Element,
                           name: str,
                           misc_object_category: EntityConfiguration.CategoryType,
                           mass: float,
                           object_name: str,
                           controller_props: ControllerProperties,
                           model3d: Optional[str] = None) -> EntityConfiguration:
        if misc_object_category == EntityConfiguration.CategoryType.WIND:
            self.add_info(
                "'MiscObject' with categoryType 'WIND' is deprecated and will be ignored.")
            return None

        props: MiscObjectProperties = self.handle(element.find("Properties"),
                                                  klass=MiscObjectProperties,
                                                  context_info=f"MiscObject '{name}'")

        bbox: BoundingBox = self.handle(element.find("BoundingBox"))

        config = EntityConfiguration()
        config.category_type = misc_object_category
        config.object_dimensions = ObjectDimensions(bbox.dimensions, bbox.center)
        config.controller_type = EntityConfiguration.ControllerType.DYNA4_TRAFFIC
        config.motion_model = MotionModel.EXACT
        config.animation_file = get_animation_file(self, element, name, object_name, props, model3d)

        return config

    @reg.register("Vehicle",
                  casts={
                      "mass": float,
                      "vehicle_category": EntityConfiguration.CategoryType.parse
                  })
    def handle_vehicle(self: OSCParser,
                       element: Element,
                       name: str,
                       vehicle_category: EntityConfiguration.CategoryType,
                       object_name: str,
                       controller_props: ControllerProperties,
                       model3d: Optional[str] = None,
                       mass: Optional[float] = None,
                       role: Optional[str] = None) -> EntityConfiguration:
        """
        :param element: XML element
        :param name: Name of the general vehicle name (e.g. in the catalog)
        :param vehicle_category: Category of the vehicle (car, truck, trailer, ...)
        :param object_name: Name of the concrete vehicle entity
        :param controller_props: additional key-value pairs for the entity's controller
        :param model3d: optional model file path for visualization (since OSC 1.1)
        :param mass: optional mass of the vehicle
        :param role: optional role of the vehicle
        """
        props: VehicleProperties = self.handle(element.find("Properties"),
                                               klass=VehicleProperties,
                                               context_info=f"Vehicle '{name}'")

        bbox: BoundingBox = self.handle(element.find("BoundingBox"))

        axle_system = self.handle(element.find("Axles"))

        if axle_system is None:
            raise AttributeError("'Vehicle' does not contain axles")

        performance_element = element.find("Performance")

        if vehicle_category in [
                EntityConfiguration.CategoryType.BICYCLE, EntityConfiguration.CategoryType.MOTORBIKE
        ]:
            for axle in axle_system.axles:
                axle.number_of_wheels = 1

        config = EntityConfiguration()
        config.category_type = vehicle_category
        config.object_dimensions = VehicleDimensions(bbox.dimensions, bbox.center, axle_system)

        if performance_element is not None:
            config.performance_limits = self.handle(performance_element)
        else:
            config.performance_limits = PerformanceLimits()

        if object_name == self.ego_entity_ref:
            config.controller_type = EntityConfiguration.ControllerType.DYNA4_VEHICLE_MODEL
        else:
            if controller_props.car_following_model is CarFollowingModel.DEFAULT:
                car_following = CarFollowing(
                    minimum_front_distance=controller_props.car_following_minimum_front_distance,
                    time_headway=controller_props.car_following_time_headway,
                    distance_tolerance=controller_props.car_following_distance_tolerance,
                    distance_control_gain=controller_props.car_following_distance_control_gain,
                    maximum_lateral_offset_to_leader=controller_props.
                    car_following_maximum_lateral_offset_to_leader)
            elif controller_props.car_following_model is CarFollowingModel.NONE:
                car_following = None
            else:
                raise AttributeError("Unsupported property for CarFollowing.Model")

            constraints = DriverConstraints(
                longitudinal_speed=controller_props.driver_constraints_longitudinal_speed,
                longitudinal_acceleration=controller_props.
                driver_constraints_longitudinal_acceleration,
                longitudinal_deceleration=controller_props.
                driver_constraints_longitudinal_deceleration,
                acceleration_rate=controller_props.
                driver_constraints_longitudinal_acceleration_rate,
                lateral_acceleration=controller_props.driver_constraints_lateral_acceleration)

            # overwrite with option parameters
            # (!) do not change the ordering
            prop = controller_props.driver_constraints_longitudinal_deceleration_rate
            if prop is None or prop >= 0:
                constraints.longitudinal.maximum_deceleration_rate = prop

            prop = controller_props.driver_constraints_lateral_speed
            if prop is None or prop >= 0:
                constraints.lateral.maximum_speed = prop

            prop = controller_props.driver_constraints_lateral_acceleration_rate
            if prop is None or prop >= 0:
                # set acceleration and deceleration synchronously
                constraints.lateral.maximum_acceleration_rate = prop
                constraints.lateral.maximum_deceleration_rate = prop

            prop = controller_props.driver_constraints_lateral_deceleration_rate
            if prop is None or prop >= 0:
                # overwrite if explicitly specified
                constraints.lateral.maximum_deceleration_rate = prop

            prop = controller_props.driver_constraints_lateral_deceleration
            if prop is None or prop >= 0:
                # overwrite if explicitly specified
                constraints.lateral.maximum_deceleration = prop

            config.add_to_scenario = False
            config.driver = Driver(
                constraints=constraints,
                speed_limit_adherence=SpeedLimitAdherence(controller_props.speed_limit_adherence),
                car_following=car_following,
                can_use_non_drivable_lanes=controller_props.can_use_non_drivable_lanes,
                preview_time=controller_props.preview_time)

            config.animation_file = get_animation_file(self, element, name, object_name, props,
                                                       model3d)

        if config.controller_type == EntityConfiguration.ControllerType.DYNA4_VEHICLE_MODEL:
            if controller_props.ego_speed_control == SpeedControl.EXACT:
                config.motion_model = MotionModel.EXACT
            else:
                config.motion_model = MotionModel.SMOOTH
        else:
            config.motion_model = controller_props.motion_model

        return config

    @reg.register("Performance",
                  casts={
                      "max_speed": float,
                      "max_acceleration": float,
                      "max_deceleration": float,
                      "max_acceleration_rate": float,
                      "max_deceleration_rate": float,
                  })
    def handle_performance(self: OSCParser,
                           element: Element,
                           max_speed: float,
                           max_acceleration: float,
                           max_deceleration: float,
                           max_acceleration_rate: Optional[float] = None,
                           max_deceleration_rate: Optional[float] = None) -> PerformanceLimits:
        return PerformanceLimits(maximum_acceleration=max_acceleration,
                                 maximum_acceleration_rate=max_acceleration_rate,
                                 maximum_deceleration=max_deceleration,
                                 maximum_deceleration_rate=max_deceleration_rate,
                                 maximum_speed=max_speed)

    @reg.register("Axles")
    def handle_axles(self: OSCParser, element: Element) -> IAxleSystem:
        """
        :param element: XMLElement
        :return: IAxleSystem
        """
        # always has a front and back axle
        # can contain extra axles
        front: IAxle = self.handle(element.find("FrontAxle"))
        rear: IAxle = self.handle(element.find("RearAxle"))
        extra: List[IAxle] = self.handle_list(element.findall("AdditionalAxle"))
        axles = [front] + extra + [rear]

        return AxleSystem(axles)

    @reg.register("FrontAxle",
                  "RearAxle",
                  "AdditionalAxle",
                  casts={
                      "max_steering": float,
                      "wheel_diameter": float,
                      "track_width": float,
                      "position_x": float,
                      "position_z": float
                  })
    def handle_axle(self: OSCParser, element: Element, max_steering: float, wheel_diameter: float,
                    track_width: float, position_x: float, position_z: float) -> Axle:
        return Axle(position_x, position_z, wheel_diameter, 2, max_steering, track_width)

    @reg.register("ObjectController")
    def handle_object_controller(self: OSCParser, element) -> ControllerProperties:
        """
        Contains either 1 CatalogReference or 1 Controller
        """

        if element is None or len(element) == 0:
            self.add_error(
                "'ObjectController' is empty. It does not contain any of ('CatalogReference', 'Controller')"
            )
            return None

        child = element[0]
        if child.tag == "CatalogReference":
            child = self.handle(child, types=["Controller"])
        # child is now definitely a Controller element
        return self.handle(child)

    @reg.register("Controller")
    def handle_controller(self: OSCParser, element, name) -> ControllerProperties:
        return self.handle(element.find("Properties"),
                           klass=ControllerProperties,
                           context_info=f"Controller '{name}'")
