import logging
import re
from copy import deepcopy
from pathlib import Path
from typing import List, Type
from xml.etree.ElementTree import Element
from xml.etree.ElementTree import parse as parse_xml

from dyna4.scenario import ParameterPool, ParameterType
from eds_osc.properties import Properties
from eds_osc.registry import XMLRegistry

logger = logging.getLogger(__name__)

ORIGINAL_CATALOG_PREFIX = re.compile(r"{original_catalog:.*?}(.*)")


def strip_original_catalog_prefix(name: str) -> str:
    """Removes the internal {original_catalog:...} prefix if present"""
    if match := ORIGINAL_CATALOG_PREFIX.match(name):
        return match.group(1)
    return name


def register_osc_handlers(reg: XMLRegistry):
    """
    Handler functions for OpenSCENARIO utilities
    """
    from eds_osc.parser import OSCParser

    @reg.register("FileHeader", casts={"rev_major": int, "rev_minor": int})
    def handle_file_header(self: OSCParser, element: Element, description: str, rev_major: int,
                           rev_minor: int, **attrib):
        self.version = (rev_major, rev_minor)
        if rev_major != 1:
            raise AttributeError(
                f"Tried to open xosc version {rev_major}.{rev_minor}, but only OpenSCENARIO 1.x is supported"
            )
        logger.debug("Description: '%s'", description)

    @reg.register("CatalogLocations")
    def handle_catalog_locations(self: OSCParser, element: Element):
        """
        Contains 0 or 1 from each ...Catalog class.
        """

        if element is None or len(element) == 0:
            # no catalogue specified
            return

        for location in element:
            if not location.tag.endswith("Catalog"):
                raise AttributeError(f"Unexpected tag {location.tag} in CatalogLocations")
            # strip "Catalog" from end to get type string
            typ = location.tag[:-7]

            # location contains exactly one directory path
            if len(location) == 0:
                raise AttributeError(f"{location.tag} does not contain a 'Directory'")

            path = Path(location[0].attrib['path'])
            if not path.is_absolute():
                # interpret path as relative path w.r.t. current scenario file
                path = self.filename.parent / path

            path = path.resolve()
            if not path.is_dir():
                raise FileNotFoundError(f"Catalog directory {path} does not exist")

            # load all .xosc files in this directory
            logger.debug("Discovering catalogs in %s", path)
            for filename in path.glob("*.xosc"):
                logger.debug("Opening catalog file %s", filename)
                catalog_element = parse_xml(filename).find("Catalog")
                if catalog_element is None:
                    continue
                logger.debug("Loading catalog file %s", filename)
                catalog_name = catalog_element.attrib['name']
                key = (typ, catalog_name)
                # merges multiple instances of the same catalog name in one dict
                # this will also overwrite duplicate entries!
                catalog = {}
                for e in catalog_element:
                    if e.tag == typ:
                        e.attrib['__catalog__'] = filename
                        item_name = e.attrib['name']
                        if item_name.endswith("[]"):
                            logger.warning(
                                f"{catalog_name} {item_name}: Catalog items should not end with []."
                                f"Can only use this syntax in CatalogReference")
                        # item_name may also contain our {original_catalog:...} syntax.
                        # It will be stripped in handle_catalog_reference
                        catalog[item_name] = e
                self.catalogs[key].update(catalog)

    @reg.register("CatalogReference")
    def handle_catalog_reference(self: OSCParser, element: Element, catalog_name: str,
                                 entry_name: str, types: List[str]) -> Element:
        potential_catalogs = []
        for typ in types:
            catalog = self.catalogs[(typ, catalog_name)]
            # will never raise KeyError since self.catalogs is a defaultdict
            if catalog:
                # break if catalog is nonempty
                potential_catalogs.append(catalog)

        if not potential_catalogs:
            raise AttributeError(
                f"Catalog '{catalog_name}' was not found or contains none of these types: {types}. "
                "Make sure to use the correct CatalogLocation tag.")

        if entry_name.endswith("[]"):
            # remove suffix for catalog lookup
            clean_lookup_name = entry_name[:-2]
            logger.debug(
                f"Found a catalog reference to {entry_name}. Will look for {clean_lookup_name}")
        else:
            clean_lookup_name = entry_name

        for catalog in potential_catalogs:
            if clean_lookup_name in catalog:
                # make a copy in case the same catalog item is referenced multiple times
                item: Element = deepcopy(catalog[clean_lookup_name])

                # override the clean catalog name with the reference version
                # to get back the brackets [] if they were present.
                # The brackets will be resolved to unique indices during handling of the individual elements.
                item.attrib['name'] = strip_original_catalog_prefix(entry_name)
                break
        else:
            raise KeyError(
                f"No catalog item named '{clean_lookup_name}' found in catalog '{catalog_name}' (types {types})"
            )

        # parse ParameterAssignments
        extra_params = dict(self.handle_list(element.iter("ParameterAssignment")))
        self._resolve_parameters(item, assignments=extra_params)
        return item

    @reg.register("ParameterAssignment")
    def handle_parameter_assignment(self: OSCParser, element: Element, parameter_ref: str,
                                    value: str):
        # we are lenient with dollar signs in ParameterAssignment
        # There should be no dollar signs here
        # but old OSC examples had them
        if parameter_ref[0] == "$":
            parameter_ref = parameter_ref[1:]
            self.add_warning(
                f"ParameterAssignment.parameter_ref should not contain $-signs: {parameter_ref}")
        return parameter_ref, value

    @reg.register("ParameterDeclaration", casts={"parameter_type": ParameterType.parse})
    def handle_parameter_declaration(parser: OSCParser,
                                     element: Element,
                                     name: str,
                                     parameter_type: str,
                                     value: str,
                                     parameter_pool: ParameterPool = None) -> None:
        # we are lenient with dollar signs in ParameterDeclarations
        if name[0] == "$":
            name = name[1:]
            parser.add_warning(f"ParameterDeclaration.name should not contain $-signs: {name}")

        if parameter_pool is None:
            parameter_pool = parser.parameters

        parameter_pool.add(name, parameter_type, parser.resolve_attribute_value(value, f"ParameterDeclaration.{name}"))

    @reg.register("VariableDeclaration", casts={"variable_type": ParameterType.parse})
    def handle_variable_declaration(parser: OSCParser, element: Element, name: str,
                                    variable_type: ParameterType, value: str) -> None:
        parser.variables.add(name, variable_type, value)

    @reg.register("Properties")
    def handle_properties(self: OSCParser, element: Element, klass: Type[Properties],
                          context_info: str) -> Properties:
        """
        Contains arbitrary number of Property and File items.

        :param klass: concrete `Properties` subclass
        :return: `Properties` instance
        """
        return klass(self.marker_list, element, filename=self.filename, context_info=context_info)
