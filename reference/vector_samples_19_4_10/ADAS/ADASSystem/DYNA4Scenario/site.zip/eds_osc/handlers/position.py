import logging
import math
from typing import List, Optional, Tuple
from xml.etree.ElementTree import Element

from dyna4.scenario import (GeoCoordinates, Height, ICoordinates, ITrajectory, Orientation,
                            RelativeLaneCoordinates, RelativeObjectCoordinates,
                            RelativeRoadCoordinates, RelativeWorldCoordinates, RoadSLaneTCoordinates,
                            RoadSRoadTCoordinates, Route, RouteEntityCoordinates,
                            RouteSLaneTCoordinates, RouteSRoadTCoordinates, RouteStrategy,
                            TrajectoryCoordinates, Waypoint, WorldCoordinates)
from eds_osc.registry import XMLRegistry
from eds_osc.utils import to_bool, position_validator

logger = logging.getLogger(__name__)


def register_position_handlers(reg: XMLRegistry):
    """
    Handler functions for position classes
    """
    from eds_osc.parser import OSCParser

    @reg.register("Position", validator=position_validator)
    def handle_position(self: OSCParser, element: Element) -> ICoordinates:
        if element is None or len(element) == 0:
            return None

        return self.handle(element[0])

    @reg.register("Orientation", casts={"h": float, "p": float, "r": float})
    def handle_orientation(self: OSCParser,
                           element,
                           h=0.0,
                           p=0.0,
                           r=0.0,
                           type="absolute") -> Orientation:
        """
        Orientation. Optional heading, pitch, roll, and type.
        """
        return Orientation(r, p, h, type == "absolute")

    @reg.register("WorldPosition",
                  casts={
                      "x": float,
                      "y": float,
                      "z": float,
                      "h": float,
                      "p": float,
                      "r": float
                  })
    def handle_world_position(self: OSCParser,
                              element: Element,
                              x,
                              y,
                              z=None,
                              h=None,
                              p=None,
                              r=None) -> ICoordinates:
        """
        Absolute world position. Mandatory x and y, optional z, heading, pitch and roll
        """
        return WorldCoordinates(x, y, z or 0, r or 0, p or 0, h or 0)

    @reg.register("GeoPosition",
                  casts={
                      "latitude_deg": float,
                      "longitude_deg": float,
                      "altitude": float,
                      "latitude": float,
                      "longitude": float,
                      "height": float
                  })
    def handle_geo_position(self: OSCParser,
                            element: Element,
                            latitude_deg: float = None,
                            longitude_deg: float = None,
                            altitude: float = None,
                            latitude: float = None,
                            longitude: float = None,
                            height: float = None) -> ICoordinates:
        """
        Geo position. Mandatory latitude and longitude, optional height
        """
        if None not in (longitude, latitude_deg):
            self.add_error(
                "The properties 'longitude' and 'latitudeDeg' are defined at the same time. Please only use the "
                "properties 'longitudeDeg' and 'latitudeDeg' both defined in degree!")
        if None not in (longitude_deg, latitude):
            self.add_error(
                "The properties 'longitudeDeg' and 'latitude' are defined at the same time. Please only use the "
                "properties 'longitudeDeg' and 'latitudeDeg' both defined in degree!")
        if longitude_deg is not None and abs(longitude_deg) > 180.0:
            longitude_deg = None
            self.add_error(
                "The property 'longitudeDeg' is not defined on the correct interval; the value must be in the "
                "interval [-180, 180].")
        if latitude_deg is not None and abs(latitude_deg) > 90.0:
            latitude_deg = None
            self.add_error(
                "The property 'latitudeDeg' is not defined on the correct interval; the value must be in the interval "
                "[-90, 90].")
        if longitude is not None and abs(longitude) > math.pi:
            longitude = None
            self.add_error(
                "The property 'longitude' is not defined on the correct interval; the value must be in the interval "
                "[-pi, pi]. Attention this is incorrectly defined in the OSC standard!")
        if latitude is not None and abs(latitude) > math.pi / 2:
            latitude = None
            self.add_error(
                "The property 'latitude' is not defined on the correct interval; the value must be in the interval "
                "[-pi/2, pi/2]. Attention this is incorrectly defined in the OSC standard!")

        def handle_geo_property(val_new_prop, val_old_prop, str_old_prop):
            if val_old_prop is not None:
                self.marker_list.add_warning_marker(
                    str(self.filename),
                    f"The property '{str_old_prop}' of the class GeoPosition is deprecated.")
                return val_old_prop, True

            return val_new_prop, False

        long, long_is_rad = handle_geo_property(longitude_deg, longitude, 'longitude')
        lat, lat_is_rad = handle_geo_property(latitude_deg, latitude, 'latitude')
        alt, old_height_format = handle_geo_property(altitude, height, 'height')

        orientation: Optional[Orientation] = self.handle(element.find("Orientation"))

        if orientation is None:
            orientation = Orientation(yaw=0, is_absolute=True, pitch=0, roll=0)

        if long is not None and long_is_rad:
            long *= 180.0 / math.pi
        if lat is not None and lat_is_rad:
            lat *= 180.0 / math.pi

        return GeoCoordinates(long or 0, lat or 0, Height(alt or 0, not old_height_format),
                              orientation)

    @reg.register("RouteRef")
    def handle_route_ref(self: OSCParser, element: Element) -> Route:
        """
        RouteRef, either contains a CatalogReference to a Route or directly a Route element
        """
        catalog_elem = element.find("CatalogReference")
        if catalog_elem is not None:
            # handle_catalog_reference raises an Error if the catalog does not exist or
            # does not contain the specified element
            route_elem = self.handle(catalog_elem, types=["Route"])
        else:
            # found no catalog -> try finding a Route
            route_elem = element.find("Route")
            if route_elem is None:
                raise AttributeError(
                    "RouteRef contains neither a CatalogReference nor a Route as a child")

        route_info: Tuple[Route, str] = self.handle(route_elem)

        return route_info[0]

    @reg.register("RoutePosition")
    def handle_route_position(self: OSCParser, element: Element) -> ICoordinates:
        """
        RoutePosition.
        """
        orientation: Optional[Orientation] = self.handle(element.find("Orientation"))

        if orientation is None:
            orientation = Orientation(roll=0, pitch=0, yaw=0, is_absolute=True)

        route: Route = self.handle(element.find("RouteRef"))

        if route is None:
            raise AttributeError(
                'Mandatory attribute "RouteRef" in RoutePosition is not specified.')

        route_position: Optional[ICoordinates] = self.handle(element.find("InRoutePosition"),
                                                             route=route,
                                                             orientation=orientation)
        if route_position is None:
            raise AttributeError(
                'Mandatory attribute "InRoutePosition" in RoutePosition is not specified.')

        return route_position

    @reg.register("FromCurrentEntity")
    def handle_position_of_current_entity(self: OSCParser, element: Element,
                                          orientation: Orientation, route: Route,
                                          entity_ref: str) -> ICoordinates:

        return RouteEntityCoordinates(route=route, entity_ref=entity_ref, orientation=orientation)

    @reg.register("FromRoadCoordinates", casts={"path_s": float, "t": float})
    def handle_position_in_road_coordinates(self: OSCParser, element: Element, route: Route,
                                            orientation: Orientation, path_s: float,
                                            t: float) -> ICoordinates:

        return RouteSRoadTCoordinates(orientation.yaw(), orientation.is_absolute(), route, path_s,
                                      t)

    @reg.register("FromLaneCoordinates", casts={"path_s": float, "lane_offset": float})
    def handle_position_in_lane_coordinates(self: OSCParser,
                                            element: Element,
                                            orientation: Orientation,
                                            route: Route,
                                            lane_id: str,
                                            path_s: float,
                                            lane_offset: float = 0) -> ICoordinates:

        return RouteSLaneTCoordinates(orientation.yaw(), orientation.is_absolute(), route,
                                      int(lane_id), path_s, lane_offset)

    @reg.register("TrajectoryRef")
    def handle_trajectory_ref(self: OSCParser, element: Element) -> ITrajectory:
        """
        TrajectoryRef, either contains a CatalogReference to a Trajectory or directly a Trajectory
        """
        catalog_elem = element.find("CatalogReference")
        if catalog_elem is not None:
            # handle_catalog_reference raises an Error if the catalog does not exist or
            # does not contain the specified element
            trajectory_elem = self.handle(catalog_elem, types=["Trajectory"])
        else:
            # found no catalog -> try finding a Trajectory
            trajectory_elem = element.find("Trajectory")
            if trajectory_elem is None:
                raise AttributeError(
                    "TrajectoryRef contains neither a CatalogReference nor a Trajectory as a child")

        trajectory: ITrajectory = self.handle(trajectory_elem)

        return trajectory

    @reg.register("TrajectoryPosition", casts={"s": float, "t": float})
    def handle_trajectory_position(self: OSCParser,
                                   element: Element,
                                   s: float,
                                   t: float = 0) -> ICoordinates:
        """
        Trajectory position. Mandatory s and trajectoryRef, optional t and orientation
        """
        trajectory: Optional[ITrajectory] = self.handle(element.find("TrajectoryRef"))
        orientation: Optional[Orientation] = self.handle(element.find("Orientation"))

        if trajectory is None:
            raise AttributeError(
                "TrajectoryPosition does not contain mandatory attribute TrajectoryRef")

        if orientation is None:
            # create new absolute Orientation with no offset in all directions
            orientation = Orientation(yaw=0, is_absolute=True, pitch=0, roll=0)

        return TrajectoryCoordinates(trajectory=trajectory, s=s, t=t, orientation=orientation)

    @reg.register("RoadPosition", casts={"s": float, "t": float})
    def handle_road_position(self: OSCParser, element: Element, road_id: str, s: float,
                             t: float) -> ICoordinates:
        orientation: Orientation = self.handle(element.find("Orientation"))

        if orientation:
            yaw = orientation.yaw()
            absolute = orientation.is_absolute()
        else:
            yaw = 0
            absolute = True

        try:
            road_id = int(road_id)
        except ValueError:
            raise ValueError("Only integer road ids are supported")

        return RoadSRoadTCoordinates(yaw, absolute, road_id, s, t)

    @reg.register("LanePosition", casts={"s": float, "offset": float})
    def handle_lane_position(self: OSCParser,
                             element: Element,
                             road_id: str,
                             lane_id: str,
                             s: float,
                             offset: float = 0) -> ICoordinates:
        orientation: Orientation = self.handle(element.find("Orientation"))

        if orientation:
            yaw = orientation.yaw()
            absolute = orientation.is_absolute()
        else:
            yaw = 0
            absolute = True

        try:
            road_id = int(road_id)
            lane_id = int(lane_id)
        except ValueError:
            raise ValueError("Only integer road and lane ids are supported")

        return RoadSLaneTCoordinates(yaw, absolute, road_id, lane_id, s, offset)

    @reg.register("RelativeWorldPosition", casts={"dx": float, "dy": float, "dz": float})
    def handle_relative_world_position(self: OSCParser,
                                       element: Element,
                                       entity_ref: str,
                                       dx: float,
                                       dy: float,
                                       dz: float = None) -> ICoordinates:
        orientation = self.handle(element.find("Orientation"))

        if orientation is None:
            orientation = Orientation(0.0, 0.0, 0.0, True)
        if dz is None:
            dz = 0

        return RelativeWorldCoordinates(entity_ref, dx, dy, dz, orientation)

    @reg.register("RelativeObjectPosition", casts={"dx": float, "dy": float, "dz": float})
    def handle_relative_object_position(self: OSCParser,
                                        element: Element,
                                        entity_ref: str,
                                        dx: float,
                                        dy: float,
                                        dz: float = None) -> ICoordinates:
        orientation = self.handle(element.find("Orientation"))

        if orientation is None:
            orientation = Orientation(0.0, 0.0, 0.0, True)
        if dz is None:
            dz = 0

        return RelativeObjectCoordinates(entity_ref, dx, dy, dz, orientation)

    @reg.register("RelativeRoadPosition", casts={"ds": float, "dt": float})
    def handle_relative_road_position(self: OSCParser, element: Element, entity_ref: str, ds: float,
                                      dt: float) -> ICoordinates:
        orientation = self.handle(element.find("Orientation"))

        if orientation is None:
            orientation = Orientation(0.0, 0.0, 0.0, True)

        return RelativeRoadCoordinates(entity_ref, ds, dt, orientation)

    @reg.register("RelativeLanePosition",
                  casts={
                      "d_lane": int,
                      "ds": float,
                      "ds_lane": float,
                      "offset": float
                  })
    def handle_relative_lane_position(self: OSCParser,
                                      element: Element,
                                      entity_ref: str,
                                      d_lane: int,
                                      ds: float = None,
                                      ds_lane: float = None,
                                      offset: float = 0) -> ICoordinates:
        orientation = self.handle(element.find("Orientation"))

        if ds is None and ds_lane is None or ds is not None and ds_lane is not None:
            raise Exception(
                "ds and dsLane are mutually exclusive, you have to provide exactly one of them")
        if ds_lane is None:
            ds_ds_lane = ds
            is_ds_lane = False
        else:
            ds_ds_lane = ds_lane
            is_ds_lane = True

        if orientation is None:
            orientation = Orientation(0.0, 0.0, 0.0, True)

        return RelativeLaneCoordinates(entity_ref, d_lane, ds_ds_lane, is_ds_lane, offset,
                                       orientation)

    @reg.register("Route", casts={"closed": to_bool})
    def handle_route(self: OSCParser, element: Element, name: str,
                     closed: bool) -> Tuple[Route, str]:
        waypoints: List[Waypoint] = self.handle_list(element.findall("Waypoint"))
        return Route(name, waypoints, closed), name

    @reg.register("Waypoint")
    def handle_waypoint(self: OSCParser, element: Element, route_strategy: str) -> Waypoint:
        if element is None or len(element) == 0:
            raise AttributeError('Waypoint does not contain a "Position" element')

        route_strategy_lower: str = route_strategy.lower()

        if route_strategy_lower == "fastest":
            strategy = RouteStrategy.FASTEST
        elif route_strategy_lower == "leastintersections":
            strategy = RouteStrategy.LEAST_INTERSECTIONS
        elif route_strategy_lower == "shortest":
            strategy = RouteStrategy.SHORTEST
        elif route_strategy_lower == "random":
            # map random onto shortest as it is not defined in the standard
            strategy = RouteStrategy.UNDEFINED
        else:
            raise AttributeError(
                f'Waypoint: RouteStrategy has the wrong value type. '
                f'Supported: \'fastest\', \'leastIntersections\', \'random\' or \'shortest\'. but was \'{route_strategy}\''
            )

        position: ICoordinates = self.handle(element[0])
        return Waypoint(position, strategy)
