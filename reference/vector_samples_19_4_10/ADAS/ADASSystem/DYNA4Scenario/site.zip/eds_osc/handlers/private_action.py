import logging
from enum import Enum
from typing import List, Optional, Tuple
from xml.etree.ElementTree import Element

from dyna4.scenario import (AbsoluteSpeedTarget, AcquirePositionAction, ContinuousDynamics,
                            DistanceReference, DynamicConstraints, DynamicsDimension, Entity,
                            EntityConfiguration, FinalSpeed, ICoordinates, IDistanceTarget,
                            InterpolantShape, InterpolationDynamics, ISpeedTarget, ISteadyState,
                            ITransitionDynamics, LaneLateralTarget, LateralAction,
                            LateralDistanceMode, LateralOffsetMode, LateralOffsetStrategy,
                            LightFlashing, LightOff, LightOn, LightStateAction, LinearRateDynamics,
                            LongitudinalAction, LongitudinalDistanceMode,
                            LongitudinalDistanceTarget, LongitudinalTimeGapTarget, MetaData,
                            MotionModel, Node, Orientation, OverrideLateralAction,
                            RelativeLaneLateralTarget, RelativeLaneOffsetLateralTarget,
                            RelativeLateralDistanceStrategy, RelativeLateralDistanceTarget,
                            RelativeLongitudinalDistanceStrategy,
                            RelativeLongitudinalDistanceTarget, RelativeSpeedTarget, Route,
                            RouteAction, SpeedAction, SpeedStrategy, SteeringWheelStrategy,
                            SteeringWheelTarget, StepDynamics, StopSteeringWheelStrategy,
                            SynchronizeAction, TargetDistanceSteadyState, TargetTimeSteadyState,
                            TeleportAction, TrajectoryAction, TrajectoryCoordinates,
                            TrajectoryStrategy, VehicleLightType, Visibility, VisibilityAction)
from eds_osc.handler import ActionHandler, EmptyHandler, PrivateActionHandler
from eds_osc.model import OSCDynamicsDimension, OSCDynamicsShape
from eds_osc.nodes import take_resource_node
from eds_osc.predicate import ParsingStage
from eds_osc.registry import XMLRegistry
from eds_osc.resources import NodeResourceUser, ResourceType
from eds_osc.utils import to_bool, unsupported_validator

logger = logging.getLogger(__name__)


# noinspection PyUnusedLocal
def register_private_action_handlers(reg: XMLRegistry):
    from eds_osc.parser import OSCParser

    @reg.register("Private")
    def handle_private(self: OSCParser, element: Element,
                       entity_ref: str) -> List[PrivateActionHandler]:
        """
        Init -> Actions -> Private
        Contains one or more PrivateAction
        """
        assert self.parsing_stage in (ParsingStage.INIT_EARLY, ParsingStage.INIT_LATE)

        # we're in init, there are no good names we can
        self.current_action_name = entity_ref
        ret = self.handle_list(element, actor_ref=entity_ref)
        return ret

    def validate_private_action(parser: OSCParser, element: Element):
        if element is None or len(element) == 0:
            parser.add_warning(
                "'PrivateAction' is empty. It does not contain any of ('LongitudinalAction', 'LateralAction', "
                "'VisibilityAction', 'ControllerAction', 'TeleportAction', 'RoutingAction', 'AppearanceAction') "
            )

    @reg.register("PrivateAction", validator=validate_private_action)
    def handle_private_action(self: OSCParser, element: Element, actor_ref: str) -> ActionHandler:
        """
        PrivateAction

        Contains exactly one of ("LongitudinalAction", "LateralAction", "VisibilityAction", "ControllerAction",
        "TeleportAction", "RoutingAction", "AppearanceAction") All child elements shall return ActionHandler
        """

        if element is None or len(element) == 0:
            return EmptyHandler()

        return self.handle(element[0], actor_ref=actor_ref)

    @reg.register("AbsoluteTargetSpeed", casts={"value": float})
    def handle_absolute_target_speed(
            self: OSCParser, element: Element, value: float,
            transition_dynamics: ITransitionDynamics) -> Tuple[ISpeedTarget, ITransitionDynamics]:
        return AbsoluteSpeedTarget(speed=value), transition_dynamics

    @reg.register("RelativeTargetSpeed", casts={"value": float, "continuous": to_bool})
    def handle_relative_target_speed(
            self: OSCParser, element: Element, entity_ref: str, continuous: bool, value: float,
            speed_target_value_type: str,
            transition_dynamics: ITransitionDynamics) -> Tuple[ISpeedTarget, ITransitionDynamics]:

        delta = 0
        factor = 1

        if speed_target_value_type.lower() == "delta":
            delta = value
        elif speed_target_value_type.lower() == "factor":
            factor = value
        else:
            raise AttributeError(
                f'RelativeTargetSpeed: SpeedTargetValueType has the wrong value type. '
                f'Supported: \'delta\' or \'factor\', but was \'{speed_target_value_type.lower()}\''
            )

        if continuous:
            if not isinstance(transition_dynamics, StepDynamics):
                logger.warning(
                    "Attribute \'continuous\' is set to \'true\' but dynamic shape is not set to \'step\'."
                )

            transition_dynamics = ContinuousDynamics(stop_on_reaching_target=False)

        return RelativeSpeedTarget(entity_ref, factor_speed=factor,
                                   delta_speed=delta), transition_dynamics

    @reg.register("SpeedActionDynamics",
                  "LaneChangeActionDynamics",
                  casts={
                      "dynamics_shape": OSCDynamicsShape,
                      "value": float,
                      "dynamics_dimension": OSCDynamicsDimension,
                      "following_mode": MotionModel.parse
                  })
    def handle_transition_dynamics(
            self: OSCParser,
            element: Element,
            dynamics_shape: OSCDynamicsShape,
            value: float,
            dynamics_dimension: OSCDynamicsDimension,
            following_mode: Optional[MotionModel] = MotionModel.UNCHANGED) -> ITransitionDynamics:

        check_transition_dynamics(self, dynamics_shape, value, dynamics_dimension)

        if dynamics_shape == OSCDynamicsShape.STEP:
            return StepDynamics(motion_model=following_mode)
        if dynamics_shape == OSCDynamicsShape.CUBIC:
            inter_shape = InterpolantShape.CUBIC
        elif dynamics_shape == OSCDynamicsShape.LINEAR:
            inter_shape = InterpolantShape.LINEAR
        elif dynamics_shape == OSCDynamicsShape.SINUSOIDAL:
            inter_shape = InterpolantShape.SINUSOIDAL
        else:
            raise AttributeError(f"Unknown dynamics shape {dynamics_shape}")

        if dynamics_dimension == OSCDynamicsDimension.RATE:
            if dynamics_shape != OSCDynamicsShape.LINEAR:
                self.add_info(
                    f'Ignoring dynamics shape {inter_shape} when dynamics dimension is set to \'rate\'. DynamicsShape \'linear\' '
                    f'will be used instead.')
            return LinearRateDynamics(rate=abs(value), motion_model=following_mode)
        elif dynamics_dimension == OSCDynamicsDimension.TIME:
            inter_dim = DynamicsDimension.TIME
        elif dynamics_dimension == OSCDynamicsDimension.DISTANCE:
            inter_dim = DynamicsDimension.DISTANCE
        else:
            raise AttributeError(f"Unknown dynamics dimension {dynamics_dimension}")

        return InterpolationDynamics(interpolation_shape=inter_shape,
                                     dimension=inter_dim,
                                     abscissa_length=value,
                                     motion_model=following_mode)

    def check_transition_dynamics(parser: OSCParser, dynamics_shape: OSCDynamicsShape, value: float,
                                  dynamics_dimension: OSCDynamicsDimension):

        if dynamics_dimension not in (OSCDynamicsDimension.RATE, OSCDynamicsDimension.TIME,
                                      OSCDynamicsDimension.DISTANCE):
            raise AttributeError(
                f"Unknown dynamicsDimension in TransitionDynamics {dynamics_dimension}")

        if dynamics_shape not in (OSCDynamicsShape.CUBIC, OSCDynamicsShape.LINEAR,
                                  OSCDynamicsShape.SINUSOIDAL, OSCDynamicsShape.STEP):
            raise AttributeError(f"Unknown dynamicsShape in TransitionDynamics {dynamics_shape}")

        # check for step:
        if dynamics_shape == OSCDynamicsShape.STEP and value != 0:
            raise AttributeError(
                f'\'value\' attribute in TransitionDynamics must be 0 when using dynamicShape \'step\', but was {value}.'
            )

        # check for rate:
        if dynamics_dimension == OSCDynamicsDimension.RATE:
            if dynamics_shape != OSCDynamicsShape.LINEAR:
                raise AttributeError(
                    f'DynamicsShape in TransitionDynamics must be \'linear\' when using dynamicsDimension \'rate\', '
                    f'but was \'{dynamics_shape}\'. ')

            if value <= 0.:
                parser.add_warning(
                    f'Negative \'rate\' {value} for linear TransitionDynamics are not valid, but interpreted as '
                    f'absolute values. ')

        if value < 0 and dynamics_dimension != OSCDynamicsDimension.RATE:
            raise AttributeError(
                f'\'value\' {value} attribute in TransitionDynamics is less than 0 but has to be in range [0..inf['
            )
        elif value == 0:
            if dynamics_shape != OSCDynamicsShape.STEP:
                raise AttributeError(
                    f'\'value\' attribute can\'t be 0 for a dynamics shape other than \'step\'.')

    @reg.register("AbsoluteTargetLane", casts={"value": int})
    def handle_absolute_target_lane(self: OSCParser, element: Element, value: int,
                                    target_lane_offset: float) -> IDistanceTarget:
        return LaneLateralTarget(target_lane_id=value,
                                 mode=LateralOffsetMode.DIST_TO_LANE_CENTER,
                                 lateral_offset=target_lane_offset)

    @reg.register("RelativeTargetLane", casts={"value": int})
    def handle_relative_target_lane(self: OSCParser, element: Element, value: int, entity_ref: str,
                                    target_lane_offset: float) -> IDistanceTarget:
        return RelativeLaneLateralTarget(entity_ref=entity_ref,
                                         relative_lane_offset=value,
                                         lateral_offset=target_lane_offset)

    @reg.register("LaneOffsetActionDynamics",
                  casts={
                      "dynamics_shape": OSCDynamicsShape,
                      "max_lateral_acc": float
                  })
    def handle_lane_transition_dynamics(self: OSCParser,
                                        element: Element,
                                        dynamics_shape: OSCDynamicsShape,
                                        transition_time: float,
                                        max_lateral_acc: float = None) -> ITransitionDynamics:

        if dynamics_shape == OSCDynamicsShape.STEP:
            return StepDynamics()
        if dynamics_shape == OSCDynamicsShape.CUBIC:
            inter_shape = InterpolantShape.CUBIC
        elif dynamics_shape == OSCDynamicsShape.LINEAR:
            inter_shape = InterpolantShape.LINEAR
        elif dynamics_shape == OSCDynamicsShape.SINUSOIDAL:
            inter_shape = InterpolantShape.SINUSOIDAL
        else:
            raise AttributeError(f"Unknown dynamics shape {dynamics_shape}")

        return InterpolationDynamics(interpolation_shape=inter_shape,
                                     dimension=DynamicsDimension.TIME,
                                     abscissa_length=transition_time)

    @reg.register("AbsoluteTargetLaneOffset", casts={"value": float})
    def handle_absolute_target_lane_offset(self: OSCParser, element: Element,
                                           value: float) -> IDistanceTarget:
        return LaneLateralTarget(mode=LateralOffsetMode.DIST_TO_LANE_CENTER, lateral_offset=value)

    @reg.register("RelativeTargetLaneOffset", casts={"value": float})
    def handle_relative_target_lane_offset(self: OSCParser, element: Element, value: float,
                                           entity_ref: str) -> IDistanceTarget:
        return RelativeLaneOffsetLateralTarget(entity_ref=entity_ref, lateral_offset=value)

    @reg.register("DynamicConstraints",
                  casts={
                      "max_acceleration": float,
                      "max_acceleration_rate": float,
                      "max_deceleration": float,
                      "max_deceleration_rate": float,
                      "max_speed": float
                  })
    def handle_dynamic_constraints(self: OSCParser,
                                   element: Element,
                                   max_acceleration: Optional[float] = None,
                                   max_acceleration_rate: Optional[float] = None,
                                   max_deceleration: Optional[float] = None,
                                   max_deceleration_rate: Optional[float] = None,
                                   max_speed: Optional[float] = None) -> DynamicConstraints:

        if max_acceleration is not None and max_acceleration < 0:
            self.add_error(
                f"Attribute 'max_acceleration'={max_acceleration} in DynamicConstraints must be in range [0..inf[."
            )

        if max_acceleration_rate is not None and max_acceleration_rate < 0:
            self.add_error(
                f"Attribute 'max_acceleration_rate'={max_acceleration_rate} in DynamicConstraints must be in range "
                f"[0..inf[. ")

        if max_deceleration is not None and max_deceleration < 0:
            self.add_error(
                f"Attribute 'max_deceleration'={max_deceleration} in DynamicConstraints must be in range [0..inf[."
            )

        if max_deceleration_rate is not None and max_deceleration_rate < 0:
            self.add_error(
                f"Attribute 'max_deceleration_rate'={max_deceleration_rate} in DynamicConstraints must be in range "
                f"[0..inf[.")

        if max_speed is not None and max_speed < 0:
            self.add_error(
                f"Attribute 'max_speed'={max_speed} in DynamicConstraints must be in range [0..inf[."
            )

        return DynamicConstraints(maximum_acceleration=max_acceleration,
                                  maximum_acceleration_rate=max_acceleration_rate,
                                  maximum_deceleration=max_deceleration,
                                  maximum_deceleration_rate=max_deceleration_rate,
                                  maximum_speed=max_speed)

    def assign_route_helper(self: OSCParser, element: Element) -> Tuple[Route, str]:
        """
        Contains either 1 CatalogReference or 1 Route
        """

        if element is None or len(element) == 0:
            raise AttributeError(
                "'AssignRouteAction' does not contain any of ('CatalogReference', 'Route')")

        child = element[0]

        if child.tag == "CatalogReference":
            child = self.handle(child, types=["Route"])

        route, name = self.handle(child)
        return route, name

    @reg.register("VisibilityAction",
                  casts={
                      "graphics": to_bool,
                      "sensors": to_bool,
                      "traffic": to_bool
                  })
    class VisibilityActionHandler(PrivateActionHandler):
        def __init__(self, parser: OSCParser, element: Element, actor_ref: str, graphics: bool,
                     sensors: bool, traffic: bool):
            super().__init__(parser, element, actor_ref)

            self.visibility = Visibility(graphics, sensors, traffic)

        def handle_entity(self, entity: Entity) -> List[Node]:
            if entity.controller_type == EntityConfiguration.ControllerType.DYNA4_VEHICLE_MODEL:
                logger.warning("Ignoring 'VisibilityAction' since it is not supported for "
                               "ControllerType.DYNA4_VEHICLE_MODEL")
                return []

            return [
                VisibilityAction(MetaData(f"{self.action_name}::VisibilityAction"), 0, entity,
                                 self.visibility)
            ]

    @reg.register("AppearanceAction")
    class AppearanceAction(PrivateActionHandler):
        def __init__(self, parser: OSCParser, element: Element, actor_ref: str):
            super().__init__(parser, element, actor_ref)

            self.action_handlers = []
            self.actions = []

            for e in element:
                self.action_handlers.append(parser.handle(e, actor_ref=actor_ref))

        def handle_entity(self, entity: Entity) -> List[Node]:
            if not self.action_handlers:
                return []

            for h in self.action_handlers:
                self.actions += h.handle_entity(entity)

            return self.actions

    @reg.register("AnimationAction", validator=unsupported_validator)
    class AnimationActionHandler(PrivateActionHandler):
        def __init__(self, parser: OSCParser, element: Element, actor_ref: str):
            super().__init__(parser, element, actor_ref)

        def handle_entity(self, entity: Entity) -> List[Node]:
            return []

    def get_light_state(parser: OSCParser, element: Element, transition_time: float):

        supported_light_types_str = [
            "daytimeRunningLights", "lowBeam", "highBeam", "fogLights", "fogLightsFront",
            "fogLightsRear", "brakeLights", "warningLights", "indicatorLeft", "indicatorRight",
            "reversingLights"
        ]
        light_type_str: str = element.find("LightType").find(
            "VehicleLight").attrib['vehicleLightType']

        if light_type_str not in supported_light_types_str:
            light_type_supported = False
            parser.add_error(f"'LightType'={light_type_str} is not supported yet.")
            return None, light_type_supported

        light_type: VehicleLightType = VehicleLightType.parse(light_type_str)
        light_type_supported = True

        light_state: Element = element.find("LightState")
        if light_state.attrib.get('luminousIntensity') is not None:
            parser.add_info(
                "Attribute 'luminousIntensity' of LightStateAction is not supported yet.")
        light_mode: LightStateActionHandler.LightMode = LightStateActionHandler.LightMode(
            light_state.attrib['mode'])
        if light_type in [
                VehicleLightType.DAYTIME_RUNNING,
                VehicleLightType.LOW_BEAM,
                VehicleLightType.HIGH_BEAM,
                VehicleLightType.FOG,
                VehicleLightType.FOG_FRONT,
                VehicleLightType.FOG_REAR,
                VehicleLightType.REVERSING,
                # VehicleLightType.LICENSE_PLATE
        ] and light_mode == LightStateActionHandler.LightMode.FLASHING:
            light_mode = LightStateActionHandler.LightMode.ON
            parser.add_warning(
                f"'LightType'={light_type_str} cannot be used with the light 'mode'=flashing. Instead "
                f"the light mode is interpreted as 'on' ignoring 'flashingOnDuration' and 'flashingOffDuration' "
                f"property. ")
        elif light_type in [
                VehicleLightType.INDICATOR_LEFT, VehicleLightType.INDICATOR_RIGHT,
                VehicleLightType.WARNING
        ] and light_mode == LightStateActionHandler.LightMode.ON:
            light_mode = LightStateActionHandler.LightMode.FLASHING
            parser.add_warning(
                f"'LightType'={light_type_str} cannot be used with the light 'mode'=on. Instead the "
                f"light mode is interpreted as 'flashing' with default values for 'flashingOnDuration'=0.5s and "
                f"'flashingOffDuration'=0.5s. ")

        color: Element = light_state.find("Color")
        if color is not None:
            parser.add_info("'Color' of LightStateAction is not supported yet.")

        # color_type = ColorType.parse(element.find("ColorType"))
        # color_rgb = parser.handle(color_rgb_elem) if (color_rgb_elem := element.find("ColorRgb")) is not None else None
        # color_rgb = parser.handle(color_cmyk_elem) if (color_cmyk_elem := element.find("ColorCmyk")) is not None else None
        # color = Color(color_type, color_rgb, color_cmyk)

        if light_mode == LightStateActionHandler.LightMode.FLASHING:
            if transition_time != 0.0:
                parser.add_warning(
                    "Attribute 'transitionTime' of LightStateAction is ignored for the light 'mode'=flashing."
                )

            def get_flashing_duration(flashing_duration_key: str):
                flashing_duration = light_state.attrib.get(flashing_duration_key)
                if flashing_duration is None:
                    flashing_duration = 0.5
                return flashing_duration

            flashing_on_duration = get_flashing_duration('flashingOnDuration')
            flashing_off_duration = get_flashing_duration('flashingOffDuration')

            light_state = LightFlashing(light_type, flashing_on_duration, flashing_off_duration)
        else:
            light_state = LightOn(
                light_type, transition_time
            ) if light_mode == LightStateActionHandler.LightMode.ON else LightOff(
                light_type, transition_time)

        return light_state, light_type_supported

    def light_state_validator(parser: OSCParser, element: Element, transition_time: float = 0.0):
        get_light_state(parser, element, transition_time)

    @reg.register("LightStateAction",
                  casts={"transition_time": float},
                  validator=light_state_validator)
    class LightStateActionHandler(PrivateActionHandler):
        class LightMode(Enum):
            ON = "on"
            OFF = "off"
            FLASHING = "flashing"

        def __init__(self,
                     parser: OSCParser,
                     element: Element,
                     actor_ref: str,
                     transition_time: float = 0.0):
            super().__init__(parser, element, actor_ref)

            self.light_state, self.light_type_supported = get_light_state(
                parser, element, transition_time)

        def handle_entity(self, entity: Entity) -> List[Node]:
            if self.light_type_supported:
                return [
                    LightStateAction(MetaData(f"{self.action_name}::LightStateAction"), 0, entity,
                                     self.light_state)
                ]

            return []

    @reg.register("SpeedAction")
    class SpeedActionHandler(PrivateActionHandler):
        def __init__(self, parser: OSCParser, element: Element, actor_ref: str):
            super().__init__(parser, element, actor_ref)

            self.target: Element = element.find("SpeedActionTarget")[0]
            self.transition_dynamics: ITransitionDynamics = parser.handle(
                element.find("SpeedActionDynamics"))

            self.target, self.transition_dynamics = parser.handle(
                self.target, transition_dynamics=self.transition_dynamics)

            self.parser = parser

            self.speed_strategy: SpeedStrategy = SpeedStrategy(self.target,
                                                               self.transition_dynamics)

        def handle_entity_config(self, entity_config: EntityConfiguration) -> bool:
            if isinstance(self.transition_dynamics, StepDynamics):
                if entity_config.initial_speed is not None:
                    self.parser.add_warning(
                        f"ScenarioObject '{entity_config.name}' has initial speed conflicts in the OpenSCENARIO file. "
                        f"Please check SpeedAction definitions with dynamicsShape='step' in the Storyboard Init. "
                    )

                # no other speed action has set an initial speed target yet
                entity_config.initial_speed = self.target
                return True  # no further action-node necessary

            if isinstance(self.transition_dynamics, InterpolationDynamics):
                # do not explicitly set an initial speed:
                # either it is set by another SpeedAction with StepDynamics or zero speed is used by default
                return False  # dynamics are applied by an action-node

            if isinstance(self.transition_dynamics, ContinuousDynamics):
                # do not explicitly set an initial speed:
                # either it is set by another SpeedAction with StepDynamics or zero speed is used by default
                return False  # dynamics are applied by an action-node

            raise AttributeError(f'Unsupported transition dynamics in SpeedAction.')

        def handle_entity(self, entity: Entity) -> List[Node]:
            node = SpeedAction(MetaData(f"{self.action_name}::SpeedAction"), 0, entity,
                               self.speed_strategy)
            resource = self.parser.resource_pool.get((entity, ResourceType.LONGITUDINAL))

            return [node, take_resource_node(resource, NodeResourceUser(node))]

    @reg.register("LaneChangeAction", casts={"target_lane_offset": float})
    class LaneChangeActionHandler(PrivateActionHandler):
        def __init__(self,
                     parser: OSCParser,
                     element: Element,
                     actor_ref: str,
                     target_lane_offset: float = 0):
            super().__init__(parser, element, actor_ref)

            # LaneChangeTarget contains exactly one child: either AbsoluteTargetLane or RelativeTargetLane
            lane_change_target: Element = element.find("LaneChangeTarget")[0]

            transition_dynamics: ITransitionDynamics = parser.handle(
                element.find("LaneChangeActionDynamics"))

            target: IDistanceTarget = parser.handle(lane_change_target,
                                                    target_lane_offset=target_lane_offset)

            self.offset_strategy = LateralOffsetStrategy(target=target,
                                                         transition_dynamics=transition_dynamics,
                                                         dynamic_constraints=None)

        def handle_entity(self, entity: Entity) -> List[Node]:
            node = LateralAction(MetaData(f"{self.action_name}::LateralAction"), 0, entity,
                                 self.offset_strategy)
            lat_resource = self.parser.resource_pool.get((entity, ResourceType.LATERAL))
            return [node, take_resource_node(lat_resource, NodeResourceUser(node))]

    @reg.register("LaneOffsetAction", casts={"continuous": to_bool})
    class LaneOffsetActionHandler(PrivateActionHandler):
        def __init__(self, parser: OSCParser, element: Element, actor_ref: str, continuous: bool):
            """
            PrivateAction > LateralAction > LaneOffsetAction
            must contains a LaneOffsetTarget and a LaneOffsetDynamics
            """

            super().__init__(parser, element, actor_ref)

            lane_offset_target: Element = element.find("LaneOffsetTarget")[0]
            target: IDistanceTarget = parser.handle(lane_offset_target)

            dynamics_target: Element = element.find("LaneOffsetActionDynamics")

            if continuous:
                transition_dynamics: ITransitionDynamics = ContinuousDynamics(not continuous)

                if not isinstance(target, RelativeLaneOffsetLateralTarget):
                    raise AttributeError(
                        f"Attribute 'continuous'={continuous} in LaneOffsetAction only reasonable for "
                        f"RelativeTargetLaneOffset.")
            else:
                # OSC does not specify a standard transition time. For now we are using a standard time of 3 seconds
                transition_dynamics: ITransitionDynamics = parser.handle(dynamics_target,
                                                                         transition_time=3)

            try:
                max_lateral_acc: float = float(dynamics_target.attrib['maxLateralAcc'])
            except KeyError:
                max_lateral_acc: None = None

            dynamic_constraints = DynamicConstraints(
                maximum_acceleration=max_lateral_acc,
                maximum_acceleration_rate=None,
                maximum_deceleration=max_lateral_acc,
                # set max_deceleration to max_acceleration for consistent parametrization of PID controller
                maximum_deceleration_rate=None,
                maximum_speed=None)

            self.offset_strategy = LateralOffsetStrategy(target=target,
                                                         transition_dynamics=transition_dynamics,
                                                         dynamic_constraints=dynamic_constraints)

        def handle_entity(self, entity: Entity) -> List[Node]:
            node = LateralAction(MetaData(f"{self.action_name}::LaneOffsetAction"), 0, entity,
                                 self.offset_strategy)
            lat_resource = self.parser.resource_pool.get((entity, ResourceType.LATERAL))
            return [node, take_resource_node(lat_resource, NodeResourceUser(node))]

    @reg.register("LateralDistanceAction",
                  casts={
                      "continuous": to_bool,
                      "distance": float,
                      "freespace": to_bool,
                      "displacement": LateralDistanceMode.parse,
                      "coordinate_system": DistanceReference.parse
                  })
    class LateralDistanceActionHandler(PrivateActionHandler):
        def __init__(self,
                     parser: OSCParser,
                     element: Element,
                     actor_ref: str,
                     continuous: bool,
                     entity_ref: str,
                     freespace: bool,
                     coordinate_system: DistanceReference = DistanceReference.ENTITY,
                     displacement: LateralDistanceMode = LateralDistanceMode.ANY,
                     distance: Optional[float] = None):
            super().__init__(parser, element, actor_ref)

            if distance is not None and distance < 0:
                raise ValueError(
                    f'Attribute "distance"(={distance}) in LateralDistanceAction is not in range [0..inf[.'
                )

            transition_dynamics: ITransitionDynamics = ContinuousDynamics(not continuous)

            dynamic_constraints_element: Optional[Element] = element.find("DynamicConstraints")
            if isinstance(dynamic_constraints_element, Element):
                dynamic_constraints: Optional[DynamicConstraints] = parser.handle(
                    dynamic_constraints_element)
            else:
                dynamic_constraints: Optional[DynamicConstraints] = None

            if distance is None:
                distance = 0

            target = RelativeLateralDistanceTarget(entity_ref=entity_ref,
                                                   distance=distance,
                                                   distance_mode=displacement,
                                                   coordinate_system=coordinate_system,
                                                   use_bounding_box=freespace)

            self.lateral_strategy = RelativeLateralDistanceStrategy(
                transition_dynamics=transition_dynamics,
                distance_target=target,
                dynamic_constraints=dynamic_constraints)

        def handle_entity(self, entity: Entity) -> List[Node]:
            node = LateralAction(MetaData(f"{self.action_name}::LateralDistanceAction::"),
                                 0,
                                 entity,
                                 lateral_strategy=self.lateral_strategy)
            lat_resource = self.parser.resource_pool.get((entity, ResourceType.LATERAL))
            return [node, take_resource_node(lat_resource, NodeResourceUser(node))]

    def target_distance_steady_state_validator(parser, element, distance: float):
        if distance <= 0:
            parser.add_error("'TargetDistanceSteadyState' allows only positive distances.")

    @reg.register("TargetDistanceSteadyState",
                  casts={"distance": float},
                  validator=target_distance_steady_state_validator)
    def handle_steady_state(parser: OSCParser, element: Element,
                            distance: float) -> TargetDistanceSteadyState:
        return TargetDistanceSteadyState(distance)

    def target_time_steady_state_validator(parser, element, time: float):
        if time <= 0:
            parser.add_error("'TargetTimeSteadyState' allows only positive time values.")

    @reg.register("TargetTimeSteadyState",
                  casts={"time": float},
                  validator=target_time_steady_state_validator)
    def handle_steady_state(parser: OSCParser, element: Element,
                            time: float) -> TargetTimeSteadyState:
        return TargetTimeSteadyState(time)

    def handle_steady_state(parser: OSCParser, element: Element) -> Optional[Element]:
        target_distance_steady_state: Optional[Element] = parser.handle(
            element.find("TargetDistanceSteadyState"))
        target_time_steady_state: Optional[Element] = parser.handle(
            element.find("TargetTimeSteadyState"))

        if target_time_steady_state is not None:
            return target_time_steady_state

        if target_distance_steady_state is not None:
            return target_distance_steady_state

        return None

    @reg.register("AbsoluteSpeed", casts={"value": float})
    def handle_absolute_speed(parser: OSCParser, element: Element, value: float) -> List[Node]:
        return [AbsoluteSpeedTarget(speed=value), handle_steady_state(parser, element)]

    @reg.register("RelativeSpeedToMaster", casts={"value": float})
    def handle_relative_speed_to_master(parser: OSCParser, element: Element, value: float,
                                        speed_target_value_type: str,
                                        master_entity_ref: str) -> List[Node]:
        steady_state: Optional[ISteadyState] = handle_steady_state(parser, element)

        factor: float = 1
        delta: float = 0

        if speed_target_value_type.lower() == "delta":
            delta = value
        elif speed_target_value_type.lower() == "factor":
            factor = value
        else:
            raise AttributeError(
                f'RelativeSpeedToMaster: SpeedTargetValueType has the wrong value type. '
                f'Supported: \'delta\' or \'factor\', but was \'{speed_target_value_type.lower()}\''
            )

        return [
            RelativeSpeedTarget(entity_ref=master_entity_ref,
                                delta_speed=delta,
                                factor_speed=factor), steady_state
        ]

    @reg.register("FinalSpeed")
    def handle_final_speed(parser: OSCParser, element: Element, master_entity_ref: str) -> Node:
        absolute_speed: Optional[AbsoluteSpeedTarget] = parser.handle(element.find("AbsoluteSpeed"))
        relative_speed: Optional[RelativeSpeedTarget] = parser.handle(
            element.find("RelativeSpeedToMaster"), master_entity_ref=master_entity_ref)

        if absolute_speed is None and relative_speed is None:
            raise AttributeError(
                f'FinalSpeed must contain either attribute AbsoluteSpeed or RelativeSpeedToMaster, but both were none.'
            )

        if absolute_speed is not None:
            return FinalSpeed(speed_target=absolute_speed[0], steady_state=absolute_speed[1])

        if relative_speed is not None:
            return FinalSpeed(speed_target=relative_speed[0], steady_state=relative_speed[1])

        return None

    def synchronize_action_validator(parser,
                                     element,
                                     master_entity_ref: str,
                                     target_tolerance: float = 0.0,
                                     target_tolerance_master: float = 0.0):
        parser.add_info(
            f"'SynchronizeAction' may yield non-physical behavior such as very high accelerations. If applicable, "
            f"constraints of the motion model are omitted when executing this action. ")

        if element is None or len(element) < 2:
            parser.add_error("'SynchronizeAction' does not contain 2 'Position' elements.")

        if master_entity_ref is None or len(master_entity_ref) == 0:
            parser.add_error("Attribute masterEntityRef in 'SynchronizeAction' must be provided.")

        if element.find('TargetPosition') is None or len(element.find('TargetPosition')) < 1:
            parser.add_error(
                "Attribute TargetPosition in 'SynchronizeAction' does not contain 'Position' element."
            )

        if element.find('TargetPositionMaster') is None or len(
                element.find('TargetPositionMaster')) < 1:
            parser.add_error(
                "Attribute TargetPositionMaster in 'SynchronizeAction' does not contain 'Position' element."
            )

        if target_tolerance < 0.0:
            parser.add_error("A negative 'targetTolerance' was specified in 'SynchronizeAction'.")

        if target_tolerance_master < 0.0:
            parser.add_error(
                "A negative 'targetToleranceMaster' was specified in 'SynchronizeAction'.")

    @reg.register("SynchronizeAction",
                  casts={
                      "target_tolerance": float,
                      "target_tolerance_master": float,
                  },
                  validator=synchronize_action_validator)
    class SynchronizeActionHandler(PrivateActionHandler):
        def __init__(self,
                     parser: OSCParser,
                     element: Element,
                     actor_ref: str,
                     master_entity_ref: str,
                     target_tolerance: float = 0.0,
                     target_tolerance_master: float = 0.0):
            super().__init__(parser, element, actor_ref)

            self.master_entity_ref = master_entity_ref
            self.target_tolerance = target_tolerance
            self.target_tolerance_master = target_tolerance_master
            self.final_speed: Optional[FinalSpeed] = parser.handle(
                self.element.find("FinalSpeed"), master_entity_ref=master_entity_ref)

            target_pos: Optional[Element] = self.element.find('TargetPosition')
            target_pos_master: Optional[Element] = self.element.find('TargetPositionMaster')

            self.target_pos: ICoordinates = parser.handle(target_pos[0])
            self.target_pos_master: ICoordinates = parser.handle(target_pos_master[0])

        def handle_entity_config(self, entity_config: EntityConfiguration) -> bool:
            if entity_config is None:
                return False

            if entity_config.controller_type == EntityConfiguration.ControllerType.DYNA4_VEHICLE_MODEL:
                self.parser.add_warning(
                    f"Ignoring 'SynchronizeAction' for entity '{entity_config.name}' since it is not supported for "
                    "ControllerType.DYNA4_VEHICLE_MODEL.")
                return True

            return False

        def handle_entity(self, entity: Entity) -> List[Node]:
            if entity.controller_type == EntityConfiguration.ControllerType.DYNA4_VEHICLE_MODEL:
                logger.warning(
                    f"Ignoring 'SynchronizeAction' for entity '{entity.name}' since it is not supported for "
                    "ControllerType.DYNA4_VEHICLE_MODEL.")
                return []

            node = SynchronizeAction(MetaData(f"{self.action_name}::SynchronizeAction"),
                                     0,
                                     entity=entity,
                                     master_entity_ref=self.master_entity_ref,
                                     target_tolerance=self.target_tolerance,
                                     target_tolerance_master=self.target_tolerance_master,
                                     target_position=self.target_pos,
                                     target_position_master=self.target_pos_master,
                                     final_speed=self.final_speed)

            long_resource = self.parser.resource_pool.get((entity, ResourceType.LONGITUDINAL))

            return [node]

    @reg.register("LongitudinalDistanceAction",
                  casts={
                      "continuous": to_bool,
                      "distance": float,
                      "freespace": to_bool,
                      "time_gap": float,
                      "displacement": LongitudinalDistanceMode.parse,
                      "coordinate_system": DistanceReference.parse
                  })
    class LongitudinalDistanceActionHandler(PrivateActionHandler):
        def __init__(self,
                     parser: OSCParser,
                     element: Element,
                     actor_ref: str,
                     continuous: bool,
                     entity_ref: str,
                     freespace: bool,
                     coordinate_system: DistanceReference = DistanceReference.ENTITY,
                     displacement: LongitudinalDistanceMode = LongitudinalDistanceMode.
                     TRAILING_REFERENCED_ENTITY,
                     distance: Optional[float] = None,
                     time_gap: Optional[float] = None):
            super().__init__(parser, element, actor_ref)

            if distance is not None and distance < 0:
                raise ValueError(
                    f'Attribute "distance"(={distance}) in LongitudinalDistanceAction is not in range [0..inf[.'
                )

            if time_gap is not None and time_gap < 0:
                raise ValueError(
                    f'Attribute "timeGap"(={time_gap}) in LongitudinalDistanceAction is not in range [0..inf[.'
                )

            transition_dynamics: ITransitionDynamics = ContinuousDynamics(not continuous)

            dynamic_constraints_element: Optional[Element] = element.find("DynamicConstraints")
            if isinstance(dynamic_constraints_element, Element):
                dynamic_constraints: Optional[DynamicConstraints] = parser.handle(
                    dynamic_constraints_element)
            else:
                dynamic_constraints: Optional[DynamicConstraints] = None

            if distance is not None and time_gap is not None:
                raise AttributeError(
                    'Attributes "distance" and "time_gap" in LongitudinalDistanceAction exclude each other. '
                    'Only one of both can be defined.')
            elif distance is None and time_gap is None:
                # in this case it is assumed that distance should be 0 and a LongitudinalDistanceTarget is used
                distance = 0

            if time_gap is not None:
                distance_target: RelativeLongitudinalDistanceTarget = LongitudinalTimeGapTarget(
                    entity_ref=entity_ref,
                    time_gap=float(time_gap),
                    distance_mode=displacement,
                    coordinate_system=coordinate_system,
                    use_bounding_box=freespace)
            else:
                distance_target: RelativeLongitudinalDistanceTarget = LongitudinalDistanceTarget(
                    entity_ref=entity_ref,
                    distance=float(distance),
                    distance_mode=displacement,
                    coordinate_system=coordinate_system,
                    use_bounding_box=freespace)

            self.longitudinal_strategy = RelativeLongitudinalDistanceStrategy(
                transition_dynamics=transition_dynamics,
                distance_target=distance_target,
                dynamic_constraints=dynamic_constraints)

        def handle_entity(self, entity: Entity) -> List[Node]:
            node = LongitudinalAction(MetaData(f"{self.action_name}::LongitudinalDistanceAction"),
                                      0,
                                      entity,
                                      longitudinal_strategy=self.longitudinal_strategy)
            long_resource = self.parser.resource_pool.get((entity, ResourceType.LONGITUDINAL))
            return [node, take_resource_node(long_resource, NodeResourceUser(node))]

    @reg.register("FollowTrajectoryAction", casts={"initial_distance_offset": float})
    class FollowTrajectoryAction(PrivateActionHandler):
        def __init__(self,
                     parser: OSCParser,
                     element: Element,
                     actor_ref: str,
                     initial_distance_offset: Optional[float] = 0.0):
            super().__init__(parser, element, actor_ref)

            self.timing = parser.handle(element.find("TimeReference"))
            self.mode = parser.handle(element.find("TrajectoryFollowingMode"))

            if (catalog_elem := element.find("CatalogReference")) is not None:
                trajectory_elem = parser.handle(catalog_elem, types=["Trajectory"])
                trajectory = parser.handle(trajectory_elem)
            elif (trajectory := element.find("Trajectory")) is not None:
                trajectory_elem = trajectory
                trajectory = parser.handle(trajectory_elem)
            elif (trajectory_ref_elem := element.find("TrajectoryRef")) is not None:
                trajectory = parser.handle(trajectory_ref_elem)

            if trajectory is None:
                raise AttributeError(
                    "Neither CatalogReference nor Trajectory nor TrajectoryRef found in FollowTrajectoryAction"
                )

            if initial_distance_offset < 0:
                raise AttributeError(
                    f'Attribute InitialDistanceOffset in FollowTrajectoryAction must be in range [0; arclength of the '
                    f'trajectory] but was: {initial_distance_offset}')

            self.trajectory = trajectory

            self.strategy = TrajectoryStrategy(self.mode, self.trajectory, self.timing,
                                               initial_distance_offset)

        def _set_trajectory_start_as_initial_position(self, entity_config: EntityConfiguration):
            entity_config.initial_position = TrajectoryCoordinates(
                s=0,
                t=0,
                trajectory=self.strategy.trajectory,
                orientation=Orientation(roll=0, pitch=0, yaw=0, is_absolute=False))

            entity_config.add_to_scenario = True

        def handle_entity_config(self, entity_config: EntityConfiguration) -> bool:
            if entity_config is None or self.strategy is None:
                return False

            if entity_config.controller_type == EntityConfiguration.ControllerType.DYNA4_VEHICLE_MODEL:
                self.parser.add_warning(
                    f"Ignoring 'FollowTrajectoryAction' for entity '{entity_config.name}' since it is not supported for "
                    "ControllerType.DYNA4_VEHICLE_MODEL.")
                return True

            if entity_config.initial_routing_position_fallback is not None:
                self.parser.add_warning(
                    f"ScenarioObject '{entity_config.name}' has conflicts in RoutingActions in the OpenSCENARIO file. "
                    f"Please check 'AssignRouteAction' and 'AcquirePositionAction' and 'FollowTrajectoryAction' definitions in the Storyboard Init."
                )

            if self.mode == MotionModel.EXACT and entity_config.initial_position is not None:  # (TrajectoryFollowingMode = position)
                self.parser.add_warning(
                    f"ScenarioObject '{entity_config.name}' has conflicts in initial positions in the OpenSCENARIO file. "
                    f"Please check 'TeleportAction' and 'AddEntityAction' definitions in combination with 'FollowTrajectoryAction' and mode='position' in the Storyboard Init."
                )

            entity_config.initial_routing_position_fallback = TrajectoryCoordinates(
                s=0,
                t=0,
                trajectory=self.strategy.trajectory,
                orientation=Orientation(roll=0, pitch=0, yaw=0, is_absolute=False))

            entity_config.add_to_scenario = True

            return False  # note that we still require the nodes to be created as well

        def handle_entity(self, entity: Entity) -> List[Node]:
            node = TrajectoryAction(MetaData(f"'{self.action_name}'::FollowTrajectoryAction "), 0,
                                    entity, self.strategy)
            lat_resource = self.parser.resource_pool.get((entity, ResourceType.LATERAL))
            nodes = [node, take_resource_node(lat_resource, NodeResourceUser(node))]

            if self.timing is not None:
                # when timing is specified, it will influence speed
                lon_resource = self.parser.resource_pool.get((entity, ResourceType.LONGITUDINAL))
                nodes.append(take_resource_node(lon_resource, NodeResourceUser(node)))

            return [node]

    def teleport_validator(parser: OSCParser, element: Element):
        if element is None or len(element) == 0:
            parser.add_error("'TeleportAction' does not contain a 'Position' element.")

    @reg.register("TeleportAction", validator=teleport_validator)
    class TeleportActionHandler(PrivateActionHandler):
        def __init__(self, parser: OSCParser, element: Element, actor_ref: str):
            super().__init__(parser, element, actor_ref)

            if element is None or len(element) == 0:
                self.position = None
                return

            self.parser = parser
            self.position = parser.handle(element[0])

        def handle_entity_config(self, entity_config: EntityConfiguration) -> bool:
            if entity_config is None or self.position is None:
                return False

            logger.debug(
                f"Setting initial position for entity '{entity_config.name}' to {self.position}")

            if entity_config.initial_position is not None:
                self.parser.add_warning(
                    f"ScenarioObject '{entity_config.name}' has initial position conflicts in the OpenSCENARIO file. "
                    f"Please check 'TeleportAction' and 'AddEntityAction' and 'RoutingAction' definitions in the Storyboard Init. "
                )

            entity_config.initial_position = self.position
            entity_config.add_to_scenario = True

            return True

        def handle_entity(self, entity: Entity) -> List[Node]:
            if entity is None or self.position is None:
                return []

            if entity.controller_type == EntityConfiguration.ControllerType.DYNA4_VEHICLE_MODEL:
                logger.warning(
                    "Ignoring 'TeleportAction' during simulation since it is not supported for "
                    "ControllerType.DYNA4_VEHICLE_MODEL. ")
                return []

            return [
                TeleportAction(MetaData(f"{self.action_name}::TeleportAction"), 0, entity,
                               self.position)
            ]

    def acquire_position_validator(parser, element):
        if element is None or len(element) == 0:
            parser.add_error("'AcquirePositionAction' does not contain a 'Position' element.")

    @reg.register("AcquirePositionAction", validator=acquire_position_validator)
    class AcquirePositionActionHandler(PrivateActionHandler):
        def __init__(self, parser: OSCParser, element: Element, actor_ref: str):
            super().__init__(parser, element, actor_ref)

            if element is None or len(element) == 0:
                self.position = None
                return

            self.position = parser.handle(element[0])

        def handle_entity_config(self, entity_config: EntityConfiguration) -> bool:
            if entity_config is None or self.position is None:
                return False

            if entity_config.initial_routing_position_fallback is not None:
                self.parser.add_warning(
                    f"ScenarioObject '{entity_config.name}' has conflicts in RoutingActions in the OpenSCENARIO file. "
                    f"Please check 'AssignRouteAction' and 'AcquirePositionAction' and 'FollowTrajectoryAction' definitions in the Storyboard Init."
                )

            # use the target point as optional starting point if no initial position is specified explicitly
            entity_config.initial_routing_position_fallback = self.position
            entity_config.add_to_scenario = True

            # ensure that AcquirePositionAction handle_entity is executed anyway.
            # The initial position might be overwritten by another action defined later in Init
            return False

        def handle_entity(self, entity: Entity) -> List[Node]:
            if entity is None or self.position is None:
                return []

            return [
                AcquirePositionAction(MetaData(f"{self.action_name}::AcquirePositionAction"), 0,
                                      entity, self.position)
            ]

    @reg.register("AssignRouteAction")
    class AssignRouteActionHandler(PrivateActionHandler):
        def __init__(self, parser: OSCParser, element: Element, actor_ref: str):
            super().__init__(parser, element, actor_ref)

            if element is None or len(element) == 0:
                raise AttributeError(
                    'AssignRouteAction contains neither a "CatalogReference" nor a "Route"')

            child = element[0]

            if child.tag == "CatalogReference":
                child = parser.handle(child, types=["Route"])

            route, name = parser.handle(child)
            self.route = route
            self.name = name

        def handle_entity_config(self, entity_config: EntityConfiguration) -> bool:
            if entity_config is None or self.route is None:
                return False

            if entity_config.route is not None:
                self.parser.add_warning(
                    f"ScenarioObject '{entity_config.name}' has conflicts in RoutingActions in the OpenSCENARIO file. "
                    f"Please check if more than one 'AssignRouteAction' is defined in the Storyboard Init."
                )
            elif entity_config.initial_routing_position_fallback is not None:
                self.parser.add_warning(
                    f"ScenarioObject '{entity_config.name}' has conflicts in RoutingActions in the OpenSCENARIO file. "
                    f"Please check 'AssignRouteAction' and 'AcquirePositionAction' and 'FollowTrajectoryAction' definitions in the Storyboard Init."
                )

            entity_config.route = self.route

            # use the first waypoint as optional starting point if no initial position is specified explicitly
            entity_config.initial_routing_position_fallback = self.route.waypoints[0].position
            entity_config.add_to_scenario = True

            return True

        def handle_entity(self, entity: Entity) -> List[Node]:
            return [
                RouteAction(MetaData(f"{self.action_name}::AssignRouteAction"), 0, entity,
                            self.route)
            ]

    @reg.register("SteeringWheel",
                  casts={
                      "active": to_bool,
                      "value": float,
                      "max_rate": float,
                      "max_torque": float
                  })
    class OverrideSteeringWheelActionHandler(PrivateActionHandler):
        def __init__(self,
                     parser: OSCParser,
                     element: Element,
                     actor_ref: str,
                     active: bool,
                     value: float,
                     max_rate: Optional[float] = None,
                     max_torque: Optional[float] = None):
            super().__init__(parser, element, actor_ref)

            self.active = active

            if max_torque is not None:
                parser.add_info("SteeringWheel max_torque is not supported. Ignoring...")

            if active:
                self.strategy = SteeringWheelStrategy(
                    target=SteeringWheelTarget(steering_wheel_angle=value, maximum_rate=max_rate))
            else:
                self.strategy = StopSteeringWheelStrategy()

        def handle_entity(self, entity: Entity) -> List[Node]:
            node = OverrideLateralAction(
                MetaData(f"{self.action_name}::OverrideSteeringWheelAction",
                         f"<active: {self.active}>"), 0, entity, self.strategy)

            lat_resource = self.parser.resource_pool.get((entity, ResourceType.LATERAL))
            return [node, take_resource_node(lat_resource, NodeResourceUser(node))]
