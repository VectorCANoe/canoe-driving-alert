import logging
import operator
from typing import List
from xml.etree.ElementTree import Element

from eds_osc.commands import Command
from eds_osc.handler import ActionHandler, EmptyHandler, PrivateActionHandler
from eds_osc.nodes import parallel, storyboard_element
from eds_osc.registry import XMLRegistry
from eds_osc.utils import unsupported_validator

from dyna4.scenario import (Action, AddAction, EmptyNode, Entity, EntityConfiguration, ICoordinates,
                            IVariable, MetaData, Node, ParameterPool, RemoveAction, VariablePool)

logger = logging.getLogger(__name__)


# noinspection PyUnusedLocal
def register_action_handlers(reg: XMLRegistry):
    """
    Handler functions for all global and user-defined actions
    """
    from eds_osc.parser import OSCParser

    #
    # Action Implementations
    #
    @reg.register("Actions")
    def handle_init_actions(self: OSCParser, element: Element) -> List[ActionHandler]:
        """
        Init -> Actions
        Can contain multiple GlobalAction, Private, UserDefinedAction elements
        """
        handlers = []
        for i, child in enumerate(element):
            self.current_action_name = f"InitAction{i}"
            if child.tag == "Private":
                # private will return a list of handlers
                handlers.extend(self.handle(child))
            else:
                # all other tags will return a single handler
                handlers.append(self.handle(child))
        self.current_action_name = "<unknown>"
        return handlers

    def validate_action(parser: OSCParser, element: Element, name: str):
        if element is None or len(element) == 0:
            parser.add_warning(
                "Element 'Action' is empty. It does not contain any of ('GlobalAction', 'UserDefinedAction', "
                "'PrivateAction')")

    @reg.register("Action", validator=validate_action)
    def handle_action(self: OSCParser, element: Element, name: str, namespace: str,
                      actors: List[Entity]) -> Node:
        """
        Action tags are only used in Story, not in Init
        Event -> Action
        Contains exactly one of GlobalAction, PrivateAction, UserDefinedAction
        """
        full_name = self.name_mgr.add("action", f"{namespace}::{name}")

        if element is None or len(element) == 0:
            return EmptyNode(MetaData("empty"), 0)

        sub_action = element[0]

        self.current_action_name = full_name
        if sub_action.tag == "PrivateAction":
            if not actors:
                logger.warning(f"PrivateAction {full_name} has no actors and will have no effect")
            action_nodes = []
            for actor in actors:
                handler: ActionHandler = self.handle(sub_action, actor_ref=actor.name)
                assert isinstance(handler, ActionHandler)
                action_nodes.extend(handler.call_create_nodes(False))
        else:
            handler = self.handle(sub_action)
            assert isinstance(handler, ActionHandler)
            action_nodes = handler.call_create_nodes(False)

        body = parallel(action_nodes, full_name + ".body")
        self.current_action_name = "<unknown>"

        sb_element = storyboard_element(full_name, body)
        self.element_mgr[full_name] = sb_element
        return sb_element

    #
    # Global Actions
    #
    def validate_global_action(parser: OSCParser, element: Element):
        if element is None or len(element) == 0:
            parser.add_warning(
                "'GlobalAction' is empty. It does not contain any of ('EnvironmentAction', 'EntityAction', "
                "'ParameterAction', 'InfrastructureAction', 'TrafficAction')")

    @reg.register("GlobalAction", validator=validate_global_action)
    def handle_global_action(self: OSCParser, element: Element) -> ActionHandler:
        """
        GlobalAction

        Contains exactly one of (environmentAction, entityAction, parameterAction, infrastructureAction, trafficAction)
        All child elements shall return ActionHandler
        """

        if element is None or len(element) == 0:
            return EmptyHandler()

        return self.handle(element[0])

    @reg.register("EnvironmentAction", validator=unsupported_validator)
    class EnvironmentActionHandler(ActionHandler):
        def create_nodes(self) -> List[Node]:
            logger.info("'EnvironmentAction' is not supported yet")
            return []

    @reg.register("Environment", validator=unsupported_validator)
    def handle_environment(self: OSCParser, element, name) -> None:
        """
        EnvironmentAction -> Environment
        """
        logger.info("'Environment' is not supported yet")

    def validate_parameter_action(parser: OSCParser, element: Element, parameter_ref: str):
        # create temporary ParameterPool
        previous_parameters = parser.parameters
        parser.parameters = ParameterPool()

        # load all parameters
        par_decls = parser.root.find("ParameterDeclarations")
        if par_decls is not None and len(par_decls) > 0:
            parser.handle_list(par_decls)

        # parse all parameters
        if element is None or len(element) == 0:
            parser.add_warning(
                "'ParameterAction' is empty. It does not contain any of ('SetAction', 'ModifyAction')"
            )

        if parameter_ref not in parser.parameters:
            parser.add_error(f"Parameter '{parameter_ref}' was not declared")

        # restore original ParameterPool
        parser.parameters = previous_parameters

    @reg.register("ParameterAction", validator=validate_parameter_action)
    class ParameterActionHandler(ActionHandler):
        def __init__(self, parser: OSCParser, element: Element, parameter_ref: str):
            super().__init__(parser, element)
            self.parameter_ref = parameter_ref

        def create_nodes(self) -> List[Node]:
            param = self.parser.parameters[self.parameter_ref]
            # element[0] is either SetAction or ModifyAction
            return [self.parser.handle(self.element[0], param=param)]

    def validate_variable_action(parser: OSCParser, element: Element, variable_ref: str):
        # create temporary VariablePool
        previous_variables = parser.variables
        parser.variables = VariablePool()

        # load all variables

        var_decls = parser.root.find("VariableDeclarations")
        if var_decls is not None and len(var_decls) > 0:
            parser.handle_list(var_decls)

        # parse all variables
        if element is None or len(element) == 0:
            parser.add_warning(
                "'VariableAction' is empty. It does not contain any of ('SetAction', 'ModifyAction')"
            )

        if variable_ref not in parser.variables:
            parser.add_error(f"Variable '{variable_ref}' was not declared")

        # restore original VariablePool
        parser.variables = previous_variables

    @reg.register("VariableAction", validator=validate_variable_action)
    class VariableAction(ActionHandler):
        def __init__(self, parser: OSCParser, element: Element, variable_ref: str):
            super().__init__(parser, element)
            self.variable_ref = variable_ref

        def create_nodes(self) -> List[Node]:
            var = self.parser.variables[self.variable_ref]
            # element[0] is either SetAction or ModifyAction
            return [self.parser.handle(self.element[0], var=var)]

    @reg.register("SetAction")
    def handle_parameter_set_action(self: OSCParser,
                                    element: Element,
                                    value: str,
                                    param: IVariable = None,
                                    var: IVariable = None) -> Node:
        """
        This tag is used for parameters and variables!

        ParameterAction -> ParameterSetAction or
        VariableAction -> VariableSetAction
        """
        if param is not None:
            return Action(MetaData(f"ParameterSetAction '{self.current_action_name}'"), 0,
                          lambda: param.assign_string(value))
        if var is not None:
            return Action(MetaData(f"VariableSetAction '{self.current_action_name}'"), 0,
                          lambda: var.assign_string(value))

        raise RuntimeError("Must either specify param or var")

    @reg.register("ModifyAction")
    def handle_parameter_modify_action(self: OSCParser,
                                       element: Element,
                                       param: IVariable = None,
                                       var: IVariable = None) -> Node:
        """
        This tag is used for parameters and variables!

        ParameterAction -> ParameterModifyAction
        VariableAction -> VariableModifyAction
        """

        if element is None or len(element) == 0:
            logger.warning(
                "'ModifyAction' is empty. It does not contain any of ('AddValue', 'MultiplyByValue')"
            )
            return EmptyNode(MetaData("empty"), 0)

        add = element[0].find("AddValue")
        mul = element[0].find("MultiplyByValue")
        if add is not None:
            op = operator.add
            val = add.attrib['value']
        elif mul is not None:
            op = operator.mul
            val = mul.attrib['value']
        else:
            raise AttributeError(
                "ModifyAction needs to have either an AddValue or a MultiplyByValue child")

        if param is not None:
            typed_val = param.cast_from_string(val)

            def action():
                param.assign_string(str(op(param.value, typed_val)))

            return Action(MetaData(f"ParameterModifyAction '{self.current_action_name}'"), 0,
                          action)
        if var is not None:
            typed_val = var.cast_from_string(val)

            def action():
                var.assign_string(str(op(var.value, typed_val)))

            return Action(MetaData(f"VariableModifyAction '{self.current_action_name}'"), 0, action)

        raise RuntimeError("Must either specify param or var")

    def validate_entity_action(parser: OSCParser, element: Element, entity_ref: str):
        if element is None or len(element) == 0:
            parser.add_warning(
                "'EntityAction' is empty. It does not contain any of ('AddEntityAction', 'DeleteEntityAction')"
            )

    @reg.register("EntityAction", validator=validate_entity_action)
    def handle_entity_action(self: OSCParser, element: Element, entity_ref: str) -> ActionHandler:
        if element is None or len(element) == 0:
            return EmptyHandler()

        return self.handle(element[0], entity_ref=entity_ref)

    def validate_add_entity_action(parser: OSCParser, element: Element):
        if element is None or len(element) == 0:
            parser.add_error("'AddEntityAction' does not contain a 'Position'")

    @reg.register("AddEntityAction", validator=validate_add_entity_action)
    class AddEntityActionHandler(PrivateActionHandler):
        def __init__(self, parser, element: Element, entity_ref: str):
            super().__init__(parser, element, actor_ref=entity_ref)

            if self.element is None or len(self.element) == 0:
                return EmptyHandler()

            self.parser = parser

            self.position: ICoordinates = parser.handle(element[0])

        def handle_entity_config(self, entity_config: EntityConfiguration) -> bool:
            if entity_config is None:
                return False

            if entity_config.initial_position is not None:
                self.parser.add_warning(
                    f"ScenarioObject '{entity_config.name}' has initial position conflicts in the OpenSCENARIO file. "
                    f"Please check 'TeleportAction' and 'AddEntityAction' definitions in the Storyboard Init. "
                )

            entity_config.add_to_scenario = True
            entity_config.initial_position = self.position
            return True

        def handle_entity(self, entity: Entity) -> List[Node]:
            if entity.controller_type == EntityConfiguration.ControllerType.DYNA4_VEHICLE_MODEL:
                self.parser.add_warning(
                    "Ignoring 'AddEntityAction' since it is not allowed on DYNA4_VEHICLE_MODEL during the simulation."
                )
                return []
            return [
                AddAction(MetaData(f"AddEntityAction '{self.action_name}'"), 0, entity,
                          self.position)
            ]

    @reg.register("DeleteEntityAction")
    class DeleteEntityActionHandler(PrivateActionHandler):
        def __init__(self, parser, element: Element, entity_ref: str):
            super().__init__(parser, element, actor_ref=entity_ref)

            self.parser = parser

        def handle_entity_config(self, entity_config: EntityConfiguration) -> bool:
            if entity_config.controller_type == EntityConfiguration.ControllerType.DYNA4_VEHICLE_MODEL:
                self.parser.add_warning(
                    "Ignoring 'DeleteEntityAction' since it is not allowed on DYNA4_VEHICLE_MODEL.")
            else:
                entity_config.add_to_scenario = False
            return True

        def handle_entity(self, entity: Entity) -> List[Node]:
            if entity.controller_type == EntityConfiguration.ControllerType.DYNA4_VEHICLE_MODEL:
                self.parser.add_warning(
                    "Ignoring 'DeleteEntityAction' since it is not allowed on DYNA4_VEHICLE_MODEL.")
                return []
            return [RemoveAction(MetaData(f"DeleteEntityAction '{self.action_name}'"), 0, entity)]

    #
    # User Defined Actions
    #
    @reg.register("CustomCommandAction")
    class CustomCommandActionHandler(ActionHandler):
        # noinspection PyShadowingBuiltins
        def __init__(self, parser: OSCParser, element: Element, type: str):
            super().__init__(parser, element)
            self.typ = type
            self.parser = parser

        def validate(self) -> bool:
            if self.typ != "dyna4":
                # TODO: use marker?
                logger.warning(f"Ignoring 'CustomCommandAction' of unknown type '{self.typ}'.")
                return False
            elif self.element is None or len(self.element) == 0:
                logger.warning(
                    "Ignoring 'CustomCommandAction' of type 'dyna4' since it does not contain a command."
                )
                return False
            return True

        def create_nodes(self) -> List[Node]:
            command: Command = self.parser.handle(self.element[0])
            return [command.make_node()]
