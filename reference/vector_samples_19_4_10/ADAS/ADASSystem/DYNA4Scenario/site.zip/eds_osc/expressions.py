import math
from typing import List, Union

from pyparsing import (CaselessLiteral, Combine, Forward, Group, Literal, OneOrMore, Optional,
                       ParseException, ParseResults, Suppress, Word, ZeroOrMore, nums, oneOf)


################################
# Arithmetic expression handling
################################


class ArithmeticExpression:
    def __init__(self, children: List = None):
        # in python lists are mutable objects therefore we have to create a copy of the lists children
        if children is None:
            children = []
        self.children = [child for child in children]

    def add_child(self, c):
        self.children.append(c)

    def eval(self) -> Union[float, int]:
        result = 0

        if len(self.children) == 0:
            return result
        if len(self.children) > 1:
            raise AttributeError("Expression parsing returned an invalid expression")

        for child in self.children:
            result += child.eval()

        return result


class NumValue(ArithmeticExpression):
    def __init__(self, children=None):
        super(NumValue, self).__init__(children)

    def eval(self) -> Union[float, int]:
        if len(self.children) > 1:
            raise AttributeError("Expression parsing returned an invalid expression")

        return self.children[0]


class UnaryMinus(ArithmeticExpression):
    def __init__(self, children=None):
        super(UnaryMinus, self).__init__(children)

    def eval(self) -> Union[float, int]:
        if len(self.children) > 1:
            raise AttributeError("Expression parsing returned an invalid expression")

        return -(self.children[0].eval())


class Operation(ArithmeticExpression):
    def __init__(self):
        super(Operation, self).__init__()

    def eval(self) -> Union[float, int]:
        result = 0
        last_op = '+'
        for child in self.children:
            if child in ("+", "-", "*", "/", "%"):
                last_op = child
            else:
                child_val = child.eval()

                if last_op == "+":
                    result += child_val
                elif last_op == "-":
                    result -= child_val
                elif last_op == "*":
                    result *= child_val
                elif last_op == "/":
                    if child_val == 0:
                        raise ArithmeticError("Division by zero is not allowed!")
                    result /= child_val
                elif last_op == "%":
                    if child_val == 0:
                        raise ArithmeticError("The remainder operator with zero is not allowed!")
                    result = math.remainder(result, child_val)

        return result


class Function(ArithmeticExpression):
    def __init__(self, func):
        super(Function, self).__init__()
        self.func = func

    def add_param(self, param):
        self.add_child(param)

    def eval(self) -> Union[float, int]:
        if len(self.children) > 2:
            raise AttributeError("Expression parsing returned an invalid expression")

        if self.func == "pow":
            return math.pow(self.children[0].eval(), self.children[1].eval())
        elif self.func == "round":
            return round(self.children[0].eval())
        elif self.func == "floor":
            return math.floor(self.children[0].eval())
        elif self.func == "ceil":
            return math.ceil(self.children[0].eval())
        elif self.func == "sqrt":
            return math.sqrt(self.children[0].eval())
        else:
            raise AttributeError('Unexpected function token "%s"', self.func)


def create_expressions(tree: List) -> ArithmeticExpression:
    """method parses the grammar tree which is represented as a list and returns a recursive expression representation
     which can be evaluated"""

    if tree[0] in ("round", "floor", "ceil", "sqrt", "pow"):
        current_expr = Function(tree[0])
        current_expr.add_param(create_expressions([tree[1]]))
        if len(tree) == 4:
            current_expr.add_param(create_expressions([tree[3]]))
        return current_expr

    if tree[0] == '-':
        unary_minus_expr = UnaryMinus()
        child_expr = create_expressions([tree[1]])
        unary_minus_expr.add_child(child_expr)
        return unary_minus_expr

    if "+" in tree[1:] or "-" in tree[1:] or "*" in tree[1:] or "%" in tree[1:] or "/" in tree[1:]:
        current_expr = Operation()
    else:
        current_expr = ArithmeticExpression()

    for i in range(len(tree)):
        element = tree[i]

        if type(element) == list:
            child_exp = create_expressions(element)
            current_expr.add_child(child_exp)
        elif type(element) in (int, float):
            current_expr.add_child(NumValue([element]))
        elif element in ("+", "-", "*", "/", "%"):
            current_expr.add_child(element)
        else:
            raise AttributeError(f"Unexpected token in expression: {element}.")

    return current_expr


def define_arithmetic_grammar():
    """ :return the pyparsing grammar for OpenScenario arithmetic expression parsing"""

    def to_num(p: ParseResults) -> Union[float, int]:
        """converts a string to a float or an int depending on its type"""
        if '.' in p[0] or 'e' in p[0]:
            return float(p[0])

        return int(p[0])

    def constant_to_val(p: ParseResults) -> float:
        if p[0] == 'PI' or p[0] == 'pi':
            return math.pi
        if p[0] == 'E' or p[0] == 'e':
            return math.e

    integer = Word(nums)
    real = Combine(integer + '.' + integer)
    scientific_notation = Combine((real | integer) + CaselessLiteral('e') + Optional(oneOf('- +')) +
                                  integer)

    constant = CaselessLiteral('PI') | CaselessLiteral('E')
    constant.set_parse_action(constant_to_val)

    expr = Forward()
    number = Combine(Optional(oneOf('- +')) + (scientific_notation | real | integer | constant))
    number.set_parse_action(to_num)

    plus, minus, mult, div, mod = map(Literal, "+-*/%")

    LPAR, RPAR = map(Suppress, "()")
    addop = plus | minus
    mulop = mult | div | mod

    unary_function = oneOf("round floor ceil sqrt") + LPAR + Group(expr) + RPAR
    binary_function = ("pow" + LPAR + Group(expr) + ',' + Group(expr) + RPAR)

    atom = Group(
        Optional("-") + (Group(unary_function) | Group(binary_function)
                         | Group(LPAR + expr + RPAR))) | number | constant

    term = Group(atom + OneOrMore(mulop + atom)) | atom

    expr <<= (term + ZeroOrMore(addop + term))

    return expr


def calculate_arithmetic_expression(string: str):
    # timeout could be an issue, but then the user input is wrong
    expr = define_arithmetic_grammar()
    try:
        parsed = expr.parseString(string, parse_all=True)
    except ParseException:
        raise SyntaxError("Invalid syntax for an arithmetic expression!")

    expression_tree = create_expressions(parsed.asList())
    result = expression_tree.eval()
    if math.isinf(result):
        raise OverflowError("Calculation resulted in an overflow!")

    return result


################################
# Boolean expression handling
################################


class BooleanExpression:
    def __init__(self, children: List = None):
        # in python lists are mutable objects therefore we have to create a copy of the lists children
        if children is None:
            children = []
        self.children = [child for child in children]

    def add_child(self, c):
        self.children.append(c)

    def eval(self) -> bool:
        result = False

        if len(self.children) == 0:
            return result
        if len(self.children) > 1:
            raise AttributeError("Expression parsing returned an invalid expression")

        result = self.children[0].eval()

        return result


class BoolValue(BooleanExpression):
    def __init__(self, children=None):
        super(BoolValue, self).__init__(children)

    def eval(self) -> bool:
        if len(self.children) > 1:
            raise AttributeError("Expression parsing returned an invalid expression")

        return self.children[0]


class Not(BooleanExpression):
    def __init__(self, children=None):
        super(Not, self).__init__(children)

    def eval(self) -> bool:
        if len(self.children) > 1:
            raise AttributeError("Expression parsing returned an invalid expression")

        return not (self.children[0].eval())


class BoolOperation(BooleanExpression):
    def __init__(self):
        super(BoolOperation, self).__init__()

    def eval(self) -> bool:
        result = False
        last_op = 'or'

        for child in self.children:
            if child in ("and", "or"):
                last_op = child
            else:
                child_val = child.eval()

                if last_op == "and":
                    result = result and child_val
                elif last_op == "or":
                    result = result or child_val

        return result


def create_bool_expressions(tree: List) -> BooleanExpression:
    """method parses the grammar tree which is represented as a list and returns a recursive expression representation
     which can be evaluated"""

    if tree[0] == 'not':
        unary_not = Not()
        child_expr = create_bool_expressions([tree[1]])
        unary_not.add_child(child_expr)
        return unary_not

    if "and" in tree[1:] or "or" in tree[1:]:
        current_expr = BoolOperation()
    else:
        current_expr = BooleanExpression()

    for i in range(len(tree)):
        element = tree[i]

        if type(element) == list:
            child_exp = create_bool_expressions(element)
            current_expr.add_child(child_exp)
        elif type(element) is bool:
            current_expr.add_child(BoolValue([element]))
        elif element in ("and", "or"):
            current_expr.add_child(element)
        else:
            raise AttributeError(f"Unexpected token in expression: {element}")

    return current_expr


def define_bool_grammar():
    """ :return the pyparsing grammar for OpenScenario boolean expression parsing"""

    def to_bool(p: ParseResults) -> bool:
        """converts a string to a bool value true or 1 -> true and false or 0 -> false"""
        if p[0].lower() == "true":
            return True
        elif p[0].lower() == "false":
            return False
        else:
            int_val = int(p[0])
            return True if int_val == 1 else False

    bool_literal = (oneOf("True true False false 0 1"))

    expr = Forward()
    bool_literal.set_parse_action(to_bool)

    and_ = Literal("and")
    or_ = Literal("or")
    not_ = Literal("not")

    LPAR, RPAR = map(Suppress, "()")

    atom = Group(not_ + bool_literal) | bool_literal | Group(LPAR + expr + RPAR)

    term = Group(atom + OneOrMore(and_ + atom)) | atom

    expr <<= (term + ZeroOrMore(or_ + term))

    return expr


def evaluate_bool_expression(string: str):
    # timeout could be an issue, but then the user input is wrong
    expr = define_bool_grammar()
    try:
        parsed = expr.parseString(string, parse_all=True)
    except ParseException:
        raise SyntaxError("Invalid syntax for a boolean expression!")

    expression_tree = create_bool_expressions(parsed.asList())
    return expression_tree.eval()


##########################################################
# handler function for arithmetic and boolean expressions:
##########################################################


def evaluate_arbitrary_expression(expr: str):
    try:
        result = calculate_arithmetic_expression(expr)
        return result
    except Exception as e:
        error_msg = str(e)

        try:
            result = evaluate_bool_expression(expr)
            return result
        except Exception as e:
            raise AttributeError(
                f'Expression ="{expr}" could not be evaluated. Error message from arithmetic '
                f'evaluation:'
                f' "{error_msg}", error message from boolean evaluation: "{str(e)}".')
