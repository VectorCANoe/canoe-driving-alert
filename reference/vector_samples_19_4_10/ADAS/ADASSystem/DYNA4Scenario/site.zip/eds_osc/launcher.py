#
# Copyright (c) Vector Informatik GmbH. All rights reserved.
#
import logging
from typing import List, Optional

from dyna4.scenario import BaseScenario, EntityConfiguration, IRoadNetwork, Node, ScenarioContext

from eds_osc.commands import core_commands
from eds_osc.parser import OSCParser
from eds_osc.utils import Dyna4LogHandler

# store commands in variable for unit tests
commands = core_commands


class Scenario(BaseScenario):
    def __init__(self, context: ScenarioContext):
        super().__init__(context)
        self.parser = OSCParser(context.marker_list, self.variables, self.parameters, self.entities)
        self.parser.load_file(self.context.scenario_file, self.context.ego_entity_name)
        self.parser.register_custom_command(*commands)

        self.early_init_loaded = False

    def define_parameters(self):
        self.parser.define_parameters()

    def preprocess_parameters(self):
        pass

    def define_road_network(self) -> Optional[IRoadNetwork]:
        self.parser.apply_parameters()
        return self.parser.define_road_network()

    def on_road_network_loaded(self, road_network):
        # early init may reference road features, so we cannot parse it in constructor
        self.parser.early_init()
        self.early_init_loaded = True

    def define_entities(self):
        self.parser.define_entities()

    def define_variables(self):
        self.parser.define_variables()

    def define_story(self, start: Node):
        if not self.early_init_loaded:
            self.parser.early_init()
        self.parser.define_story(start)
