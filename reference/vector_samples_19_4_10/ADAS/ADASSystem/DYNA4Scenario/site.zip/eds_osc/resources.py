#
# Copyright (c) Vector Informatik GmbH. All rights reserved.
#
"""
This module provides classes for tracking conflicts between OpenSCENARIO actions
that try to access an entity's resources such as the longitudinal control.

See also OpenSCENARIO User Guide Version 1.1 Section 4.3.2 Paragraph "Conflicting actions"
"""

from abc import ABC, abstractmethod
from enum import Enum
from typing import Any, Optional


class ResourceType(Enum):
    LONGITUDINAL = 1
    LATERAL = 2


class ResourceUser(ABC):
    """Interface for a generic resource user"""
    @abstractmethod
    def on_resource_lost(self):
        """
        Callback when a resource that was previously owned by this object got claimed by a new user.
        The old owner should no longer perform operations on the resource.
        """


class NodeResourceUser(ResourceUser):
    """ResourceUser implementation that calls ``stop_and_continue`` when resource is lost"""
    def __init__(self, node):
        self.node = node

    def on_resource_lost(self):
        self.node.stop_and_continue(None, 0)


class Resource:
    """Individual resource that can be held by max. 1 party at a time"""
    def __init__(self, name):
        self.user = None
        self.name = name

    def take(self, user: Optional[ResourceUser]):
        """Claim this resource.
        If this resource has a previous ResourceUser, it is notified via ``on_resource_lost``.

        :param user: new resource user. Can be None if the new resource operation ends immediately.
        """
        if self.user and self.user != user:
            self.user.on_resource_lost()
        self.user = user

    def __repr__(self):
        return f"Resource({self.name!r})"


class ResourcePool:
    """Collection of resources"""
    def __init__(self):
        self.resources = {}

    def get(self, key: Any) -> Resource:
        """
        Get a resource for a given key.
        Creates a new instance if it does not exist.

        :param key: any object that uniquely identifies a resource. Can be e.g. a tuple of (Entity, ResourceType)
        :return: the corresponding resource object
        """
        if key not in self.resources:
            self.resources[key] = Resource(repr(key))
        return self.resources[key]
