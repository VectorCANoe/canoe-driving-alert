#
# Copyright (c) Vector Informatik GmbH. All rights reserved.
#
from dataclasses import dataclass
from enum import Enum

from dyna4.scenario import BoxCenter, BoxDimension

from .registry import XMLRegistry


@dataclass
class BoundingBox:
    dimensions: BoxDimension
    center: BoxCenter


@dataclass
class Timing:
    absolute: bool
    offset: float
    scale: float


class Priority(Enum):
    PARALLEL = "parallel"
    SKIP = "skip"
    OVERWRITE = "overwrite"  # deprecated with OSC 1.2
    OVERRIDE = "override"


class OSCDynamicsShape(Enum):
    CUBIC = "cubic"
    LINEAR = "linear"
    SINUSOIDAL = "sinusoidal"
    STEP = "step"


class OSCDynamicsDimension(Enum):
    DISTANCE = "distance"
    RATE = "rate"
    TIME = "time"


class CarFollowingModel(Enum):
    DEFAULT = "Default"
    NONE = "None"


class SpeedControl(Enum):
    EXACT = "Exact"
    AUTOMATIC = "Automatic"


@dataclass
class File:
    """
    Represents a File tag in OpenSCENARIO.
    Resolution of relative paths is not handled by this class.
    : filepath: Filepath-string as it is specified in the scenario file
    """
    filepath: str


@dataclass
class OSCRoadNetwork:
    logic_file: File = None
    scene_graph_file: File = None


def register_models(reg: XMLRegistry):
    reg.register_class(BoxDimension,
                       "Dimensions",
                       casts={
                           "width": float,
                           "length": float,
                           "height": float
                       })
    reg.register_class(BoxCenter, "Center", casts={"x": float, "y": float, "z": float})
    reg.register_class(BoundingBox,
                       "BoundingBox",
                       children={
                           "dimensions": "Dimensions",
                           "center": "Center"
                       })
    reg.register_class(File, "LogicFile", "SceneGraphFile")
    reg.register_class(OSCRoadNetwork,
                       "RoadNetwork",
                       children={
                           "logic_file": "LogicFile",
                           "scene_graph_file": "SceneGraphFile"
                       })
