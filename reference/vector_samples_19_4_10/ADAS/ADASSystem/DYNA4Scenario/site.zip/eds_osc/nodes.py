#
# Copyright (c) Vector Informatik GmbH. All rights reserved.
#
import logging
from typing import List

from dyna4.scenario import (Action, And, EmptyNode, MetaData, Node, NodeGroup, NodeState, NodeStateTransition,
                 StatefulNodeGroup, TriggerDelayEvent)

from .resources import Resource, ResourceUser

TRANSITION_START_RUNNING = NodeStateTransition("Start", NodeState.RUNNING)
TRANSITION_STOP_COMPLETE = NodeStateTransition("Stop", NodeState.COMPLETE)
TRANSITION_END_RUNNING = NodeStateTransition("End", NodeState.RUNNING)
TRANSITION_END_COMPLETE = NodeStateTransition("End", NodeState.COMPLETE)
TRANSITION_SKIP_STANDBY = NodeStateTransition("Skip", NodeState.STANDBY)


def storyboard_element(name: str, body: Node, in_node=None, iterations=None) -> StatefulNodeGroup:
    """

    :param name:
    :param body:
    :param in_node: optional input node that gets executed before TRANSITION_START_RUNNING. Must NOT be included in body
    :param iterations:
    :return:
    """
    if in_node is None:
        in_node = EmptyNode(MetaData(name + ".in_node"), 0)

    has_loop = iterations is not None and iterations > 1

    in_node.connect(body)

    if has_loop:
        node_loop = TriggerDelayEvent(MetaData(name + ".Loop"),
                                      0,
                                      min=0,
                                      max=iterations - 1,
                                      reset=iterations)
        node_break = TriggerDelayEvent(MetaData(name + ".Break"),
                                       0,
                                       min=iterations - 1,
                                       max=1,
                                       reset=iterations)

        body.connect([node_loop, node_break])
        node_loop.connect(in_node)

        group = StatefulNodeGroup([in_node, body, node_loop, node_break], in_node, node_break,
                                  NodeState.STANDBY, MetaData(name + ".NG"))
        group.add_transition(TRANSITION_END_COMPLETE, node_break)
        group.add_transition(TRANSITION_END_RUNNING, node_loop)
    else:
        group = StatefulNodeGroup([in_node, body], in_node, body, NodeState.STANDBY, MetaData(name))
        group.add_transition(TRANSITION_END_COMPLETE, body)

    group.add_transition(TRANSITION_START_RUNNING, in_node)
    group.add_stop_transition(TRANSITION_STOP_COMPLETE)
    return group


def sequence(nodes: List[Node], name: str = "Sequence") -> Node:
    """
    Creates a chain of Nodes
    :param nodes: list of nodes
    :param name: optional name
    :return: NodeGroup
    """
    if len(nodes) == 0:
        return EmptyNode(MetaData(name + ".sequence_root"), 0)
    elif len(nodes) == 1:
        # optimization: if there is only one node, return it directly
        return nodes[0]

    # chain nodes together
    prev = nodes[0]
    for node in nodes[1:]:
        prev.connect(node)
        prev = node

    return NodeGroup(nodes, nodes[0], nodes[-1], MetaData(name + ".sequence_ng"))


def parallel(nodes: List[Node], name: str = "Parallel") -> Node:
    assert isinstance(nodes, list)
    root = EmptyNode(MetaData(name + "parallel_root"), 0)

    if len(nodes) == 0:
        return root
    elif len(nodes) == 1:
        return nodes[0]

    and_node = And(MetaData("_" + name + ".done"), 0)
    for node in nodes:
        root.connect(node)
        node.connect(and_node)
    return NodeGroup(nodes + [root, and_node], root, and_node, MetaData(name + ".parallel_ng"))


def for_loop(iterations: int, body: Node, name="ForLoop"):
    if iterations < 1:
        raise ValueError("Number of iterations must be >= 1")
    if iterations == 1:
        return body, None, None

    node_loop = TriggerDelayEvent(MetaData(name + ".Loop"),
                                  0,
                                  min=0,
                                  max=iterations - 1,
                                  reset=iterations)
    node_break = TriggerDelayEvent(MetaData(name + ".Break"),
                                   0,
                                   min=iterations - 1,
                                   max=1,
                                   reset=iterations)

    body.connect([node_loop, node_break])
    node_loop.connect(body)

    return NodeGroup([body, node_break, node_loop], body, node_break,
                     MetaData(name + "Group")), node_loop, node_break


def take_resource_node(resource: Resource, user: ResourceUser) -> Node:
    return Action(MetaData("TakeResource"), 0, lambda: resource.take(user))
