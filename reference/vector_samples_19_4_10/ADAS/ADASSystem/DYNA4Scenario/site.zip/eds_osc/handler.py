import abc
from abc import ABC, abstractmethod
from typing import List
from xml.etree.ElementTree import Element

from dyna4.scenario import Entity, EntityConfiguration, Node


class ActionHandler(ABC):
    """
    Base class for all handlers of action elements.
    Each OSC Action must be handled using a subclass of ActionHandler.
    """

    skip_node_for_init = False
    """
    Skip call to create_nodes if the current action is defined in init.
    Subclasses may overwrite this value either on class-level or instance-level.
    This is typically used if an init action can be completely described using an EntityConfiguration,
    without the need for extra nodes.
    """
    def __init__(self, parser, element: Element):
        """
        Construct a new ActionHandler instance.
        Subclasses may define their own constructor with additional arguments,
        similar to regular eds_osc handler functions.
        If a custom CTOR is defined, a call to super().__init__ must be included.

        :param parser: OSCParser instance
        :param element: XML element
        """
        self.parser = parser
        self.element = element
        if parser:
            self.action_name = parser.current_action_name

        self._validate_called = False
        self._valid = False

    def call_configure(self) -> None:
        """
        Safely call :py:meth:`configure`.
        Should not be overwritten by subclasses.
        
        :return: None
        """
        if not self._validate_called:
            self.call_validate()
        if not self._valid:
            return
        self.configure()

    def call_create_nodes(self, is_init: bool) -> List[Node]:
        """
        Safely call :py:meth:`create_nodes`.
        Should not be overwritten by subclasses.

        :return: List of EDS nodes
        """
        if not self._validate_called:
            self.call_validate()
        if not self._valid:
            return []
        if (is_init and self.skip_node_for_init) or not self._valid:
            return []
        return self.create_nodes()

    def call_validate(self) -> bool:
        """
        Safely call :py:meth:`validate`.
        Should not be overwritten by subclasses.

        :return: Whether element is valid
        """
        self._valid = self.validate()
        self._validate_called = True
        return self._valid

    def validate(self) -> bool:
        """
        Optional validation.
        Subclasses may implement this method to check whether the defined element is logically well-defined.
        The parser should assume that the data is adhering to OSC schema,
        so there is no need to check for deviations from standard.
        This method should not be called manually.

        :return:
            - True if the element is valid.
            - False if it is not valid; it will be skipped in any further processing.
        """
        return True

    def configure(self) -> None:
        """
        Optional configure callback.
        Subclasses may implement this method to perform special tasks for Init actions.
        This method will only be called for Actions located in the Init section, it will be skipped for Story actions.
        This method will be called during mdlInitializeConditions after the road has been loaded but before Entities
        have been built.
        This is primarily used to define EntityConfigurations.

        :return: None
        """
        pass

    @abstractmethod
    def create_nodes(self) -> List[Node]:
        """
        Required node callback.
        This method will be called for Story and Init actions, except when self.skip_node_for_init is True.

        :return: List of EDS nodes
        """
        ...


class EmptyHandler(ActionHandler):
    """Dummy handler that can be returned when no action should be performed"""
    def __init__(self):
        super().__init__(None, Element(""))

    def create_nodes(self) -> List[Node]:
        return []


class PrivateActionHandler(ActionHandler):
    def __init__(self, parser, element: Element, actor_ref: str):
        """
        Construct a new PrivateActionHandler instance.

        :param parser: OSCParser
        :param element: XML element
        :param actor_ref: name of the actor that this action will affect
        """
        super().__init__(parser, element)
        self.actor_ref = actor_ref
        self.skip_node_for_init = False

    def configure(self) -> None:
        self.skip_node_for_init = self.handle_entity_config(
            self.parser.get_entity_config(self.actor_ref))

    def create_nodes(self) -> List[Node]:
        return self.handle_entity(self.parser.get_entity(self.actor_ref))

    def handle_entity_config(self, entity_config: EntityConfiguration) -> bool:
        """
        Optional entity config callback.
        This method will only be called for init actions.
        Subclasses may implement this method to modify an entity's configuration before building it.
        Depending on the return value, additional nodes can still be defined later for dynamic tasks.

        :param entity_config: configuration for this entity
        :return: True if this element has been fully handled already and :py:meth:`handle_entity` should be skipped.
        """
        return False

    @abc.abstractmethod
    def handle_entity(self, entity: Entity) -> List[Node]:
        """
        Required entity callback.
        This method will be called for all story actions.
        It will also be called for init actions if :py:meth:`handle_entity_config` returned False.

        :param entity: actor for this action
        :return: List of EDS nodes
        """
        ...
