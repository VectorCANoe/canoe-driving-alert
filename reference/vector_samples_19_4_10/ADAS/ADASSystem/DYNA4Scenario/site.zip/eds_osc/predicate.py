from enum import IntEnum


class ParsingStage(IntEnum):
    """Internal state of the OSCParser"""

    #: parsing top of OSC file: RoadNetwork, Entities, ...
    HEADER = 1

    #: parsing init section, before building entities
    INIT_EARLY = 2

    #: parsing init section, after building entities
    INIT_LATE = 3

    #: parsing main story sections
    STORY = 4

    #: after parsing story; ready to trigger post parsing callbacks
    POST_STORY = 5
