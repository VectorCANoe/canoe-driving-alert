#
# Copyright (c) Vector Informatik GmbH. All rights reserved.
#
import logging
from abc import ABC, abstractmethod
from typing import Dict, List, Optional, Type

from dyna4.scenario import (Action, Condition, Instruction, MetaData, Node, TimeDelayEvent,
                            get_object)

from .constants import DYNA4_XML_NAMESPACE
from .instructions import TakeResourceInstruction, TriggerCountInstruction
from .registry import XMLRegistry
from .resources import NodeResourceUser, Resource
from .utils import get_signal_float_supplier, to_bool

get_signal_modifier = get_object
get_signal_source = get_object


class XMLDeserializable:
    """
    Mixin for classes that can be deserialized from an XML element.
    """
    tag = None
    casts = {}
    children = {}
    pass_context = False
    pass_element = False

    @classmethod
    def get_tag(cls) -> str:
        """Get the XML tag name"""
        return cls.tag

    @classmethod
    def register(cls, reg: XMLRegistry, replace=True):
        reg.register_func(cls,
                          cls.get_tag(),
                          casts=cls.casts,
                          children=cls.children,
                          pass_context=cls.pass_context,
                          pass_element=cls.pass_element,
                          replace=replace)


class Command(ABC, XMLDeserializable):
    """
    Abstract base class for user-defined commands.

    All our custom commands are expected to be defined within our own XML namespace.
    To use a custom command in an `.osc` file, make sure to "import" the dyna4 namespace in the header:

    .. code-block:: XML

        <OpenSCENARIO
            xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
            xmlns:dyna4="http://vector.com/dyna4/openscenario/v1.0"
            xsi:noNamespaceSchemaLocation="OpenSCENARIO.xsd">

    Then you can use it as described in the individual class docstrings.
    """
    @classmethod
    def get_tag(cls) -> str:
        """Get the XML tag name. Overrides default behaviour to add our custom dyna4 XML namespace"""
        return "{%s}%s" % (DYNA4_XML_NAMESPACE, cls.tag)

    @abstractmethod
    def make_node(self) -> Node:
        ...


class SimpleCommand(Command):
    """Abstract base class for one-off commands"""
    @abstractmethod
    def execute(self):
        ...

    def make_node(self) -> Node:
        return Action(MetaData(self.tag), 0, self.execute)


class InstructionCommand(Command):
    """Abstract base class for commands that use a custom Instruction class"""
    def __init__(self, instr: Instruction):
        self.instr = instr

    def make_node(self) -> Node:
        return Node(MetaData(self.tag), 0, self.instr)


class TimeDelayCommand(Command):
    """
    Waits a given amount of time (in seconds) between activation and triggering:

    .. code-block:: XML

        <CustomCommandAction type="dyna4">
            <dyna4:TimeDelay delay="2.5"/>
        </CustomCommandAction>
    """

    tag = "TimeDelay"
    casts = {"delay": float}

    def __init__(self, delay: float):
        self.delay = delay

    def make_node(self) -> Node:
        return TimeDelayEvent(MetaData("TimeDelay"), 0, self.delay)


class PrintCommand(SimpleCommand):
    """
    Prints a message to stdout:

    .. code-block:: XML

        <CustomCommandAction type="dyna4">
            <dyna4:Print text="Hello, world!"/>
        </CustomCommandAction>
    """
    tag = "Print"

    def __init__(self, text: str):
        self.text = text

    def execute(self):
        print(self.text)


class LogCommand(SimpleCommand):
    """
    Logs a message using the Python logging library:

    .. code-block:: XML

        <CustomCommandAction type="dyna4">
            <dyna4:Log text="Hello, world!" level="info"/>
        </CustomCommandAction>
    """
    tag = "Log"

    def __init__(self, text: str, level: str = "info", name: str = "LogCommand"):
        self.logger = logging.getLogger(name)
        self.text = text
        self.level = logging.getLevelName(level.upper())

    def execute(self):
        self.logger.log(self.level, self.text)


class PyEvalCommand(SimpleCommand):
    """
    Evaluates raw Python code:

    .. code-block:: XML

        <CustomCommandAction type="dyna4">
            <dyna4:PyEval value="print(1+2)"/>
        </CustomCommandAction>
    """
    tag = "Eval"

    def __init__(self, value: str):
        self.content = value

    def execute(self):
        eval(self.content)


class TriggerCountCommand(InstructionCommand):
    """
    Counts the number of times it has been triggered

    .. code-block:: XML

        <CustomCommandAction type="dyna4">
            <dyna4:TriggerCount name="myCounter"/>
        </CustomCommandAction>

    Retrieve the counter value using
    ::

        >>> TriggerCountCommand.query("myCounter")
    """

    tag = "TriggerCount"

    instances: Dict[str, "TriggerCountCommand"] = {}

    allow_replace_instance = True

    def __init__(self, name: str):
        super().__init__(TriggerCountInstruction())
        if name in TriggerCountCommand.instances and not TriggerCountCommand.allow_replace_instance:
            raise KeyError(f"Duplicate entry in TriggerCountCommand: '{name}'")
        TriggerCountCommand.instances[name] = self

    @classmethod
    def query(cls, name: str) -> int:
        """Returns the number of counted triggers for a given counter name"""
        return cls.instances[name].instr.count()

    @classmethod
    def trigger_time(cls, name: str, idx: int) -> float:
        return cls.instances[name].instr.trigger_events[idx]


class TakeResourceCommand(InstructionCommand):
    """
    Claims a resource by name.
    If block is true, this node will block forever.

    .. code-block:: XML

        <CustomCommandAction type="dyna4">
            <dyna4:TakeResource resourceName="someResource123" block="true"/>
        </CustomCommandAction>
    """
    tag = "TakeResource"
    casts = {"block": to_bool}

    resources: Dict[str, Resource] = {}

    @classmethod
    def get_resource(cls, resource_name: str) -> Resource:
        if resource_name not in cls.resources:
            cls.resources[resource_name] = Resource(resource_name)
        return cls.resources[resource_name]

    def __init__(self, resource_name, block=False):
        condition = Condition(lambda: not block)
        super().__init__(TakeResourceInstruction(self.get_resource(resource_name), condition))

    def make_node(self) -> Node:
        node = Node(MetaData(self.tag), 0, self.instr)
        self.instr.set_user(NodeResourceUser(node))
        return node


class WriteToSignalSourceCommand(SimpleCommand):
    """
    Writes a float value to a DYNA4 Signal Source

    value can be a floating-point value or a DYNA4 identifier like signal:some.signal

    .. code-block:: XML

        <!-- set value of signal source "example.source" to 4.5 -->
        <CustomCommandAction type="dyna4">
            <dyna4:WriteToSignalSource accessId="example.source" value="4.5"/>
        </CustomCommandAction>

        <!-- set value of signal source "example.source" to the current value of signal "some.other.signal" -->
        <CustomCommandAction type="dyna4">
            <dyna4:WriteToSignalSource accessId="example.source" value="signal:some.other.signal"/>
        </CustomCommandAction>

    """
    tag = "WriteToSignalSource"

    def __init__(self, access_id: str, value: str):
        self.source = get_signal_source(access_id)
        self.value_supplier = get_signal_float_supplier(value)

    def execute(self):
        self.source.set_value(self.value_supplier())


class EnableSignalModifierCommand(SimpleCommand):
    """
    Enables a Simulink signal modifier
    and optionally sets scale and/or value.
    Values remain unchanged if the attributes are missing.
    Both scale and value can individually either be floating-point value
    or a DYNA4 identifier like signal:some.signal

    .. code-block:: XML

        <CustomCommandAction type="dyna4">
            <dyna4:EnableSignalModifier accessId="example.signal"/>
        </CustomCommandAction>
        <!-- or -->
        <CustomCommandAction type="dyna4">
            <dyna4:EnableSignalModifier accessId="example.signal" scale="2" value="signal:some.signal"/>
        </CustomCommandAction>
    """
    tag = "EnableSignalModifier"

    def __init__(self, access_id: str, scale: Optional[str] = None, value: Optional[str] = None):
        self.modifier = get_signal_modifier(access_id)
        self.scale_supplier = get_signal_float_supplier(scale) if scale is not None else None
        self.value_supplier = get_signal_float_supplier(value) if value is not None else None

    def execute(self):
        self.modifier.enable()
        if self.scale_supplier is not None:
            self.modifier.set_scale(self.scale_supplier())
        if self.value_supplier is not None:
            self.modifier.set_value(self.value_supplier())


class DisableSignalModifierCommand(SimpleCommand):
    """
    Disables a Simulink signal modifier

    .. code-block:: XML

        <CustomCommandAction type="dyna4">
            <dyna4:DisableSignalModifier accessId="example.signal"/>
        </CustomCommandAction>

    """
    tag = "DisableSignalModifier"

    def __init__(self, access_id: str):
        self.modifier = get_signal_modifier(access_id)

    def execute(self):
        self.modifier.disable()


class ResetSignalModifierCommand(SimpleCommand):
    """
    Resets a Simulink signal modifier

    .. code-block:: XML

        <CustomCommandAction type="dyna4">
            <dyna4:ResetSignalModifier accessId="example.signal"/>
        </CustomCommandAction>
    """
    tag = "ResetSignalModifier"

    def __init__(self, access_id: str):
        self.modifier = get_signal_modifier(access_id)

    def execute(self):
        self.modifier.reset()


core_commands: List[Type[Command]] = [
    TimeDelayCommand, PrintCommand, LogCommand, WriteToSignalSourceCommand,
    EnableSignalModifierCommand, DisableSignalModifierCommand, ResetSignalModifierCommand
]
test_commands: List[Type[Command]] = core_commands + [TriggerCountCommand, TakeResourceCommand]
