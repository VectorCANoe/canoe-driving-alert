#
# Copyright (c) Vector Informatik GmbH. All rights reserved.
#

from typing import Callable

IntSupplier = Callable[[], int]
"""Function that takes no arguments and returns an int"""

FloatSupplier = Callable[[], float]
"""Function that takes no arguments and returns a float"""
