#
# Copyright (c) Vector Informatik GmbH. All rights reserved.
#
import logging
import re
from collections import defaultdict
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Type
from xml.etree.ElementTree import Element
from xml.etree.ElementTree import parse as parse_xml

from dyna4.scenario import (Entity, EntityConfiguration, EntityPool, IRoadNetwork,
                            MetaData, Node, OpenDRIVE, ParameterPool, StatefulNodeGroup,
                            StaticCodeMarkerList, StopSimulation, VariablePool)

from .commands import Command
from .expressions import evaluate_arbitrary_expression
from .handler import ActionHandler
from .handlers import register_all_handlers
from .model import OSCRoadNetwork, register_models
from .nodes import parallel
from .predicate import ParsingStage
from .registry import XMLRegistry
from .resources import ResourcePool
from .utils import ElementNameManager, assert_is_list_of

logger = logging.getLogger(__name__)

reg = XMLRegistry()

reg.register_trivial([
    "LongitudinalAction", "LateralAction", "ControllerAction", "RoutingAction", "Init",
    "UserDefinedAction", "ByValueCondition", "EntityCondition", "LaneOffsetTarget",
    "LaneChangeTarget", "InRoutePosition", "OverrideControllerValueAction"
])
register_models(reg)


# noinspection PyUnusedLocal
class OSCParser:
    """Main class for parsing OpenSCENARIO files and building the EDS network"""
    def __init__(self,
                 marker_list: StaticCodeMarkerList = None,
                 variables: VariablePool = None,
                 parameters: ParameterPool = None,
                 entity_configs: EntityPool = None):
        self.marker_list = StaticCodeMarkerList() if marker_list is None else marker_list
        self.variables = VariablePool() if variables is None else variables
        self.parameters = ParameterPool() if parameters is None else parameters
        self.ego_entity_ref = None
        self.entity_configs = EntityPool(
        ) if entity_configs is None else entity_configs  # allows duplicate keys
        self.traffic_animation_files = {}
        self.custom_commands: Dict[str, Type[Command]] = {}
        self.catalogs = defaultdict(dict)
        self.filename = None
        self.root = None
        self.parsing_stage = ParsingStage.HEADER
        self.post_parsing_callbacks = []
        self.version = (-1, -1)
        self.registry = reg.deepcopy()
        register_all_handlers(self.registry)
        self.resource_pool = ResourcePool()
        self.road_network = None
        self.init_handlers: List[ActionHandler] = []
        self.current_action_name = "<unknown>"
        self.current_condition_name = "<unknown>"

        self.name_mgr = ElementNameManager()
        self.element_mgr = {}

    def load_file(self, filename, ego_entity_ref=""):
        """
        Load OpenSCENARIO file and parse header section

        :param filename: string of path-like object pointing to an `.osc` file
        :param ego_entity_ref: name of the entity that should be used as the ego vehicle
        """
        logger.debug(f"Loading OpenSCENARIO '{filename}'")
        self.ego_entity_ref = ego_entity_ref
        self.filename = Path(filename)
        self.root = parse_xml(filename).getroot()

    def early_init(self):
        self.handle(self.root.find("FileHeader"))
        self.handle(self.root.find("CatalogLocations"))
        self.handle(self.root.find("Entities"))

        storyboard = self.root.find("Storyboard")

        # walk over entities for the first time before building entities
        self.parsing_stage = ParsingStage.INIT_EARLY
        self.init_handlers: List[ActionHandler] = self.handle(storyboard.find("Init"))
        assert_is_list_of(self.init_handlers, ActionHandler)
        for handler in self.init_handlers:
            handler.call_configure()

    def define_parameters(self):
        # resolve parameters and account for local parameter scopes
        # note: a depth-first-search recursive iteration is used to apply parameters directly which are not defined on
        # top-level. Top-level parameters are stored in global parameter pool to be exposed to task automation and
        # scenario-engine py-scripts
        self._resolve_parameters_depth_first_search(xml_root=self.root,
                                                    parameter_pool=self.parameters)

    def define_variables(self):
        var_decls = self.root.find("VariableDeclarations")
        if var_decls is not None and len(var_decls) > 0:
            self.handle_list(var_decls)

    def define_story(self, start: Node):
        """Build network of EDS nodes and attach it

        :param start: parent EDS node to which all new nodes will be appended
        """

        # note: the start node is delayed to give the traffic another timestep to initialize (see ScenarioLoader.cpp)

        assert self.parsing_stage == ParsingStage.INIT_EARLY
        storyboard = self.root.find("Storyboard")

        # walk over init section again now that we have entities built
        self.parsing_stage = ParsingStage.INIT_LATE
        init_nodes = []
        for handler in self.init_handlers:
            init_nodes.extend(handler.call_create_nodes(True))
        start.connect(init_nodes)

        self.parsing_stage = ParsingStage.STORY
        story_node = parallel(self.handle_list(storyboard.findall("Story")))

        self.parsing_stage = ParsingStage.POST_STORY

        # connect story node (starting with OSC 1.2, a story is not mandatory)
        if story_node is not None:
            start.connect(story_node)

        # stop trigger (optional)
        stop_trigger_elem = storyboard.find("StopTrigger")
        if stop_trigger_elem is not None and len(stop_trigger_elem) > 0:
            stop_trigger_node: Node = self.handle(stop_trigger_elem, name="Storyboard.stop_trigger")
            start.connect(stop_trigger_node)
            stop_action = StopSimulation(MetaData("Storyboard.StopSimulation"), 0)
            stop_trigger_node.connect(stop_action)

        # this must happen at the very end of parsing
        for callback in self.post_parsing_callbacks:
            callback()

    def get_storyboard_element(self, typ: str, short_name: str) -> StatefulNodeGroup:
        # we must at least be in POST_STORY stage so that it is guaranteed that all SB elements are already parsed
        assert self.parsing_stage >= ParsingStage.POST_STORY
        long_name = self.name_mgr.resolve(typ, short_name)
        return self.element_mgr[long_name]

    def _resolve_parameters_depth_first_search(self, xml_root: Element,
                                               parameter_pool: Optional[ParameterPool]):
        # when going downwards, search for next ParameterDeclarations with more local scope
        # when going upwards, once leaving the scope of a ParameterDeclaration, the parameters are applied directly
        # except for top-level parameters (i.e. call for root element)
        scope = xml_root.find('.//ParameterDeclarations/..')

        if scope is None:
            return  # empty parameter declarations

        # continue depth-first-search up to next ParameterDeclarations child
        for child in scope:
            # skip the ParameterDeclarations child itself
            if child.tag == "ParameterDeclarations":
                continue

            # note: pass None as parameter_pool to only store top-level parameters in the parameter_pool
            self._resolve_parameters_depth_first_search(child, parameter_pool=None)

        # if no external parameter_pool is passed, apply the resolved parameters directly to all children
        apply_parameters = False

        if parameter_pool is None:
            apply_parameters = True  # apply parameters to local scope directly afterwards
            parameter_pool = ParameterPool()  # use a local scope parameter pool

        # store the parameters in the parameter_pool
        par_decls = scope.find('./ParameterDeclarations')
        if par_decls is not None and len(par_decls) > 0:
            self.handle_list(par_decls, parameter_pool=parameter_pool)

        # before we are leaving the current scope, apply parameters of this pool to all remaining parameter references
        if apply_parameters:
            self._resolve_parameters(scope, None, parameter_pool)

    def resolve_attribute_value(self, a_val: str, location: str) -> str:
        expression_regex = re.compile(r"\s*\${(.+)}\s*")
        param_regex = re.compile(r"\s*\$([A-Za-z_][A-Za-z0-9_]*)\s*")

        def replacer(m) -> str:
            param_name = m.group(1)
            try:
                value = self.parameters[param_name].value
                return f"({value})"
            except KeyError:
                logger.warning(
                    f"Unresolved parameter '{param_name}' in expression '{expr}' in {location}"
                )

        match = expression_regex.fullmatch(a_val)
        if match:
            expr = match.group(1)
            expr = param_regex.sub(replacer, expr)
            logger.debug("Expression after substitution: %s", expr)

            result = evaluate_arbitrary_expression(expr)
            return str(result)

        match = param_regex.fullmatch(a_val)
        if match:
            param_name = match.group(1)
            if param_name in self.parameters:
                return str(self.parameters[param_name].value)  # replace value as string
            # otherwise the parameter will be set by another scope

        return a_val

    def _resolve_parameters(self,
                            xml_root: Element,
                            assignments: Dict[str, str] = None,
                            parameter_pool: ParameterPool = None):
        """
        Resolves all parameters in a given XML tree by replacing all occurrences.

        :param xml_root: XML Root Element
        :param assignments: optional dictionary that overrides local parameters. Key must NOT contain $ signs
        :return: updated XML Element
        """

        global_parameters = self.parameters

        if parameter_pool is not None:
            self.parameters = parameter_pool

        if assignments:
            # use a temporary parameter pool and add parameters to which parameters will be assigned
            # do not add the parameters to the global container and do not expose them
            self.parameters = ParameterPool()
            self.handle_list(xml_root.iter("ParameterDeclaration"))

            for k, v in assignments.items():
                self.parameters[k].assign_string(v)

        # iterate through the whole tree and replace parameters
        for el in xml_root.iter():
            for a_key, a_val in el.attrib.items():
                if not isinstance(a_val, str):
                    # skip non-string attributes
                    continue
                if el.tag == "ParameterAssignment" and a_key == "name":
                    # skip name field of ParameterAssignment
                    # in case they wrongfully used a dollar sign
                    continue
                el.attrib[a_key] = self.resolve_attribute_value(a_val, f"{el.tag}.{a_key}")

        # restore the global parameter pool
        self.parameters = global_parameters

        return xml_root

    def apply_parameters(self):
        # apply parameters from global parameter pool (either default values or modified via task automation and/or
        # scenario engine py-scripts
        self._resolve_parameters(xml_root=self.root, parameter_pool=self.parameters)
        self.registry.validate_recursive(self, self.root)

    def define_road_network(self) -> Optional[IRoadNetwork]:
        self.road_network: OSCRoadNetwork = self.handle(self.root.find("RoadNetwork"))

        if self.road_network.logic_file is None:
            # Falling back to Proving Ground if no road is specified in an additional python script
            # this is handled by ScenarioLoader
            return None

        xodr_path = Path(self.road_network.logic_file.filepath)

        if not xodr_path.is_absolute():
            xodr_path = self.filename.parent / xodr_path
        if not xodr_path.exists():
            raise RuntimeError(f"OpenDRIVE file '{xodr_path}' does not exist")

        # always pass absolute path to eds so that we bypass the data directory logic
        return OpenDRIVE(str(xodr_path.resolve()))

    def define_entities(self):
        # nothing to do
        pass

    def relative_path_for_element(self, element: Element, sub_path: Path) -> Path:
        if "__catalog__" in element.attrib:
            # if element came from catalog, it will have a __catalog__ attribute added by the parser
            # noinspection PyUnresolvedReferences
            return element.attrib['__catalog__'].parent / sub_path
        else:
            # otherwise this element was defined inline, so use the normal filename as base
            return self.filename.parent / sub_path

    def get_entity(self, entity_ref: str) -> Entity:
        assert self.parsing_stage >= ParsingStage.INIT_LATE
        return self.entity_configs[entity_ref]  # note: the []-operator accesses Entity objects

    def has_entity(self, entity_ref: str) -> bool:
        return entity_ref in self.entity_configs

    def get_entity_config(self, entity_ref: str) -> EntityConfiguration:
        # using entity configs only makes sense as long as entities are not built yet
        assert self.parsing_stage <= ParsingStage.INIT_EARLY
        try:
            return self.entity_configs.get_config(entity_ref)
        except KeyError:
            if entity_ref == "":
                self.add_error(f"Entity with empty name was referenced")
            else:
                self.add_error(f"Entity '{entity_ref}' was referenced but was never declared")

    def handle(self, element: Element, **kwargs):
        """
        Dynamically resolves the handler function depending on the element tag
        """
        return self.registry.handle(self, element, **kwargs)

    def handle_list(self, elements: Iterable[Element], **kwargs) -> List[Any]:
        """
        Iterates over a given list of elements and handles each item.
        Returns a list of corresponding individual return values.
        """
        return [self.handle(e, **kwargs) for e in elements]

    def register_custom_command(self, *cmd_classes: Type[Command]):
        for c in cmd_classes:
            c.register(self.registry)

    def add_info(self, msg: str):
        self.marker_list.add_info_marker(str(self.filename), msg)

    def add_warning(self, msg: str):
        self.marker_list.add_warning_marker(str(self.filename), msg)
        if self.parsing_stage > ParsingStage.INIT_EARLY:
            logger.warning(msg)

    def add_error(self, msg: str):
        self.marker_list.add_error_marker(str(self.filename), msg)
        if self.parsing_stage > ParsingStage.INIT_EARLY:
            logger.error(msg)
