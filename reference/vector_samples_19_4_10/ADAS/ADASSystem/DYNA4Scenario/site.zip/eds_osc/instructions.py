#
# Copyright (c) Vector Informatik GmbH. All rights reserved.
#
import logging

from dyna4.scenario import Condition, Instruction, MetaData, Node, State, TriggerSignal

from .resources import Resource, ResourceUser
from .utils import join_format

logger = logging.getLogger(__name__)


class TriggerCountInstruction(Instruction):
    def __init__(self):
        super().__init__()
        self.trigger_events = []

    def execute(self, time):
        self.trigger_events.append(time)
        return TriggerSignal.TRIGGER

    def count(self):
        return len(self.trigger_events)

    def info(self):
        return f"Triggers: [{join_format(',', '{:.3f}', self.trigger_events)}]"


class TakeResourceInstruction(Instruction):
    def __init__(self, resource: Resource, unblock_condition: Condition):
        super().__init__()
        self.resource = resource
        self.user = None
        self.unblock_condition = unblock_condition

    def set_user(self, user: ResourceUser):
        self.user = user

    def OnActivate(self, src, time):
        self.resource.take(self.user)

    def execute(self, time):
        return TriggerSignal.TRIGGER if self.unblock_condition.update() else TriggerSignal.NULL


class IfInstruction(Instruction):
    """
    Checks if a condition evaluates to true when it gets activated.
    Opposed to EventInstruction that waits until the condition is true,
    IfInstruction only checks once.

    If condition true: triggers immediately
    If condition false: stays deactivated
    """
    def __init__(self, condition: Condition, name=None):
        super().__init__()
        self.condition = condition
        self.name = name or "IfInstruction"

    def execute(self, time):
        return TriggerSignal.TRIGGER

    def OnChangeState(self, new_state, src, time):
        if new_state == State.ACTIVE:
            # only change to active when condition evaluates to true
            cond = self.condition.update()
            return cond
        else:
            return super().OnChangeState(new_state, src, time)

    @classmethod
    def create_node(cls, condition, name, prio=0) -> Node:
        return Node(MetaData(name), prio, cls(condition, name=name))
